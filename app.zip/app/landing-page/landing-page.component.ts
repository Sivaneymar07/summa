import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild } from '@angular/core';
import { PrototypeInterface } from '../shared/prototype.interface';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { NgxCarousel } from 'ngx-carousel';
import { Location } from '@angular/common';
import { DataService } from '../shared/data.service';
import { NetWorkingService } from '../shared/networking.service';
import { Pipe, PipeTransform } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { BaseChartDirective } from 'ng2-charts';
import { Chart } from 'chart.js';


@Component({
    selector: 'app-landing-page',
    templateUrl: './landing-page.component.html',
    styleUrls: ['./landing-page.component.css'],
    providers: [],

})
export class LandingPageComponent implements OnInit, OnDestroy {
    public carouselTile: NgxCarousel;
    public carouselTileTrending: NgxCarousel;
    public carouselTilenew: NgxCarousel;
    public proto: any[] = [];
    @ViewChild(BaseChartDirective) baseChart: BaseChartDirective;

    show_carousel = true;
    value: any;
    routes: string;
    value2 = 'Uniqueviews';
    prototypeFlag = false;
    carouselTileItems = [];
    public carousel: any[] = [];
    imageArray = [
        './assets/images/PAGE1.png',
        './assets/images/PAGE2.png',
        './assets/images/PAGE3.png',
        './assets/images/PAGE4.png'
    ];
    imgCount: any;
    imglength = false;
    hide = false;
    addPopup = false;
    flag = true;
    carouselTileLand: any;
    pid: any;
    p_id: any;
    screenshots = [];
    description: string;
    pdomain: string;
    reqId: any;
    reqassignId: any;
    prototypes: any = [];
    prototypeName: string;
    prototypeSubscription: Subscription;
    proNames = [];
    id: any;
    count = 1;
    prodetails = {};
    prototypeFileName: string;
    favouritesArray = [];
    reviewrs: Array<any>;
    temparra = [];
    savetoast: boolean = false;
    youMayLike = [];
    favourities: any;
    deleteproto = false;
    deleteDialog = false;
    showDialog = false;
    popupCount = 0;
    adminforms: PrototypeInterface[] = [];
    adminform: PrototypeInterface;
    location = '';
    mail: any;
    savetoast2: boolean = false;
    savetoast3: boolean = false;
    loginflag = false;
    loginflag1: any;
    loading: boolean = true;
    dynamicData: any = [];
    userDynamicData: any = [];
    selectedList: string = 'TOYBOX COMMUNITY';
    protoList = ["TOYBOX COMMUNITY", "MY UPLOADS"]
    allDynamicData: PrototypeInterface;
    showList: boolean = false;
    viewsPercent = 0;
    likesPercent = 0;
    sharePercent = 0;
    previewPercent = 0;

    chartOptions: any = {
        responsive: true,
        layout: {
            padding: {
                left: 0,
                right: 0,
                top: 30,
                bottom: 0
            }
        },
        maintainAspectRatio: false,
        scaleShowLabels: false,
        legend: {
            display: false
        },
        scales: {
            pointLabels: {
                fontStyle: "bold",
            },
            yAxes: [{

                display: false,
                gridLines: {
                    display: false,
                    color: "rgba(0, 0, 0, 1)",
                },
                ticks: {
                    beginAtZero: false

                }

            }],

            xAxes: [{
                gridLines: {
                    display: false,
                    color: "#7bceef",
                },
                ticks: {
                    fontSize: 12,
                    beginAtZero: false

                }
            }]

        }


    };

    viewsData = { data: [], label: [] };
    likesData = { data: [], label: [] };
    shareData = { data: [], label: [] };
    previewData = { data: [], label: [] };

    allViewsData = { data: [], label: [] };
    allLikesData = { data: [], label: [] };
    allShareData = { data: [], label: [] };
    allPreviewData = { data: [], label: [] };

    userViewsData = { data: [], label: [] };
    userLikesData = { data: [], label: [] };
    userShareData = { data: [], label: [] };
    userPreviewData = { data: [], label: [] };

    shareChart: any;
    likesChart: any;
    viewsChart: any;
    previewChart: any;

    public lineChartLegend: boolean = true;
    public lineChartType: string = 'line';
    constructor(private data: DataService, private networkingService: NetWorkingService,
        private route: ActivatedRoute, private router: Router, private authService: AuthService) {
        this.route.params.subscribe(
            (params) => {
                this.prototypeFileName = params['id'];
            });
    }

    ngOnInit() {
        this.mail = JSON.parse(localStorage.getItem('user'));
        var obj = { mail: this.mail.email };
        var userObj = {
            user: this.mail
        };
        console.log("userObj", userObj);
        var CurrentIDpro = {
            fileName: this.mail.id
        };

        this.networkingService.get('/users/getSuggested/').subscribe(
            (prototypes) => {
                this.youMayLike = prototypes;
                console.log("this.youMayLike", this.youMayLike);

            });


        this.networkingService.post('/proto/getDynamicData/', {}).subscribe((dynamicData) => {
            this.allDynamicData = dynamicData;
            // this.dynamicData = dynamicData
            console.log("jhgbjhgvbjhg", this.dynamicData)
            var viewsGraph = this.allDynamicData[2].graphViewsData.slice(-5);
            var shareGraph = this.allDynamicData[1].graphShareData.slice(-5);
            var likesGraph = this.allDynamicData[0].graphLikesData.slice(-5);
            var previewGraph = this.allDynamicData[3].graphPreviewData.slice(-5);
            viewsGraph.forEach((viewsCount) => {
                console.log("viewsCount", viewsCount);
                this.allViewsData.data.push(viewsCount.data);
                this.allViewsData.label.push(viewsCount.date);
            })
            shareGraph.forEach((shareCount) => {
                this.allShareData.data.push(shareCount.data);
                this.allShareData.label.push(shareCount.date);
            })
            likesGraph.forEach((likesCount) => {
                this.allLikesData.data.push(likesCount.data);
                this.allLikesData.label.push(likesCount.date);
            })
            previewGraph.forEach((previewCount) => {
                this.allPreviewData.data.push(previewCount.data);
                this.allPreviewData.label.push(previewCount.date);
            })
            console.log("viewsGraph: ", this.viewsData);
            console.log("shareGraph: ", this.shareData);
            console.log("likesGraph: ", this.previewData);

            if (this.allViewsData.data.length != 5) {
                this.allViewsData.data = [4, 10, 8, 6, 9];
                this.allViewsData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];

            }

            if (this.allShareData.data.length != 5) {
                this.allShareData.data = [5, 8, 2, 4, 10];
                this.allShareData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];

            }

            if (this.allLikesData.data.length != 5) {
                this.allLikesData.data = [3, 9, 4, 9, 7];
                this.allLikesData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];

            }
            if (this.allPreviewData.data.length != 5) {
                this.allPreviewData.data = [2, 8, 5, 3, 8];
                this.allPreviewData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];
            }

            this.viewsData.data = this.allViewsData.data;
            this.viewsData.label = this.allViewsData.label;

            this.shareData.data = this.allShareData.data;
            this.shareData.label = this.allShareData.label;

            this.likesData.data = this.allLikesData.data;
            this.likesData.label = this.allLikesData.label;

            this.previewData.data = this.allPreviewData.data;
            this.previewData.label = this.allPreviewData.label;

            if (this.allViewsData.data[3] && this.allViewsData.data[4]) {
                this.viewsPercent = Math.round(((this.allViewsData.data[4] - this.allViewsData.data[3]) / this.allViewsData.data[3]) * 100)
            }
            if (this.allShareData.data[4] && this.allShareData.data[3]) {
                this.sharePercent = Math.round(((this.allShareData.data[4] - this.allShareData.data[3]) / this.allShareData.data[3]) * 100)
            }
            if (this.allLikesData.data[4] && this.allLikesData.data[3]) {
                this.likesPercent = Math.round(((this.allLikesData.data[4] - this.allLikesData.data[3]) / this.allLikesData.data[3]) * 100)
            }
            if (this.allPreviewData.data[4] && this.allPreviewData.data[3]) {
                this.previewPercent = Math.round(((this.allPreviewData.data[4] - this.allPreviewData.data[3]) / this.allPreviewData.data[3]) * 100)
            }

            this.networkingService.post('/proto/getUserDynamicData/', { userId: this.mail.id }).subscribe((userDynamicData) => {
                this.userDynamicData = userDynamicData;
                if (this.userDynamicData.length > 0) {
                    console.log(this.userDynamicData, 'userDynamicData')

                    var viewsGraph = this.userDynamicData[2].graphViewsData.slice(-5);
                    var shareGraph = this.userDynamicData[1].graphShareData.slice(-5);
                    var likesGraph = this.userDynamicData[0].graphLikesData.slice(-5);
                    var previewGraph = this.userDynamicData[3].graphPreviewData.slice(-5);
                    viewsGraph.forEach((viewsCount) => {
                        console.log("viewsCount", viewsCount);
                        this.userViewsData.data.push(viewsCount.data);
                        this.userViewsData.label.push(viewsCount.date);
                    })
                    shareGraph.forEach((shareCount) => {
                        this.userShareData.data.push(shareCount.data);
                        this.userShareData.label.push(shareCount.date);
                    })
                    likesGraph.forEach((likesCount) => {
                        this.userLikesData.data.push(likesCount.data);
                        this.userLikesData.label.push(likesCount.date);
                    })
                    previewGraph.forEach((previewCount) => {
                        this.userPreviewData.data.push(previewCount.data);
                        this.userPreviewData.label.push(previewCount.date);
                    })

                    if (this.userViewsData.data.length != 5) {
                        this.userViewsData.data = [1, 8, 5, 1, 9];
                        this.userViewsData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];
                    }

                    if (this.userShareData.data.length != 5) {
                        this.userShareData.data = [0, 5, 2, 3, 7];
                        this.userShareData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];
                    }

                    if (this.userLikesData.data.length != 5) {
                        this.userLikesData.data = [2, 8, 3, 6, 9];
                        this.userLikesData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];

                    }

                    if (this.userPreviewData.data.length != 5) {
                        this.userPreviewData.data = [2, 4, 5, 2, 10];
                        this.userPreviewData.label = ['May 1-5', 'May 8-12', 'May 15-19', 'May 22-26', 'May 29-30'];
                    }

                }
                this.chartData(this.viewsData, this.previewData, this.likesData, this.shareData);
                this.data.landingPageTabValue.subscribe((tabValue) => {
                    console.log('changing', tabValue);
                    this.selectedList = tabValue;
                    if (this.selectedList === 'TOYBOX COMMUNITY') {
                        this.dynamicData = this.allDynamicData
                    }
                    else {
                        this.dynamicData = this.userDynamicData

                    }
                })

            });

            this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
                (prototypes) => {
                    this.proNames = prototypes;
                    this.loading = false;
                });



        });

        this.networkingService.post('/api/loadAddedPrototypes/', CurrentIDpro)
            .subscribe(
                (prototypes) => {
                    if (prototypes.length > 0) {
                        this.prototypeFlag = true;
                    } else {
                        this.prototypeFlag = false;
                    }
                });
        this.networkingService.post('/users/getfavorite/', obj).subscribe((favourities) => {
            console.log('obj', favourities);
            if (favourities) {
                this.favouritesArray = favourities.favorites;
                console.log("fav", this.favouritesArray.length)
            }
        });
        this.carouselTilenew = {
            grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
            slide: 1,
            speed: 400,
            interval: 4000,
            point: {
                visible: true
            },
            load: 2,
            touch: true,
            loop: true,
            custom: 'banner'
        };
        const currentuser = {
            email: this.mail.email,
        };
        // var gridObject = {
        //     xs: 2,
        //     sm: 3,
        //     md: 6,
        //     all: 0
        // };
        this.carouselTile = {
            grid: {
                xs: 2,
                sm: 3,
                md: 6,
                lg: 6,
                all: 0
            },
            slide: 6,
            speed: 400,
            animation: 'lazy',
            load: 2,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
        this.carouselTileTrending = {
            grid: {
                xs: 2,
                sm: 3,
                md: 4,
                lg: 4,
                all: 0
            },
            slide: 6,
            speed: 400,
            animation: 'lazy',
            load: 2,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
        this.carouselTileLand = {
            grid: {
                xs: 1,
                sm: 1,
                md: 1,
                lg: 1,
                all: 0
            },

            speed: 400,
            animation: 'lazy',
            load: 2,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
        this.location = location.hash;
        this.imgCount = 4;

        this.modalPopUp();
        const CurrentID = {
            fileName: this.mail.id
        };


        const userDetails = JSON.parse(localStorage.getItem('user'));
        if (userDetails.firstlogin !== undefined) {
            this.loginflag = userDetails.firstlogin;
        } else {
            this.networkingService.post('/users/getFirstLogin/', currentuser).subscribe((loginflag) => {
                this.loginflag = loginflag;

            });
        }
    }
    ngOnDestroy() {
        if (this.loginflag) {
            const currentuser = {
                email: this.mail.email,
                id: this.mail.id,
                rewardPoints: this.mail.rewardPoints

            };
            this.networkingService.post('/users/Firstlogin/', currentuser).subscribe((res) => {
                this.loginflag = false;
                localStorage.setItem('user', JSON.stringify(res));

            });
        }
    }
    toggle(p_id) {
        this.p_id = p_id;
        this.deleteDialog = !this.deleteDialog;
    }
    removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    view(id, category, prototype) {
        this.data.changePrototype(prototype);
        if (category.indexOf(' ') !== -1) {
            category = category.split(' ');
            category = category[0] + '%20' + category[1];
        }
        this.router.navigateByUrl('/toolbox/' + category + '/' + id);
        window.scrollTo(0, 0);
    }
    Edit(id) {
        const reqObj = {
            'query': id,
            'lang': 'en'
        };
        this.networkingService.post('/api/editPrototype', reqObj)
            .subscribe(adminform => {
                this.adminforms.push(adminform);
                this.router.navigateByUrl('/toolbox/createPrototype');
            });
    }
    addProto() {
        this.data.changeMessage('false');
        const CurrentID = {
            fileName: this.mail.id
        };
        var draftcount = 1;
        this.networkingService.post('/api/loadAddedPrototypes/', CurrentID)
            .subscribe(
                (prototypes) => {
                    this.proNames = prototypes;
                    if (this.proNames.length !== 0) {
                        for (let j = 0; j < this.proNames.length; j++) {
                            if (this.proNames[j].status === 'Draft') {
                                draftcount++
                                console.log(draftcount);
                            }
                        }
                        if (draftcount > 3) {
                            this.addPopup = true;
                        } else {
                            this.data.sendPrototypeData(null);

                            this.router.navigateByUrl('/toolbox/createPrototype');
                        }
                    } else {
                        this.data.sendPrototypeData(null);
                        this.router.navigateByUrl('/toolbox/createPrototype');
                    }
                });

    }
    edit() {
        for (let j = 0; j < this.proNames.length; j++) {
            if (this.proNames[j].status === 'Draft') {
                const reqObj = {
                    'query': this.proNames[j].id,
                    'lang': 'en'
                };
                this.networkingService.post('/api/editPrototype', reqObj)
                    .subscribe(adminform => {
                        this.adminforms.push(adminform);
                        this.data.sendPrototypeData(adminform);
                        this.router.navigateByUrl('/toolbox/createPrototype');
                    });
            }
        }
    }
    createnew() {
        for (let j = 0; j < this.proNames.length; j++) {
            this.showDialog = !this.showDialog;
            if (this.proNames[j].status === 'Draft') {
                this.networkingService.delete('/api/prototypes/' + this.proNames[j].id)
                    .subscribe(adminform => {
                        const CurrentID = {
                            fileName: this.mail.id
                        };
                    });
            }
        }
    }
    modalPopUp() {
        const a = localStorage.getItem('localCount');
        if (a === 'one') {
            this.showDialog = !this.showDialog;
            localStorage.setItem('localCount', 'two');
        }
    }
    delete() {
        this.networkingService.delete('/api/prototypes/' + this.p_id).subscribe
            (adminform => {
                const CurrentID = {
                    fileName: this.mail.id
                };
                this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
                    (prototypes) => {
                        this.proNames = prototypes;

                    });
                this.deleteDialog = !this.deleteDialog;
            });
        this.deleteproto = true;
        window.scrollTo(0, 0);
    }
    closesignout() {
        this.deleteDialog = !this.deleteDialog;
    }
    deleteclose() {
        this.deleteproto = false;
    }
    gotoPrototypeDetail(id, prototype) {
        this.data.changePrototype(prototype);
        this.router.navigate(['../toolbox/All Categories/' + id]);
        window.scrollTo(0, 0);

    }
    public carouselTileLoad(evt: any) {
        if (evt === 0) {
            this.hide = false;
        } else {
            this.hide = true;
        }
        if (evt === (this.imgCount - 1)) {
            this.imglength = true;
        } else {
            this.imglength = false;
        }
    }
    closebtn() {
        this.showDialog = false;
    }
    filter(value3) {
        this.value2 = value3;
        console.log(value3);
    }
    navClick() {
        this.data.changeMessage('MyPrototypes');
        this.router.navigateByUrl('/toolbox');
    }
    exploreroute() {
        this.data.changeMessage('AllPrototypes');
        this.router.navigateByUrl('/toolbox');
    }
    selectedProto(selectProto) {
        this.data.changeLandingPageTabValue(selectProto)
        // this.selectedList = "TOYBOX COMMUNITY";

        if (this.selectedList === "TOYBOX COMMUNITY") {
            this.dynamicData = this.allDynamicData;


            if (this.allViewsData.data[3] && this.allViewsData.data[4]) {
                this.viewsPercent = Math.round(((this.allViewsData.data[4] - this.allViewsData.data[3]) / this.allViewsData.data[3]) * 100)
            }
            if (this.allShareData.data[4] && this.allShareData.data[3]) {
                this.sharePercent = Math.round(((this.allShareData.data[4] - this.allShareData.data[3]) / this.allShareData.data[3]) * 100)
            }
            if (this.allLikesData.data[4] && this.allLikesData.data[3]) {
                this.likesPercent = Math.round(((this.allLikesData.data[4] - this.allLikesData.data[3]) / this.allLikesData.data[3]) * 100)
            }
            if (this.allPreviewData.data[4] && this.allPreviewData.data[3]) {
                this.previewPercent = Math.round(((this.allPreviewData.data[4] - this.allPreviewData.data[3]) / this.allPreviewData.data[3]) * 100)
            }
            this.viewsData = this.allViewsData;

            this.shareData = this.allShareData;

            this.likesData = this.allLikesData;

            this.previewData = this.allPreviewData;

            this.chartData(this.allViewsData, this.allPreviewData, this.allLikesData, this.allShareData);

        }
        else if (this.selectedList === "MY UPLOADS") {
            if (this.proNames.length > 0) {
                this.dynamicData = this.userDynamicData;


                if (this.userViewsData.data[3] && this.userViewsData.data[4]) {
                    this.viewsPercent = Math.round(((this.userViewsData.data[4] - this.userViewsData.data[3]) / this.userViewsData.data[3]) * 100)
                }
                if (this.userShareData.data[4] && this.userShareData.data[3]) {
                    this.sharePercent = Math.round(((this.userShareData.data[4] - this.userShareData.data[3]) / this.userShareData.data[3]) * 100)
                }
                if (this.userLikesData.data[4] && this.userLikesData.data[3]) {
                    this.likesPercent = Math.round(((this.userLikesData.data[4] - this.userLikesData.data[3]) / this.userLikesData.data[3]) * 100)
                }
                if (this.userPreviewData.data[4] && this.userPreviewData.data[3]) {
                    this.previewPercent = Math.round(((this.userPreviewData.data[4] - this.userPreviewData.data[3]) / this.userPreviewData.data[3]) * 100)
                }
                this.viewsData = this.userViewsData;

                this.shareData = this.userShareData;

                this.likesData = this.userLikesData;

                this.previewData = this.userPreviewData;
                this.chartData(this.userViewsData, this.userPreviewData, this.userLikesData, this.userShareData);

            }
            this.selectedList = "MY UPLOADS";
            console.log(this.selectedList)


        }
        this.showList = false;
    }
    chartClicked(event) {
        console.log("chart event", this.baseChart);
        // this.baseChart.datasets[0].data[4].fillColor = "rgba(000,111,111,55)";
        // this.baseChart.chart.update();

    }
    onClickOutside(e: Event) {
        this.showList = false;
    }
    clickfilter() {
        this.showList = true;
    }
    chartData(vChart, pChart, lChart, sChart) {
        console.log("ngAfterViewInit");

        var vctx = document.getElementById("viewsChart");
        this.viewsChart = new Chart(vctx, {

            type: 'line',
            data: {
                labels: vChart.label,
                datasets: [{
                    label: 'Unique visits',
                    data: vChart.data,
                    backgroundColor: '#2cb1f5',
                    borderColor: '#2cb1f5',
                    pointBackgroundColor: ['#2c65b4', '#2c65b4', '#2c65b4', '#2c65b4', '#2c65b4'],
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: ['#2c65b4', '#2c65b4', '#2c65b4', '#2c65b4', '#2c65b4'],
                    pointHoverBorderColor: '#fff',
                    borderWidth: 1,
                    pointRadius: 7,
                    pointHoverRadius: 7,
                }]
            },
            options: this.chartOptions,
        });

        console.log("vchart", this.viewsChart);
        var v = vChart.data.indexOf(Math.max(...vChart.data));
        this.viewsChart.config.data.datasets[0].pointBackgroundColor[v] = "#e41919";
        this.viewsChart.config.data.datasets[0].pointHoverBackgroundColor[v] = "#e41919";
        this.viewsChart.update();

        var pctx = document.getElementById("previewChart");
        this.previewChart = new Chart(pctx, {

            type: 'line',
            data: {
                labels: pChart.label,
                datasets: [{
                    label: 'Preview',
                    data: pChart.data,
                    backgroundColor: '#fe6d9b',
                    borderColor: '#fe6d9b',
                    pointBackgroundColor: ['#fe6d9b', '#fe6d9b', '#fe6d9b', '#fe6d9b', '#fe6d9b'],
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: ['#fe6d9b', '#fe6d9b', '#fe6d9b', '#fe6d9b', '#fe6d9b'],
                    pointHoverBorderColor: 'rgba(148,159,177,0.8)',
                    borderWidth: 1,
                    pointRadius: 7,
                    pointHoverRadius: 7,
                }]
            },
            options: this.chartOptions,
        });

        var p = pChart.data.indexOf(Math.max(...pChart.data));
        this.previewChart.config.data.datasets[0].pointBackgroundColor[p] = "#e41919";
        this.previewChart.config.data.datasets[0].pointHoverBackgroundColor[p] = "#e41919";
        this.previewChart.update();

        var lctx = document.getElementById("likesChart");
        this.likesChart = new Chart(lctx, {

            type: 'line',
            data: {
                labels: lChart.label,
                datasets: [{
                    label: 'Likes',
                    data: lChart.data,
                    backgroundColor: '#a1c15e',
                    borderColor: '#a1c15e',
                    pointBackgroundColor: ['#a1c15e', '#a1c15e', '#a1c15e', '#a1c15e', '#a1c15e'],
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: ['#a1c15e', '#a1c15e', '#a1c15e', '#a1c15e', '#a1c15e'],
                    pointHoverBorderColor: 'rgba(148,159,177,0.8)',
                    borderWidth: 1,
                    pointRadius: 7,
                    pointHoverRadius: 7,
                }]
            },
            options: this.chartOptions,
        });
        var l = lChart.data.indexOf(Math.max(...lChart.data));
        this.likesChart.config.data.datasets[0].pointBackgroundColor[l] = "#e41919";
        this.likesChart.config.data.datasets[0].pointHoverBackgroundColor[l] = "#e41919";

        this.likesChart.update();

        var sctx = document.getElementById("shareChart");
        this.shareChart = new Chart(sctx, {

            type: 'line',
            data: {
                labels: sChart.label,
                datasets: [{
                    label: 'Shares',
                    data: sChart.data,
                    backgroundColor: '#9775ce',
                    borderColor: '#9775ce',
                    pointBackgroundColor: ['#9775ce', '#9775ce', '#9775ce', '#9775ce', '#9775ce'],
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: ['#9775ce', '#9775ce', '#9775ce', '#9775ce', '#9775ce'],
                    pointHoverBorderColor: 'rgba(148,159,177,0.8)',
                    borderWidth: 1,
                    pointRadius: 7,
                    pointHoverRadius: 7,

                }]
            },
            options: this.chartOptions,
        });
        var s = sChart.data.indexOf(Math.max(...sChart.data));
        this.shareChart.config.data.datasets[0].pointBackgroundColor[s] = "#e41919";
        this.shareChart.config.data.datasets[0].pointHoverBackgroundColor[s] = "#e41919";
        this.shareChart.update();

    }
}
@Pipe({
    name: 'reverse',
    pure: false
})
export class ReversePipe implements PipeTransform {
    transform(value) {
        return value.slice().reverse();
    }
}

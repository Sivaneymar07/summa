import { Component, OnInit, OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { DataService } from '../../shared/data.service';
import { NetWorkingService } from '../../shared/networking.service';
import { AuthService } from '../../services/auth.service';
import { NgxCarousel } from 'ngx-carousel';
@Component({
  selector: 'app-active-campaign',
  templateUrl: './active-campaign.component.html',
  styleUrls: ['./active-campaign.component.css']
})
export class ActiveCampaignComponent implements OnInit {
  count = 1;
  campaign = [];
    campaignCount = 0;
  campaignFlag = true;
  popupCount = 0;
  location = '';
  mail: any;
  emptyArray = [];
  public carouselTile: NgxCarousel;
  public carouselTileTrending: NgxCarousel;
  public carouselTilenew: NgxCarousel;

  constructor(private networkingservice: NetWorkingService, private data: DataService, private networkingService: NetWorkingService,
    private route: ActivatedRoute, private router: Router, private authService: AuthService) { }

  ngOnInit() {
    const userObj = JSON.parse(localStorage.getItem('user'));
    this.networkingService.post('/users/getcampaign/', {}).subscribe(
      (services) => {
        this.campaign = services;
        this.campaign = services;
        for (let i = 0; i < this.campaign.length; i++) {
          this.campaign[i].show = true;
        }
        this.networkingservice.post('/servicerequest/getenrollment', userObj)
          .subscribe(data => {
            if (data.length > 0) {
              for (let i = 0; i <= data.length; i++) {
                for (let j = 0; j < services.length; j++) {
                  if (services[j]) {
                    if (data[i].service_id === services[j].id) {
                      this.campaign[j].show = false;
                    }
                  }
                }
                this.emptyArray = this.campaign;
                for (let k = 0; k < this.campaign.length; k++) {
                  if (this.emptyArray[k].show === false) {
                    this.emptyArray.splice(k, 1);
                  }
                }
                this.campaignCount = this.emptyArray.length;
              }
            } else {
              this.emptyArray = services;
              this.campaignCount = this.emptyArray.length;
            }
            console.log(this.emptyArray, 'campaign count');
          });

      });
    this.carouselTilenew = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };
  }

}

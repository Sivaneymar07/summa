import { Component, OnInit, OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { PrototypeInterface } from '../shared/prototype.interface';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { DataService } from '../shared/data.service';
import { NetWorkingService } from '../shared/networking.service';
import { AuthService } from '../services/auth.service';
import { NgxCarousel } from 'ngx-carousel';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-user-stream',
  templateUrl: './user-stream.component.html',
  styleUrls: ['./user-stream.component.css']
})
export class UserStreamComponent implements OnInit {
  profilePopup = false;
  displayPic: string;
  profileProto = [];
  profile: any;
  tabvalue = 'MyPrototypes'
  carouselTileItems = [];
  coreProfileCount = 0;
  id: any;
  activeFeed: any;
  public carouselTile: NgxCarousel;
  public carouselTileTrending: NgxCarousel;
  public carouselTilenew: NgxCarousel;
  carouselTileLand: any;
  imgCount: any;
  imglength = false;
  hide = false;
  location = '';
  coreTeam = [];
  activityProfileSetting: Boolean = false;
  peopleWeSuggest: Boolean = false;
  peopleYouMayKnow: Boolean = false;
  activityStart: Boolean = true;
  settingsObj: any;
  notifiComment: Boolean = false;
  notifiPeoplerating: Boolean = false;
  notifiPlaylist: Boolean = false;
  notifiEvent: Boolean = false;
  notifiPeopleEvent: Boolean = false;
  userData: any;
  userSettingObj: any;
  userSaveData: any;
  user: any;
  userStream: Boolean;
  followListArray: Array<any> = [];
  activityFeed: Array<any> = [];
  profileProgress: number;
  followButtonFlag : Array<any> = [];



  constructor(private data: DataService, private networkingService: NetWorkingService,
    private route: ActivatedRoute, private router: Router, private authService: AuthService,
    private translate: TranslateService) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    const username = this.user.username;
    this.carouselTilenew = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };

    this.carouselTile = {
      grid: {
        xs: 2,
        sm: 3,
        md: 4,
        lg: 6,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.carouselTileTrending = {
      grid: {
        xs: 2,
        sm: 3,
        md: 4,
        lg: 4,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.carouselTileLand = {
      grid: {
        xs: 1,
        sm: 1,
        md: 1,
        lg: 1,
        all: 0
      },

      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.location = location.hash;
    this.imgCount = 4;
    const userObj = {
      user: this.user
    };
    this.networkingService.post('/users/coreteam', userObj)
      .subscribe(
        (coreteamlist) => {
          this.coreTeam = coreteamlist;
          console.log("this.coreTeamTTTTTTTTTTTTTTTTTTTTTTTTTTTTT", this.coreTeam)
        });
    this.networkingService.post('/users/follow', userObj)
      .subscribe(
        (followlist) => {
          console.log("userstream checking", followlist);
          this.followListArray = followlist;
        });
    this.networkingService.post('/users/getActivityFeed/' + this.user.id, {}).subscribe((activityFeeds) => {
      this.activityFeed = activityFeeds.reverse();
    });
  }

  configureSetting() {
    this.activeFeed = 'hideDom';
    this.peopleWeSuggest = true;
    this.activityStart = false;
    return this.activeFeed;
  }
  saveActivityFeedSettings() {
    this.networkingService.post('/users/ViewProfile', { email: this.user.email }).subscribe(data => {
      if (data !== '') {
        this.profileProgress = data.Profileprogress
        this.userStream = data.userStream;
        var profileProgress = this.profileProgress;
        if (!this.userStream)
          profileProgress = this.profileProgress + 20;
      }
      this.settingsObj = {
        comment: this.notifiComment,
        playlist: this.notifiPlaylist,
        peopleEvent: this.notifiPeopleEvent,
        userId: this.user.id,
        emailId: this.user.email,
        rating: this.notifiPeoplerating,
        profileProgress: profileProgress,
        userStream: true
      };
      if (JSON.stringify(this.userSettingObj) === JSON.stringify(this.settingsObj)) {

      } else {
        this.networkingService.put('/users/activityFeed', this.settingsObj).subscribe((Response) => {
          localStorage.setItem('user', JSON.stringify(Response));
          this.user = JSON.parse(localStorage.getItem('user'));
          this.networkingService.post('/users/getnotification/' + this.user.email, {}).subscribe((resdata) => {
            this.data.profilenotify(resdata);
          });
        });
        this.userSettingObj = this.settingsObj;
        this.userData = this.userSaveData;
      }
    });
  }
  followFunction(id, event) {
    this.coreProfileCount++;
    event.stopPropagation();
    this.followButtonFlag[id] = true
    this.networkingService.put('/users/followerAndFollowingUpdate/' + id, this.user).subscribe(uploadData => {

      // var userObj = {
      //   user: this.user
      // };
      // this.networkingService.post('/users/coreteam', userObj)
      //   .subscribe(
      //     (followlist) => {
      //       this.coreTeam = followlist;
      //       console.log("followListArray ggggggggggggggggggggggggggggggg", this.followListArray);
      //     });
    });


  }
  unfollowFunction(id, event) {
    this.coreProfileCount--;
    event.stopPropagation();
    this.followButtonFlag[id] = false
    this.networkingService.put('/users/unfollow/' + id, this.user).subscribe(uploadData => {

      // var userObj = {
      //   user: this.user
      // };
      // this.networkingService.post('/users/coreteam', userObj)
      //   .subscribe(
      //     (followlist) => {
      //       this.coreTeam = followlist;
      //       console.log("followListArray ggggggggggggggggggggggggggggggg", this.followListArray);
      //     });
    });


  }
  viewProfile(profileData) {

    console.log("profileData in userstream", profileData);
    this.profile = profileData;

    this.profileProto = profileData.addedPrototypes;
    console.log("this.profileProto userstream", this.profileProto);
    this.profilePopup = true;


  }
  close() {
    this.profilePopup = false;
  }
  tabchange(value) {
    console.log(value, 'value');
    // if (value == 'MyPrototypes') {
    // const CurrentID = {
    //   fileName: this.mail.id,
    //   admin: this.mail.admin
    // };

    // this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
    //   (prototypes) => {

    //     this.proNames = prototypes;
    //     console.log("loadAddedPrototypes",this.proNames)
    //   });
    // }
    this.tabvalue = value;
  }
}

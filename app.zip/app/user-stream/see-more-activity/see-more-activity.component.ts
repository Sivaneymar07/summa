import { Component, OnInit, OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { DataService } from '../../shared/data.service';
import { NetWorkingService } from '../../shared/networking.service';
import { AuthService } from '../../services/auth.service';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';


@Component({
    selector: 'app-see-more-activity',
    templateUrl: './see-more-activity.component.html',
    styleUrls: ['./see-more-activity.component.css']
})
export class SeeMoreActivityComponent implements OnInit {
    loading: Boolean = true;
    activityFeed: Array<any> = [];
    mail: any;
    timeStamp: Array<any> = [];
    // public loading = false;

    mailHeader: Array<any> = [];

    constructor(private data: DataService, private networkingService: NetWorkingService,
        private route: ActivatedRoute, private router: Router, private authService: AuthService,
        private translate: TranslateService, private _location: Location,
    ) {
    }
    ngOnInit() {
                this.loading = true;

        this.mail = JSON.parse(localStorage.getItem('user'));
        const obj = { mail: this.mail.email };
        const userObj = {
            user: this.mail
        };
        this.networkingService.post('/users/getActivityFeed/' + this.mail.id, {}).subscribe((activityFeeds) => {
                        this.loading = false;
            
            this.activityFeed = activityFeeds;
            console.log('bgbg', activityFeeds);
            let i = -1;
            this.activityFeed.forEach((feed) => {
                i++;
                let mailId;
                if (feed.userId.ldap) {
                    mailId = feed.userId.email.split('.');
                    this.mailHeader[i] = mailId[0][0].concat(mailId[1][0]);
                } else {
                    this.mailHeader[i] = feed.userId.email.slice(0, 2);
                }

                let diff = moment(new Date(), 'MM/DD/YYYY HH:mm')
                    .diff(moment(new Date(feed.timeStamp), 'MM/DD/YYYY HH:mm'), 'second');
                this.timeStamp[i] = `${diff} seconds ago`;
                if (diff > 60) {
                    diff = moment(new Date(), 'MM/DD/YYYY HH:mm')
                        .diff(moment(new Date(feed.timeStamp), 'MM/DD/YYYY HH:mm'), 'minute');
                    this.timeStamp[i] = `${diff} minutes ago`;
                    if (diff > 60) {
                        diff = moment(new Date(), 'MM/DD/YYYY HH:mm')
                            .diff(moment(new Date(feed.timeStamp), 'MM/DD/YYYY HH:mm'), 'hours');
                        this.timeStamp[i] = `${diff} hours ago`;
                        if (diff > 24) {
                            // diff = moment(new Date(), 'MM/DD/YYYY HH:mm')
                            //     .diff(moment(new Date(feed.timeStamp), 'MM/DD/YYYY HH:mm'), 'days');
                            this.timeStamp[i] = moment(new Date(feed.timeStamp)).format('MMMM Do YYYY, h:mm:ss a');

                        }
                    }
                }
            });
        });

    }
    backToHome() {
        this._location.back();
    }
}

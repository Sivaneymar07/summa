import { Component, OnInit, OnDestroy, Pipe, PipeTransform, Input } from '@angular/core';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { DataService } from '../../shared/data.service';
import { NetWorkingService } from '../../shared/networking.service';
import { AuthService } from '../../services/auth.service';
import { NgxCarousel } from 'ngx-carousel';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {
  @Input() followersFlag: Boolean;
  mail: any;
  id: any;
  public carouselTile: NgxCarousel;
  public carouselTileTrending: NgxCarousel;
  public carouselTilenew: NgxCarousel;
  tabvalue = 'MyPrototypes'
  proNames = [];
  follow: any;
  profile: any;
  followListArray: any = [];
  profilePopup = false;
  carouselTileItems = [];
  carouselTileLand: any;
  imgCount: any;
  imglength = false;
  hide = false;
  location = '';
  profileProto = [];
  displayPic: string;
  followButtonFlag: Array<any> = [];

  constructor(private data: DataService, private networkingService: NetWorkingService,
    private route: ActivatedRoute, private router: Router, private authService: AuthService) { }

  ngOnInit() {
    // ******************************************FOLLOW USER FUNCTIONS STARTS**********************//
    this.carouselTilenew = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };
    // const currentuser = {
    //   email: this.mail.email,
    //   // admin:this.admin
    // };
    this.carouselTile = {
      grid: {
        xs: 2,
        sm: 3,
        md: 4,
        lg: 6,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.carouselTileTrending = {
      grid: {
        xs: 2,
        sm: 3,
        md: 4,
        lg: 4,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.carouselTileLand = {
      grid: {
        xs: 1,
        sm: 1,
        md: 1,
        lg: 1,
        all: 0
      },

      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };

    this.location = location.hash;
    this.imgCount = 4;
    this.mail = JSON.parse(localStorage.getItem('user'));
    var obj = { mail: this.mail.email };
    // var userObj = { userId: this.mail.id, department: this.mail.department };
    var userObj = {
      user: this.mail
    };
    console.log("userObj", userObj);
    var CurrentIDpro = {
      fileName: this.mail.id
    };
    this.networkingService.post('/users/follow', userObj)
      .subscribe(
        (followlist) => {
          this.followListArray = followlist;

          console.log("followListArray - followers page", this.followListArray);
        });

  }
  tabchange(value) {
    console.log(value, 'value');
    // if (value == 'MyPrototypes') {
    // const CurrentID = {
    //   fileName: this.mail.id,
    //   admin: this.mail.admin
    // };

    // this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
    //   (prototypes) => {

    //     this.proNames = prototypes;
    //     console.log("loadAddedPrototypes",this.proNames)
    //   });
    // }
    this.tabvalue = value;
  }
  followFunction(id, event) {
    this.followButtonFlag[id] = true
    event.stopPropagation();
    this.networkingService.put('/users/followerAndFollowingUpdate/' + id, this.mail).subscribe(uploadData => {

      // var userObj = {
      //   user: this.mail
      // };
      // this.networkingService.post('/users/follow', userObj)
      //   .subscribe(
      //     (followlist) => {
      //       this.followListArray = followlist;
      //       console.log("followListArray", this.followListArray);
      //     });
    });


  }
  unfollowFunction(id, event) {
    event.stopPropagation();
    this.followButtonFlag[id] = false
    this.networkingService.put('/users/unfollow/' + id, this.mail).subscribe(uploadData => {

      // var userObj = {
      //   user: this.user
      // };
      // this.networkingService.post('/users/coreteam', userObj)
      //   .subscribe(
      //     (followlist) => {
      //       this.coreTeam = followlist;
      //       console.log("followListArray ggggggggggggggggggggggggggggggg", this.followListArray);
      //     });
    });


  }
  viewProfile(profileData) {

    this.profile = profileData;
    console.log("profileData", profileData);
    this.displayPic = profileData
    this.profileProto = profileData.addedPrototypes;
    console.log("this.profileProto", this.profileProto);
    this.profilePopup = true;


  }
  close() {
    this.profilePopup = false;
  }
  public carouselTileLoad(evt: any) {
    if (evt === 0) {
      this.hide = false;
    } else {
      this.hide = true;
    }
    if (evt === (this.imgCount - 1)) {
      this.imglength = true;
    } else {
      this.imglength = false;
    }
  }
}

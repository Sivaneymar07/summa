import { Component, OnInit } from '@angular/core';
import { Location, NgStyle } from '@angular/common';
import { NetWorkingService } from '../../shared/networking.service';
import { LoadingModule } from 'ngx-loading';


@Component({
  selector: 'app-profile-list',
  templateUrl: './profile-list.component.html',
  styleUrls: ['./profile-list.component.css']
})
export class ProfileListComponent implements OnInit {
  mail: any;
  followListArray: any = [];
  profilePopup = false;
  profile: any;
  profileProto = [];
  public loading = false;
  tabvalue = 'MyPrototypes'
  constructor(private _location: Location, private networkingService: NetWorkingService) { }

  ngOnInit() {
    this.loading = true;
    this.mail = JSON.parse(localStorage.getItem('user'));
    var userObj = {
      user: this.mail
    };
    this.networkingService.post('/users/follow', userObj)
      .subscribe(
        (followlist) => {
          this.loading = false;
          console.log("checking", followlist);
          this.followListArray = followlist;
          console.log("this.followListArray", this.followListArray);

        });

  }
  backToprofileList() {
    this._location.back();
  }
  close() {
    this.profilePopup = false;
  }
  viewProfile(profileData) {
    console.log("profile list click", profileData)
    this.profilePopup = true;
    this.profile = profileData;
    this.profileProto = profileData.addedPrototypes;
  }
  tabchange(value) {
    console.log(value, 'value');
    // if (value == 'MyPrototypes') {
    // const CurrentID = {
    //   fileName: this.mail.id,
    //   admin: this.mail.admin
    // };

    // this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
    //   (prototypes) => {

    //     this.proNames = prototypes;
    //     console.log("loadAddedPrototypes",this.proNames)
    //   });
    // }
    this.tabvalue = value;
  }
}

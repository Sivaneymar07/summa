import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../shared/networking.service';
import { DataService } from '../shared/data.service';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-favorite-details',
  templateUrl: './favorite-details.component.html',
  styleUrls: ['./favorite-details.component.css']
})
export class FavoriteDetailsComponent implements OnInit {

  constructor(private networkingService : NetWorkingService, private location : Location , private data : DataService, private route: ActivatedRoute, private router: Router) { }
  user: any;
  favorites:Array<any> = []
  loading:Boolean = true;
  page:String
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    var obj = { mail: this.user.email }    
    this.networkingService.post('/users/getfavorite/',obj).subscribe((response)=> {
      this.favorites = response.favorites;
      this.loading = false;
    })
    this.data.currentMessage.subscribe(res=> {
      console.log(res,'res')
      if(res === '/landingpage') {
        this.page = 'Home'
      }
      else if(res === '/toolbox/All%20Categories') {
        this.page = 'Prototypes'
      }
      else if(res === '/playlist') {
        this.page = 'Playlist'
      }
      else if(res.includes('service-request')) {
        this.page = 'Service Request'
      }
      else if(res === '/myProject') {
        this.page = 'My Project'
      }
      else if(res.includes('rbac')) {
        this.page = 'Dashboard'
      }
      else if(res.includes('permissions')){
        this.page = 'User Permissions'
      }
      else if(res.includes('opportunity')) {
        this.page = 'Opportunity Tracker'
      }
    })
  }
  backToCategoryList() {
    this.location.back();
  }
  gotoPrototypeDetail(id, prototype) {
    this.data.changePrototype(prototype);
    this.router.navigate(['../toolbox/All Categories/' + id]);
    window.scrollTo(0, 0);
  }
}

import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../shared/networking.service';
import { DataService } from '../shared/data.service';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ValidateService } from '../services/validate.service';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { ClickOutsideModule } from 'ng-click-outside';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  i: any = 0;
  user: any;
  message: string;
  search: string;
  token: string;
  authToken: string;
  item: any;
  public a: number;
  location = '';
  categoryname = '';
  resObj = [];
  requestObj3: any;
  requestObjpro: Object = {};
  userSubscription: Subscription;
  headerFlag: any;
  signoutDialog = false;
  signoutDialog1 = false;
  popupCount = 0;

  constructor(private authService: AuthService,
    private data: DataService,
    private route: ActivatedRoute,
    public router: Router,
    private _location: Location,
    private networkingService: NetWorkingService
  ) { }
  ngOnInit() {
    this.item = localStorage.getItem('user');
    this.user = JSON.parse(this.item);
    //  this.router.events.filter(event => event instanceof NavigationEnd)
    //     .subscribe(
    //       event => {
    //         if (this.a !== 3) {
    //           this.search = undefined;
    //         }
    //       }
    //     );
    // this.data.currentFlag1.subscribe(message => {
    //   console.log(message)
    this.route.params.subscribe(
      (params) => {
        this.requestObjpro = {
          query: params['id'],
          userGroup: this.user.userGroup,
          curuser: this.user.email
        };
        //   };
        // });
        // this.data.currentFlag2.subscribe(response => {
        //    this.headerFlag = response;
        // });
      });
  }
  sendSearchData() {
    const requestObj = {
      query: this.search,
      lang: 'en',
      curuser: this.user.email
    };
    if (this.search.length >= 3) {
      //   this.data.changeFlag4(true);
      //    this.data.currentFlag2.subscribe(response => {
      //    if (response !== 'loading') {
      //     if (response === 'list') {
      //       this.data.changeFlag3('listpageshow');
      //     } else {
      //       this.data.changeFlag3('listpagehide');
      //     }
      //    }
      // });
      this.networkingService.post("/api/searchdata", requestObj).subscribe((res) => {
        console.log("dataservice response", res);
        this.data.changeMessage(res);

      });
    } else if (this.search.length === 0) {
      // this.data.currentFlag2.subscribe(response => {
      //    if (response !== 'loading') {
      //     if (response === 'list') {
      //        this.data.changeFlag3('listpagehide');
      //     } else {
      //         this.data.changeFlag3('listpageshow');
      //     }
      //    }
      // });
      this.networkingService.post("/api/prototypesSearch", this.requestObjpro).subscribe((res) => {
        console.log(res)
        const mergeArr = [];
        mergeArr.push(res[0]);
        mergeArr.push(res[1]);
        this.data.changeMessage(res);
      });
    }
  }
}

export class ServiceInterface {
    public Requestername: string;
    public email_address: string;
    public Phonenumber: any;
    public Clientname: string;
    public onbehalfname: string;
    public onbehalfemail: string;
    public onbehalfphonenumber: any;
    // public Domain: string;
    public Role: string;
    public ServiceRequested: string;
    public RequestType: string;
    public PreferredChannel: string;
    public Preferredplatform: string;
    public Fidelity: string;
    public techStackArray: Array<any>;
    public OperatingSystemField: string;
    public PrototypePlatformField: string;
   public InstanceNeededField: any;
    public req_id: any;
    public timeStamp: any;
    public user_id: any;
    public id: any;
    public instance_url: string;
    public status: string;

}

export class requestInterface {
    // public cust_name:string;
    public req_id: any;
    // public timeStamp: string;
    // public tech_details:string;
}


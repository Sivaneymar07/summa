

export class PrototypeInterface {
        // public Customer: string;
        public PrototypeName: string;
        // public Industry: string;
        //  public Technology: string;
        // public vertical: string;
        public Categories: any;
        // public type : string;
        // public Fidelity : string;
        public type: string;
        public subtype: string;
        public Fidelity: string;
        public category_name: any;
        // public Description: string;
        public LDescription: string;
        public domain: string;
        public ownerID: number;
        public ownerName: string;
        // public Designation : string;
        // public BU : string;
        // public Compatability : string;
        // public Factor : string;
        public Frontend: string;
        public Middleware: string;
        public Backend: string;
        public Comments: string;
        public Hosted: string;
        // public Tags : string;
        public id:  string;
        public prototype_id:  string;
        public categoryUrl:  string;
        public app_icon:  string;
        public accronym:  string;
        public uploadDate:  string;
        public rating:   string;
        public ratingUrl:  string;
        public popularity:  string;
        public thumbnail_Url: string;
        public playstore_Url: string;
        public ios_Url:  string;
        public platform: string;
        public screenshots: any;
        public ExecuteableFile:  string;
        public HelpGuide:  string;
        public Icon:  string;
        public user_id: string;
        public user_email: string;
        public review: any;
        public  prototype_type: string;
        public Technology: string;
        public status: string;
        public author_name: String;
        public lastModifiedDate: String;
        public  supportingFileName: String;
        public supportingFileSize: String;
        public dueDate: String;
        public rejectFeedback: String;
        // public ExFileDescription:  string;
        // public ReadmeFileDescription: string;
        // public appIconDescription:  string;
        // public ScreenshotDescription: string;


}


import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';

let responseData;
let prototype;
@Injectable()
export class DataService {
    private subject = new Subject<any>();
    public messageSource = new BehaviorSubject<string>('AllPrototypes');
    private profileNotification = new BehaviorSubject<any>('');//profile, category list, and admin form ,header//clubbed with prototype detail
    private prototypeDetail = new BehaviorSubject<string>('');
    private landingPageTab = new BehaviorSubject<string>('TOYBOX COMMUNITY');
    currentMessage = this.messageSource.asObservable();
    prototype = this.prototypeDetail.asObservable();
    MyprofileNotification = this.profileNotification.asObservable();
    landingPageTabValue = this.landingPageTab.asObservable();
    changeMessage(message) {

        this.messageSource.next(message);
        console.log("message",message)
    }
    profilenotify(detail) {
        this.profileNotification.next(detail);
    }
    changePrototype(detail) {
        this.prototypeDetail.next(detail);
        console.log("detailsdetails", detail)
    }
    sendPrototypeData(data) {
        prototype = data;
    }
    getPrototypeData() {
        return prototype;
    }
    sendMessage(message: string) {
        this.subject.next({ text: message });
    }
    changeLandingPageTabValue(tabValue) {
        this.landingPageTab.next(tabValue);
    }

    clearMessage() {
        this.subject.next();
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

}




export class CommonInterface {

                            public _id: any;
                            public id: string;
                            public prototype_id: string;
                            public name: string;
                            public category: string;
                            public tags: string;
                            public uploadDate: string;
                            public rating: number;
                            public ratingUrl: string;
                            public accronym: string;
                            public category_name: string;
                            public categoryUrl: string;
                            public app_icon: string;
                            public popularity: string;
                            public title: string;
                            public domain: string;
                            public Technology: string;
                            public shortDescription: string;
                            public description: string;
                            public thumbnail_url: string;
                            public playstore_url: string;
                            public ios_url: string;
                            public platform: string;
                            public prototype_type: string;
                            public screenshots: any;
                            public review: any;
                            public user_id: string;
                            public likesCount:number;
                            public shareCount:number;
                            public uniqueViewsCount:number;
                            public previewCount:number;
}

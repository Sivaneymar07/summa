export class CategorynameInterface {
    public PrototypeName: string;
    public Categories: any;
}

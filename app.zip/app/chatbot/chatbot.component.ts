import { Component, AfterViewChecked, ElementRef, ViewChild, OnInit, Input } from '@angular/core';
import { Http, Response } from '@angular/http';
import { CommonModule } from '@angular/common';
import { NetWorkingService } from './../shared/networking.service';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core'; 

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css']
})

export class ChatbotComponent implements OnInit, AfterViewChecked {
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;
  @Input() Click;
  knowTYB : string;
  contactusYes : string;
  profileExploration : string
  raiseRequest : string;
  augmentedReality : string;
  internetOfThings : string;
  artificialIntelligence : string;
  allPrototypes : string;
  ownExploration : string;
  conceptBuilder : string;
  prototypeFactory : string;
  serviceRequest : string;
  title = 'app';
  msg = '';
  contactus : any;
  botMsg = [];
  temp = {};
  oldUserfirstTime = true;
  newUserfirstTime = true;  
  profilePage = false;
  secondTime :boolean;
  userObj: any;
  userName : string; 
  i = 0;
  userFlag = false;
  videoFlag = false;
  userMsg = '';
  Response = '';
  redirectToSupportTeam = false;
  location = '';

constructor(private netWorkingService: NetWorkingService, private router: Router, private translate: TranslateService) { }   

ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        window.scrollTo(0, 0);
        this.location = event.url;
      }
      if(this.location == '/login'){
        this.Click=true;
      }
    });
    this.userFlag = false;
    this.userObj = JSON.parse(localStorage.getItem('user'));
    this.userName = this.userObj.name;
    console.log('username',this.userName)
    if(this.userName){
    this.temp["Response"] = "Hi " + this.userName + "! I am here to help you!";
    this.temp["userFlag"] = false; 
    this.sendMsg();   
    }
    else{
      this.sendMsg();
    }
    this.botMsg.push(this.temp);
  }
  ngAfterViewChecked() {
    // this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) { }
  }

  sendMsg() {
    if(this.userName){
      if (this.oldUserfirstTime) {
        var requestObj = {
          'query': "hi",
          'lang': 'en'
        };
        this.oldUserfirstTime = false;
      } else {
        var requestObj = {
          'query': this.msg,
          'lang': 'en'
        };
      };
      this.netWorkingService.post('/oldUser', requestObj).subscribe(res => {
        const output = res.result.fulfillment.messages;
        this.temp = {};
        this.userMsg = this.msg;
        this.temp["Response"] = this.msg;
        this.temp["userFlag"] = true;
        this.botMsg.push(this.temp);
        console.log(this.botMsg, "botMsg Arraaaay");
        this.temp = {};
        this.msg = '';      
        console.log(this.userMsg);  
        for (var msgs of output) {
          this.temp["Response"] = msgs.speech;
          this.temp["userFlag"] = false;
          this.botMsg.push(this.temp);
          this.translate.get('chatbot_contactUs').subscribe((res: string) => {
            this.contactus = res;
          }); 
          if(this.temp["Response"] === this.contactus){
              this.clickableResponse(this.userMsg);
          };
          this.temp = {};
        }
        this.msg = '';
      });

  } 
  
  else {
    if (this.newUserfirstTime) {
      var requestObj = {
        'query': "welcome",
        'lang': 'en'
      };
      this.newUserfirstTime = false;
    }
    else {
      var requestObj = {
        'query': this.msg,
        'lang': 'en'
      };
    };

    this.netWorkingService.post('/firstTimeUser', requestObj).subscribe(res => {
      const output = res.result.fulfillment.messages;
      this.temp = {};
      this.userMsg = this.msg;
      this.temp["Response"] = this.msg;
      this.temp["userFlag"] = true;
      this.botMsg.push(this.temp);
      this.temp = {};
      this.msg = '';      
      for (var msgs of output) {
        this.temp["Response"] = msgs.speech;
        this.temp["userFlag"] = false;
        this.botMsg.push(this.temp);
        this.translate.get('chatbot_contactUs').subscribe((res: string) => {
          this.contactus = res;
        }); 
        if(this.temp["Response"] === this.contactus){
            this.clickableResponse(this.userMsg);
        };
        this.temp = {};
      }
      this.msg = '';
    });
  }

  }

  clickableResponse(message) {
    this.translate.get('know_about_toybox').subscribe((res: string) => {
      this.knowTYB = res;
    });
    this.translate.get('raise_request').subscribe((res: string) => {
      this.raiseRequest  = res;
    });
    this.translate.get('augmented_reality.').subscribe((res: string) => {
      this.augmentedReality  = res;
    });
    this.translate.get('internet_of_things').subscribe((res: string) => {
      this.internetOfThings  = res;
    });
    this.translate.get('artificial_intelligence').subscribe((res: string) => {
      this.artificialIntelligence  = res;
    });
    this.translate.get('others').subscribe((res: string) => {
      this.allPrototypes  = res;
    });
    this.translate.get('own_exploration').subscribe((res: string) => {
      this.ownExploration  = res;
    });
    this.translate.get('explore_profile').subscribe((res: string) => {
      this.profileExploration  = res;
    });
    this.translate.get('contact_us_yes').subscribe((res: string) => {
      this.contactusYes  = res;
    });
    this.translate.get('concept_builder').subscribe((res: string) => {
      this.conceptBuilder  = res;
    });
    this.translate.get('prototype_factory').subscribe((res: string) => {
      this.prototypeFactory  = res;
    });
    this.translate.get('service_request').subscribe((res: string) => {
      this.serviceRequest  = res;
    });
    this.msg = message;
    switch (message) {
      case this.knowTYB:
        this.router.navigate(['/launch-pad']);
        this.sendMsg();
        break;
      case this.raiseRequest:
        this.router.navigate(['/servicebox']);
        this.sendMsg();
        break;
      case this.augmentedReality:
        this.router.navigate(['/toolbox/Augmented Reality']);
        this.sendMsg();
        break;
      case this.internetOfThings:
        this.router.navigate(['/toolbox/Internet of things']);
        this.sendMsg();
        break;
      case this.artificialIntelligence:
        this.router.navigate(['/toolbox/Artificial Intelligence']);
        this.sendMsg();
        break;
      case this.allPrototypes:
        this.router.navigate(['/toolbox/All Categories']);
        this.sendMsg();
        break;
        case this.ownExploration:
        setTimeout(function() {
          this.Click = true;             
        }, 2000);
        this.sendMsg();        
        break;
        case this.profileExploration:
        this.router.navigate(['/profile']);
        this.sendMsg();
        break;
        case this.contactusYes:
        this.router.navigate(['/contactUs']);
        break;
        case this.conceptBuilder:
        this.sendMsg();
        break;
        case this.prototypeFactory:
        this.sendMsg();
        break;
        case this.serviceRequest:
        this.sendMsg();
        break;
      default:
        this.sendMsg();
        break;
    }
  }

}

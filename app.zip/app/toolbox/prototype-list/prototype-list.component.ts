import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DataService } from '../../shared/data.service';
import { Pipe, PipeTransform } from '@angular/core';
import { LoadingModule } from 'ngx-loading';
import { CommonInterface } from '../../shared/common.interface';
import { ClickOutsideModule } from 'ng-click-outside';
import { Location } from '@angular/common';
import { HostListener } from '@angular/core';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { ScrollToService, ScrollToConfigOptions } from '@nicky-lenaers/ngx-scroll-to';
import { NgxCarousel } from 'ngx-carousel';
import { NetWorkingService } from '../../shared/networking.service';
import { prototype } from 'stream';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
    selector: 'app-prototype-list',
    templateUrl: './prototype-list.component.html',
    styleUrls: ['./prototype-list.component.css'],
    animations: [
        trigger('fade', [
            transition(':enter', [
                style({ transform: 'translateX(100%)' }),
                animate(700)
            ]),
            transition('* => void', [
                animate('0.5s 0.5s ease-out', style({
                    opacity: 0
                }))
            ])
        ])
    ]
})
export class PrototypeListComponent implements OnInit {
    public resetflag = 0;
    scrollYValue: number;
    prototypes: any = [];
    public test = false;
    currentprototype: string;
    indexofproto: any;
    playlistNameHtmlview: any;
    app_icon: any;
    playlist_id: any;
    prototypeToPlaylist: any;
    vipPlaylist = false;
    deletetoast: boolean = false;
    deleteDialog: boolean = false;
    vipplaylists: any;
    public categoryname = '';
    p_id: any;
    public popuploading = false;
    public sortInput = '';
    public domainNames: any[] = [];
    public domainNames1: any[] = [];
    public domainNames2: any[] = [];
    public loading = false;
    playlistGif = [];
    Playlistdialogbox = false;
    backtoplaylist: boolean = false;
    public filter1 = false;
    detailscrolltop = false;
    existingContent = true;
    protoplaylist: any = [];
    public sortval = 'Most Rated';
    filtercount = 0;
    errorMessage = '';
    prototypeSubscription: Subscription;
    prototypeFileName = '';
    chatBotClick = false;
    detailsLength = 0;
    carouselTileLoad = false;
    subfilter = 0;
    count = 0;
    public domainFilter = '';
    public domainFilter1 = '';
    public domainFilter2 = '';
    filtersort = false;
    isValid = false;
    listFlag = true;
    active = false;
    Radioimage = [];
    inactive = false;
    playlistDescription: any;
    filterArray = {
        'domain': [],
        'Technology': [],
        'prototype_type': []
    };
    removeFilterArray = {
        'domain': [],
        'Technology': [],
        'prototype_type': []
    };
    showfilterArray = {
        'domain': [],
        'Technology': [],
        'prototype_type': []
    };
    diffArray = {
        'domain': [],
        'Technology': [],
        'prototype_type': []
    };
    options = {
        year: 'numeric', month: 'short',
        day: 'numeric'
    };
    time: string = new Date().toLocaleString('en-IN', this.options);
    showHide = false;
    prototypeList = [];
    nbar = false;
    value2 = 'domain';
    tabvalue = 'AllPrototypes'
    user: any;
    value = 'raja';
    matchdata = [];
    showDialog = false;
    submitdisable = false;
    adminforms: PrototypeInterface[] = [];
    popupCount = 0;
    initial: any = 0;
    popupCount1 = 0;
    public carouselTile: NgxCarousel;
    carouselTileItems = [];
    public carousel: any[] = [];
    filterItems = [];
    proNames = [];
    currFileName: any;
    sorts = ['Most Rated', 'Title', 'Domain', 'Fidelity', 'Technology'];
    message: string;
    flag: any = false;
    PrototypeListPage: boolean;
    prototypecount: any;
    mail: any;
    playlists: any = [];
    playListProtoId: any;
    Playlistname: any;
    playlistCreated: any;
    playlistName: any;
    playlistFlag = false;
    disablePopup: boolean = false;
    dueDate: any;
    already = false;
    alreadyaddedplaylist = false;
    playlistId: string;
    public triggerScrollTo() {
        const config: ScrollToConfigOptions = {
            target: 'Library',
            duration: 1500,
            easing: 'easeOutElastic',
            offset: 0
        };
        this._scrollToService.scrollTo(config);
        this.detailscrolltop = false;
    }
    constructor(private networkingService: NetWorkingService, private route: ActivatedRoute, public router: Router,
        private data: DataService, private _scrollToService: ScrollToService, private _location: Location) {
    }

    ngOnInit() {
        this.loading = true;
        this.mail = JSON.parse(localStorage.getItem('user'));
        this.prototypecount = localStorage.getItem('prototypecount');
        this.flag = false;
        this.user = JSON.parse(localStorage.getItem('user'));
        this.route.params.subscribe(
            (params: Params) => {
                this.categoryname = params['id'];
            }
        );
        this.carouselTile = {
            grid: {
                xs: 2,
                sm: 3,
                md: 3,
                lg: 5,
                all: 0
            },
            slide: 5,
            speed: 400,
            custom: 'banner',
            load: 2,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
        this.route.params.subscribe(
            (params) => {
                this.prototypeFileName = params['id'];
                this.currFileName = {
                    fileName: this.prototypeFileName,
                    userGroup: this.user.userGroup,
                    curuser: this.user.email
                };
                this.networkingService.post('/search/prototypesFilter', this.currFileName).subscribe(
                    (prototypes) => {
                        console.log("----------------------------------------------", prototypes)
                        this.loading = false;
                        this.prototypes = prototypes;
                        this.prototypeList = prototypes;
                        this.playlistGif.length = this.prototypes.length;
                        for (var i = 0; i < this.playlistGif.length; i++) {
                            this.playlistGif[i] = "test"
                            console.log(this.playlistGif[i])
                        }
                        for (const i in this.prototypes) {
                            if (prototypes.hasOwnProperty(i)) {
                                this.count++;
                                this.domainNames.push(this.prototypes[i].Domain);
                                this.domainNames1.push(this.prototypes[i].Technology);
                                this.domainNames2.push(this.prototypes[i].prototype_type);
                            }
                        }
                        const a = this.domainNames;
                        const b = this.domainNames1;
                        const c = this.domainNames2;
                        this.domainNames = a.filter(function (item, pos) {
                            return a.indexOf(item) === pos;
                        });
                        this.domainNames1 = b.filter(function (item, pos) {
                            return b.indexOf(item) === pos;
                        });
                        this.domainNames2 = c.filter(function (item, pos) {
                            return c.indexOf(item) === pos;
                        });
                    });
            });
        const CurrentID = {
            fileName: this.mail.id,
            admin: this.mail.admin
        };
        this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
            (prototypes) => {
                this.proNames = prototypes;
            });
        this.data.currentMessage.subscribe(message => {
            console.log(message, "---------------------------------------------------------->");

            if (message !== 'AllPrototypes' && message !== undefined) {
                console.log("parseInt(message[message.length - 1]) <= 2", parseInt(message[message.length - 1]) <= 2);
                if (parseInt(message[message.length - 1]) <= 2) {
                    this.prototypes = message[1];
                } else {
                    var Message = {
                        filteredprotos: {type: []},
                        filteredplaylist: {type: []}
                    }
                    message = JSON.stringify(message);                    
                    Message = JSON.parse(message);
                    console.log('type', typeof Message)
                    this.prototypes = Message.filteredprotos;

                    if (Message.filteredplaylist) {
                        this.protoplaylist = Message.filteredplaylist;
                    }else{
                        this.protoplaylist.length = 0;
                    }
                }
            }
        });

        this.data.prototype.subscribe(Response => {
            console.log("Response-playlist", Response);
            let response
            response = JSON.stringify(Response);
            response = JSON.parse(response);
            if (response.name && response.id)
                this.backtoplaylist = true;
            this.playlistName = response.name;
            this.playlist_id = response.id;
            console.log(this.playlist_id, "playlistId")
        });
    }
    tabchange(value) {
        console.log(value, 'value');
        if (value == 'MyPrototypes') {
            const CurrentID = {
                fileName: this.mail.id,
                admin: this.mail.admin
            };
            this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
                (prototypes) => {
                    this.loading = false;
                    this.proNames = prototypes;
                });
        }
        this.tabvalue = value;
    }
    toggle(p_id) {
        this.p_id = p_id;
        this.deleteDialog = !this.deleteDialog;
    }
    delete() {
        console.log("ssssssssssssssssssssssssssssssssssssssssssssssssss")
        this.networkingService.delete('/api/prototypes/' + this.p_id)
            .subscribe(adminform => {
                this.deletetoast = true;
                const CurrentID = {
                    fileName: this.mail.id
                };
                this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
                    (prototypes) => {
                        this.proNames = prototypes;

                    });
                this.deletetoast = true;
                setTimeout(() => {
                    this.deletetoast = false;
                }, 7000);
            });

        this.deleteDialog = !this.deleteDialog;
        window.scrollTo(0, 0);


    }
    view(id, category, prototype) {
        this.data.changeMessage('MyPrototypes');
        this.data.changePrototype(prototype);
        if (category.indexOf(' ') !== -1) {
            category = category.split(' ');
            category = category[0] + '%20' + category[1];
        }
        this.router.navigateByUrl('/toolbox/' + category + '/' + id);
        window.scrollTo(0, 0);
        if (prototype.status == 'Approved') {
            const reqObj = {
                view: 'false',
            };
            this.networkingService.put('/api/changeApprovedViewStatus/' + prototype._id, reqObj).subscribe((Response) => {

            });

        }
    }
    closesignout() {
        this.deleteDialog = !this.deleteDialog;
    }
    changeShowStatus() {
        this.active = !this.active;
        this.filterItems = [];
        this.showHide = !this.showHide;
        this.filter1 = false;
        if (this.popupCount === 2 && this.active === true) {
            this.popupCount = 0;
            this.showHide = true;
        } else if (this.active === false) {
            this.showHide = true;
        }
        if (this.showfilterArray.domain.length === 0 && this.showfilterArray.Technology.length === 0 &&
            this.showfilterArray.prototype_type.length === 0) {
            this.active = true;
        } else {
            this.active = false;
        }
    }
    edit() {
        for (let j = 0; j < this.proNames.length; j++) {
            if (this.proNames[j].status === 'Draft') {
                const reqObj = {
                    'query': this.proNames[j].id,
                    'lang': 'en'
                };
                this.networkingService.post('/api/editPrototype', reqObj)
                    .subscribe(adminform => {
                        this.adminforms.push(adminform);
                        this.data.sendPrototypeData(adminform);
                        this.router.navigateByUrl('/toolbox/createPrototype');
                    });
            }
        }
    }
    Edit(id) {
        var obj = {
            "query": id,
            "action": "view",
            "lang": "en"
        }
        //   this.data.setadminserviceflag("true");
        this.router.navigateByUrl('/toolbox/createPrototype?id=' + id + "&action=view");
        const reqObj = {
            'query': id,
            'lang': 'en'
        };
    }
    modalPopUp() {
        for (let j = 0; j < this.proNames.length; j++) {
            this.showDialog = !this.showDialog;
            if (this.proNames[j].status === 'Draft') {
                this.networkingService.delete('/api/prototypes/' + this.proNames[j].id)
                    .subscribe(adminform => {
                        const CurrentID = {
                            fileName: this.mail.id
                        };
                    });
            }
        }
    }
    // addProto() {
    //     this.data.sendPrototypeData(null);
    //     this.data.changeMessage('addproto');
    //     const CurrentID = {
    //         fileName: this.mail.id
    //     };
    //     this.networkingService.post('/api/loadAddedPrototypes/', CurrentID)
    //         .subscribe(
    //             (prototypes) => {
    //                 this.proNames = prototypes;
    //                 if (this.proNames.length !== 0) {
    //                     for (let j = 0; j < this.proNames.length; j++) {
    //                         if (this.proNames[j].status === 'Draft') {
    //                             this.showDialog = true;
    //                         }
    //                     }
    //                     if (this.showDialog === false) {
    //                         this.router.navigateByUrl('/toolbox/createPrototype');
    //                     }
    //                 } else {
    //                     this.router.navigateByUrl('/toolbox/createPrototype');
    //                 }
    //             });

    // }
    addProto() {
        this.data.sendPrototypeData(null);
        // this.data.changeMessage('addproto');
        this.data.changeMessage('false');
        this.router.navigateByUrl('/toolbox/createPrototype');
    }
    checkAccess(accessRestriction) {
        console.log(this.user.email)
        console.log(accessRestriction)
        if (accessRestriction.includes(this.user.email) || accessRestriction.length == 0) {
            console.log(this.user.email)
            return true;

        }
        else {
            console.log("false")
            return false;
        }
    }
    onClickedOutside(e: Event) {
        this.popupCount++;
        if (this.popupCount === 1) {
            this.active = true;
            this.inactive = false;
            this.filter1 = false;
            this.resetflag = 0;
        } else if (this.popupCount === 2) {
            this.resetflag = 0;
            if (this.showfilterArray.domain.length > 0
                || this.showfilterArray.Technology.length > 0 || this.showfilterArray.prototype_type.length > 0) {
                this.active = true;
            } else {
                this.active = false;
            }
            this.showHide = !this.showHide;
            this.popupCount = 0;
        }
        this.shareFilter();
    }
    onClickOutside(e: Event) {
        this.popupCount++;
        if (this.popupCount === 2) {
            this.filter1 = !this.filter1;
            this.popupCount = 0;
        }
    }
    onClickOutside1(e: Event) {
        this.popupCount1++;
        if (this.popupCount1 === 1) {
            this.filter1 = false;
            this.popupCount1 = 0;
        }
    }
    clickfilter() {
        this.filter1 = !this.filter1;
        this.active = false;
        this.showHide = false;
    }
    reset() {
        for (const item in this.filterArray) {
            if (this.filterArray.hasOwnProperty(item)) {
                this.filterArray[item].length = 0;
            }
        }
        this.resetflag = 1;
        this.showHide = true;
    }
    gotoPlaylist() {
        this.existingContent = false;
        this.playlists.length = 0;
    }
    vipPlaylistCheck() {
        this.vipPlaylist = !this.vipPlaylist;
    }
    Playlistdialog(proto, id, i) {
        this.Radioimage = [];
        this.Playlistname = '';
        this.playlistDescription = '';
        this.popuploading = true;
        this.playListProtoId = id;
        console.log("playlistnamesdf", this.playlist_id)
        if (this.playlistName) {
            this.popuploading = false;
            this.prototypeToPlaylist = {
                playlistId: this.playlist_id,
                id: this.playListProtoId,
                userId: this.user.id
            }
            this.prototypeToBeAdded();
            if (i || i === 0) {
                console.log('time')
                this.playlistGif[i] = './assets/images/demo_1.gif';
                // this.playlistGif[i]='';                            
            }
            console.log("gaanehs", this.playlistGif[i])
            this.disablePopup = true;

        }
        else {
            var Obj = {
                user: this.user.id
            }
            this.networkingService.post('/users/playlist/', Obj).subscribe(Response => {
                this.popuploading = false;
                // console.log(Response,"arun")
                this.playlists = Response.playlist;
                // console.log("this.playlists",this.playlists)
                this.Radioimage.length = this.playlists.length
            });
            this.playlist_id = this.playlist_id;
            this.currentprototype = proto;
            this.Playlistdialogbox = true;
            this.Playlistname = '';
        }

    }
    // Playlistdialog(proto, id, appicon) {
    //     this.popuploading = true;
    //     this.playListProtoId = id;
    //     if (this.playlistName) { 
    //         this.popuploading = false;
    //         this.disablePopup = true;       
    //         this.addToPlaylist(this.playlistName,this.playlistId);         
    //     } else {
    //         var Obj = {
    //         user: this.user.id
    //         }
    //         this.networkingService.post('/users/playlist', Obj).subscribe(Response => {
    //             this.popuploading = false;
    //             this.playlists = Response.playlist
    //         });
    //         this.app_icon = appicon;
    //         this.currentprototype = proto;
    //         this.Playlistdialogbox = true;
    //         this.Playlistname = '';
    //     }
    // }
    submitData() {
        const playListObj = {
            uploadDate: this.time,
            playlistName: this.Playlistname,
            prototypeId: this.playListProtoId,
            playlistDescription: this.playlistDescription,
            vipPlaylist: this.vipPlaylist,
            userRole: this.user.userGroup,
            userId: this.user.id,
            userName: this.user.name,
            dueDate: this.getserviceday(this.time),
            request_id: "REQ" + Math.floor(100000 + Math.random() * 900000)
        }
        this.networkingService.post('/users/createPlaylist', playListObj).subscribe(Response => {
            this.playlistCreated = Response
            this.playlistNameHtmlview = Response.name;
            if (this.playlistCreated == "already added") {
                this.alreadyaddedplaylist = true;
                setTimeout(() => {
                    this.alreadyaddedplaylist = false;
                }, 7000);
            }
            if (this.playlistCreated != "already added") {
                this.playlistFlag = true;
                setTimeout(() => {
                    this.playlistFlag = false;
                }, 7000);
                this.Playlistdialogbox = !this.Playlistdialogbox;
            }
        });
        this.playlistDescription = '';
    }
    close() {
        this.active = false;
        this.popupCount = 0;
        this.showHide = !this.showHide;
        this.shareFilter();
    }
    shareFilter() {
        for (const item in this.showfilterArray) {
            if (this.showfilterArray.hasOwnProperty(item)) {
                this.filterArray[item].length = 0;
                for (let j = 0; j <= this.showfilterArray[item].length; j++) {
                    this.filterArray[item].push(this.showfilterArray[item][j]);
                }
            }
        }
    }
    filter(value) {
        this.value2 = value;
    }
    filterDomain(value, type, event) {
        console.log("KK")
        if (event.toElement.checked) {
            this.filterArray[type].push(value);
        } else {
            const index = this.removeFilterArray[type].indexOf(value);
            if (index <= -1) {
                this.removeFilterArray[type].push(value);
            }
        }
    }
    removeSelectedFilter(type, item) {
        this.active = false;
        const index = this.filterArray[type].indexOf(item);
        this.filterArray[type].splice(index, 1);
        this.sendfilterdata();
        if (this.showfilterArray.domain.length === 0 && this.showfilterArray.Technology.length === 0 &&
            this.showfilterArray.prototype_type.length === 0) {
            this.active = true;
        }
    }
    /*----------------------sendfilterdata starts here---------------------*/

    sendfilterdata() {
        this.nbar = true;
        this.showHide = false;
        this.active = true;
        this.popupCount = 0;
        for (const item in this.removeFilterArray) {
            if (this.removeFilterArray[item].length > 0) {
                for (let i = 0; i < this.removeFilterArray[item].length; i++) {
                    const index = this.filterArray[item].indexOf(this.removeFilterArray[item][i]);
                    if (index > -1) {
                        this.filterArray[item].splice(index, 1);
                    }
                }
                this.removeFilterArray[item].length = 0;
            }
        }
        for (const item in this.filterArray) {
            if (this.filterArray[item].length > 0) {
                this.showfilterArray[item].length = 0;
                for (let i = 0; i < this.filterArray[item].length; i++) {
                    if (this.filterArray[item][i]) {
                        this.showfilterArray[item].push(this.filterArray[item][i]);
                    }
                }
            }
        }
        this.networkingService.post('/search/getFilterPrototypes', [this.showfilterArray, this.prototypeFileName]).subscribe(
            (prototypes) => {
                this.loading = false;
                this.prototypes = prototypes;
                if (this.showfilterArray.domain.length === 0 && this.showfilterArray.Technology.length === 0 &&
                    this.showfilterArray.prototype_type.length === 0) {
                    this.active = !this.active;
                }
            });
        if (this.resetflag === 1) {
            for (const item in this.showfilterArray) {
                if (this.showfilterArray.hasOwnProperty(item)) {
                    this.showfilterArray[item].length = 0;
                }
            }
        }
    }
    /*----------------------sendfilterdata ends here---------------------*/
    removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    /*-------------------GLOBAL SEARCH ------------------*/

    onPrototypeClick(prototypeId) {
        this.router.navigate([prototypeId], {
            relativeTo: this.route
        });
    }
    gotoPrototypeDetail(prototypeId, prototype) {
        if (this.Playlistdialogbox !== true && this.disablePopup != true) {
            console.log("prototype", prototype)
            this.data.changePrototype(prototype);
            this.data.changeMessage('AllPrototypes');
            this.router.navigate([prototypeId], {
                relativeTo: this.route
            });
            window.scrollTo(0, 0);
        }
    }
    backToCategoryList() {
        this.loading = false;
        localStorage.setItem("playlistName", this.playlistName)
        this.data.changeMessage('AllPrototypes')
        this._location.back();
    }
    lengths(a) {
        this.detailsLength = a;
    }
    ngOnDestroy() {
        // this.data.changePrototype('');

        // this.data.changePlayListName('');
        // this.data.changeFlag2('');
        // if (!this.data.flag) { }
    }
    sortBySelection(val) {
        this.sortval = val;
        this.sortInput = val;
    }
    deleteclose() {
        this.playlistFlag = !this.playlistFlag;
    }
    closeplaylist() {
        this.Playlistdialog(this.currentprototype, this.playListProtoId, this.indexofproto);
        // this.Playlistdialogbox = false;
        this.Playlistname = '';
    }
    closeplaylistdialog() {
        this.Playlistdialogbox = false;
    }
    getserviceday(gettime) {
        var d = new Date(gettime);
        this.dueDate = new Date(d.setDate(d.getDate() + 3)).toLocaleString('en-IN', this.options);
        return this.dueDate;
    }
    addToPlaylist(playlistName, i, playlist_id) {
        this.playlistNameHtmlview = playlistName;
        for (let k = 0; k < this.Radioimage.length; k++) {
            if (k == i) {
                this.Radioimage[k] = true;
            }
            else {
                this.Radioimage[k] = false;
            }
        }
        this.prototypeToPlaylist = {
            playlistId: playlist_id,
            id: this.playListProtoId
        }
    }
    uncheckPlaylist(playlistName, i) {
        this.Radioimage[i] = false;
    }
    prototypeToBeAdded() {
        console.log("working", this.prototypeToPlaylist)
        this.networkingService.put('/users/updatePlaylist', this.prototypeToPlaylist).subscribe((Response) => {
            console.log(Response, "ResponseResponse")
            if (Response == "already added") {
                this.already = true;
                setTimeout(() => {
                    this.already = false;
                }, 5000);
            }

            else {

                this.playlistFlag = true;
                setTimeout(() => {
                    this.playlistFlag = false;
                }, 5000);
                if (this.Playlistdialogbox)
                    this.Playlistdialogbox = !this.Playlistdialogbox;

            }

        });
        this.prototypeToPlaylist = {};
    }
    // addToPlaylist(playlistName,playlistId) {
    //     this.playlistNameHtmlview = playlistName;
    //     var obj = {
    //         playlistName: playlistId,
    //         id: this.playListProtoId
    //     }
    //     this.networkingService.put('/users/updatePlaylist', obj).subscribe((Response) => {
    //         if (Response == "already added") {
    //             this.already = true;
    //             setTimeout(() => {
    //                 this.already = false;
    //             }, 7000);
    //         }
    //         else {
    //             this.playlistFlag = true;
    //             setTimeout(() => {
    //                 this.playlistFlag = false;
    //             }, 7000);
    //             if (this.Playlistdialogbox)
    //                 this.Playlistdialogbox = !this.Playlistdialogbox;
    //         }

    //     });
    // }
    @HostListener('window:scroll', [])
    onWindowScroll() {
        this.scrollYValue = window.pageYOffset;
        console.log("scroll num", this.scrollYValue)
        if (this.scrollYValue > 150) {
            this.detailscrolltop = true;
        } else {
            this.detailscrolltop = false;
        }
    }
}
/*-------------------GLOBAL SEARCH ------------------*/

@Pipe({
    name: 'categoryPipe'
})
export class CategoryPipe implements PipeTransform {
    transform(arr: any, filterId: any, domainFilter: any, domainFilter1: any, domainFilter2: any): any {
        if (filterId === 'All Categories' && !domainFilter) {
            return arr;
        }
        let tempArr = arr.filter(function (item) {
            return item.category_name === filterId;
        });
        if (filterId !== 'All Categories') {
            if (domainFilter !== '') {
                tempArr = tempArr.filter(function (item) {
                    return (item.domain === domainFilter);
                });
            }
            if (domainFilter1 !== '') {
                tempArr = tempArr.filter(function (item) {
                    return (item.Technology === domainFilter1);
                });
            }
            if (domainFilter2 !== '') {
                tempArr = tempArr.filter(function (item) {
                    return (item.prototype_type === domainFilter2);
                });
            }
        }
        if (filterId === 'All Categories') {
            if (domainFilter !== '' && domainFilter1 === '' && domainFilter2 === '') {
                tempArr = arr.filter(function (item) {
                    return (item.domain === domainFilter);
                });
            }
            if (domainFilter1 !== '' && domainFilter !== '' && domainFilter2 === '') {
                tempArr = arr.filter(function (item) {
                    return (item.domain === domainFilter);
                });
                tempArr = tempArr.filter(function (item) {
                    return (item.Technology === domainFilter1);
                });
            }
            if (domainFilter1 !== '' && domainFilter !== '' && domainFilter2 !== '') {
                tempArr = arr.filter(function (item) {
                    return (item.domain === domainFilter);
                });
                tempArr = tempArr.filter(function (item) {
                    return (item.Technology === domainFilter1);
                });
                tempArr = tempArr.filter(function (item) {
                    return (item.prototype_type === domainFilter2);
                });
            }
        }
        const length = tempArr.length;
        return tempArr;
    }
}
@Pipe({
    name: 'SortPipe'
})
export class SortPipe implements PipeTransform {
    transform(arr: any, filterId: any, sortInput: any): any {
        const tempSortArr = [];
        for (const i in arr) {
            if (arr.hasOwnProperty(i)) {
                tempSortArr[i] = arr[i];
            }
        }
        if (sortInput !== '') {
            if (sortInput === 'Title') {
                tempSortArr.sort(function (a, b) {
                    const nameA = a.title.toLowerCase(),
                        nameB = b.title.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                return tempSortArr;
            } else if (sortInput === 'Domain') {
                tempSortArr.sort(function (a, b) {
                    const nameA = a.Domain.toLowerCase(),
                        nameB = b.Domain.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                return tempSortArr;
            } else if (sortInput === 'Fidelity') {
                tempSortArr.sort(function (a, b) {
                    const nameA = a.prototype_type.toLowerCase(),
                        nameB = b.prototype_type.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                return tempSortArr;
            } else if (sortInput === 'Technology') {
                tempSortArr.sort(function (a, b) {
                    const nameA = a.Technology.toLowerCase(),
                        nameB = b.Technology.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                return tempSortArr;
            } else if (sortInput === 'Most Rated') {
                tempSortArr.sort(function (a, b) {
                    const nameA = a.rating,
                        nameB = b.rating;
                    if (nameA > nameB) {
                        return -1;
                    }
                    if (nameA < nameB) {
                        return 1;
                    }
                    return 0;
                });
                return tempSortArr;
            }
        }
        return tempSortArr;
    }
}

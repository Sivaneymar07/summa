import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-toolbox',
  templateUrl: './toolbox.component.html',
  styleUrls: ['./toolbox.component.css']
})
export class ToolboxComponent implements OnInit {

  constructor( private route: ActivatedRoute, private router: Router) {

   }

  ngOnInit() {

  }
  onWorkSpaceClicked() {
    this.router.navigate(['../toybox'], {relativeTo: this.route});
  }
}

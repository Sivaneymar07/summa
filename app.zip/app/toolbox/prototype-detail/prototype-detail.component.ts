import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { NgxCarousel } from 'ngx-carousel';
import { Pipe, PipeTransform, HostListener } from '@angular/core';
import { DataService } from '../../shared/data.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { CommonInterface } from '../../shared/common.interface';
import { ClickOutsideModule } from 'ng-click-outside';
import { ScrollToService, ScrollToConfigOptions } from '@nicky-lenaers/ngx-scroll-to';
import { NetWorkingService } from '../../shared/networking.service';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { RatingModule } from 'ngx-rating';
import { Location, NgStyle } from '@angular/common';
import { CompleterService, CompleterData } from 'ng2-completer';

@Component({
    selector: 'app-prototype-detail',
    templateUrl: './prototype-detail.component.html',
    styleUrls: ['./prototype-detail.component.css']
})
export class PrototypeDetailComponent implements OnInit, OnDestroy {
    public reviewrs: Array<any>;
    public ratings: Array<any>;
    public rating: Array<number>;
    public reviewcarouselTile: NgxCarousel;
    public carouselTileTwo11: NgxCarousel;
    public screenshotscarouselTile: NgxCarousel;
    public reviewersortInput = '';
    Playlistdialogbox = false;
    alreadyaddedplaylist = false;
    public popuploading = false;
    playlistNameHtmlview: any;
    starsCount: number;
    rateFlags = false;
    userComments = '';
    dueDate: any;
    userstarsCount: number;
    playlistDescription: string;
    playlists = [];
    shareduserID: any;
    vipPlaylist = false;
    groupName: any;
    term = '';
    already = false;
    sharePrototype = false;
    shareDialogbox = false;
    existingContent = true;
    Playlistname: any;
    playlistCreated: any;
    playlistFlag = false;
    numb: number;
    TagStack: string;
    rateShow = false;
    defaultrateShow = false;
    tagStackArray = [];
    sharedUserDL = [];
    tagStackArrayDL = [];
    tagstackfinaldivboolean = false;
    userdoesntexists = false;
    showHide: any;
    shareProtoDL = false;
    dataService: CompleterData;
    user: any;
    users: any;
    currFileName: any;
    // savetoast = false;
    savetoasts = false;
    detailfilter = false;
    GetPrototypeClick = false;
    detailscrolltop = false;
    isActive = false;
    public reviewsortval = 'Best Rated';
    public filter = false;
    favouritiesVisible = [];
    favouriteClickedArray = [];
    sorts = ['Best Rated', 'Least Rated', 'Recent'];
    prototypeId = '';
    loading: boolean;
    rev = {};
    value = false;
    dlink = false;
    reviewShow = false;
    prototypeSubscription: Subscription;
    temparra = [];
    filterShareUserArray = [];
    Sharedusers = [];
    token: string;
    prototypeToPlaylist: any;
    time = new Date();
    reviewDate: any;
    url;
    tabtogglevalue: any = 'description';
    Radioimage = [];
    avgRating: number;
    adminforms: PrototypeInterface[] = [];
    adminform: PrototypeInterface;
    prototypes: CommonInterface[] = [];
    prototype: CommonInterface;
    mail: any;
    rateFlag: any;
    newWin: any;
    prototy: any;
    reviewArray: any;
    showDialog = false;
    initial: any = 0;
    submitdisable = false;
    slideConfig = {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        centerMode: true,
        focusOnSelect: true,
        centerPadding: '23px',
        arrows: false
    };
    formateDate(dateValue) {
        const dropdowndate = dateValue.toLocaleString('en-US', { hour12: false }).split(' ');
        let mdy = dropdowndate[0];
        mdy = mdy.split('/');
        const month = parseInt(mdy[0]);
        const day = parseInt(mdy[1]);
        const year = parseInt(mdy[2]);
        const formattedDate = month + '-' + day + '-' + year;
        const tempDate = formattedDate.split('-').join('/');
        return tempDate;
    }
    options1 = {
        year: 'numeric', month: '2-digit',
        day: '2-digit',
    };
    options = {
        year: 'numeric', month: 'short',
        day: 'numeric'
    };
    public triggerScrollTo() {
        const config: ScrollToConfigOptions = {
            target: 'Library',
            duration: 1500,
            easing: 'easeOutElastic',
            offset: 0
        };
        this._scrollToService.scrollTo(config);
        this.detailscrolltop = false;
    }

    constructor(private networkingService: NetWorkingService, private _location: Location,
        private data: DataService, private completerService: CompleterService, private route: ActivatedRoute,
        private router: Router, private _scrollToService: ScrollToService) { };

    ngOnInit() {
        this.userComments = '';
        this.userstarsCount = 0;
        this.loading = true;
        this.showHide = true;
        const route = this.router.url;
        const splitRoute = route.split('/');
        this.user = JSON.parse(localStorage.getItem('user'));
        this.reviewcarouselTile = {
            grid: {
                xs: 2,
                sm: 2,
                md: 2,
                lg: 2,
                all: 0
            },
            slide: 2,
            speed: 400,
            animation: 'lazy',
            point: {
                visible: true
            },
            loop: true,
            load: 2,
            touch: true,
            easing: 'ease'
        };
        this.screenshotscarouselTile = {
            grid: {
                xs: 1,
                sm: 1,
                md: 1,
                lg: 1,
                all: 0
            },
            slide: 1,
            speed: 400,
            animation: 'lazy',
            point: {
                visible: true
            },
            loop: true,
            load: 1,
            touch: true,
            easing: 'ease'
        };
        this.carouselTileTwo11 = {
            grid: { xs: 2, sm: 2, md: 2, lg: 2, all: 280 },
            slide: 5,
            speed: 400,
            animation: 'lazy',
            load: 1,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
        this.mail = JSON.parse(localStorage.getItem('user'));
        this.data.prototype.subscribe(detail => {
            const proto = JSON.stringify(detail);
            this.prototype = JSON.parse(proto);
            this.avgRating = this.prototype.rating;
            this.loading = false;
            if (this.prototype) {

                this.reviewrs = this.prototype.review;
                if (this.prototype.title) {
                    console.log('here')
                    this.temparra = this.removeDuplicates(this.reviewrs, 'userrating');
                }
                localStorage.setItem('prototype', JSON.stringify(this.prototype));
                this.starsCount = this.prototype.rating;
            } else {
                this.prototype = JSON.parse(localStorage.getItem('prototype'));
                this.reviewrs = this.prototype.review;
                if (this.prototype.title) {
                    console.log('here')

                    this.temparra = this.removeDuplicates(this.reviewrs, 'userrating');
                }
                this.starsCount = this.prototype.rating;
            }

        });
        this.networkingService.post('/proto/updateViewCount/' + this.prototype.id, { views: this.prototype.uniqueViewsCount }).subscribe((response) => {
            // this.data.changePrototype(response);
        });
        this.route.params.subscribe(
            (params: Params) => {
                this.rateFlags = false;
                this.userstarsCount = 0;
                this.prototypeId = params['prototypeId'];
                const reviewQuery = { prototypeID: this.prototypeId };
                this.networkingService.post('/search/getReview', reviewQuery).subscribe(data => {
                    this.reviewArray = data[0].review;
                    this.prototype.rating = data[0].rating;
                    this.avgRating = this.prototype.rating;
                });
            });
        this.route.params.subscribe(
            (params: Params) => {
                this.prototypeId = params['prototypeId'];
                this.isActive = false;
                this.mail = JSON.parse(localStorage.getItem('user'));
                var obj = { mail: this.mail.email }
                this.networkingService.post('/users/getfavorite', obj).subscribe((favourities) => {
                    this.favouritiesVisible = favourities.favorites;
                    for (let i = 0; i < this.favouritiesVisible.length; i++) {
                        if (this.favouritiesVisible[i].id === this.prototypeId) {
                            this.isActive = true;
                        }
                    }

                });
            });

        var obj = { mail: this.mail.email }
        this.networkingService.post('/users/shareUsers', obj).subscribe((users) => {
            users.forEach(user => {
                this.Sharedusers.push(user.email);
            })
            var index = this.Sharedusers.indexOf(this.user.email);
            this.Sharedusers.splice(index, 1);
            this.dataService = this.completerService.local(this.Sharedusers);
        });
        this.networkingService.post('/users/shareUsersDL', obj).subscribe((users) => {
            users.forEach(user => {
                if (user.userGroupName) {
                    this.Sharedusers.push(user.userGroupName);
                }
                this.sharedUserDL.push(user);
            })
        });
    }
    dialogFlow() {
        const requestObj = {
            'query': 'Hi',
            'lang': 'en'
        };
        this.networkingService.post('/msg5', requestObj).subscribe(res => {
        });
    }
    sharePrototypePopup() {
        this.tagStackArray = [];
        this.TagStack = '';
        this.groupName = '';
        this.filterShareUserArray = [];
        this.dlink = false;
        this.shareDialogbox = !this.shareDialogbox;
    }
    tagStackdiv(event) {
        const emailobject = { email: this.TagStack };
        let checkDL = this.TagStack.includes('@');
        if (checkDL) {
            if (!this.tagStackArray.includes(this.TagStack)) {
                var obj = this.Sharedusers.filter((a) => {
                    if (a == this.TagStack) {
                        this.tagStackArray.push(this.TagStack);
                        return a;
                    }
                })
            }
            this.TagStack = '';
        } else {
            const obj = this.sharedUserDL.filter(a => {
                if (a.userGroupName == this.TagStack) {
                    this.tagStackArray.push(this.TagStack);
                    return a;
                }
            })
            obj.forEach(obj => {
                obj.emailID.forEach(email => {
                    this.tagStackArrayDL.push(email);
                })
            })
            if (this.tagStackArray.length >= 2) {
                this.dlink = true;
            }
            this.TagStack = '';
        }
    }
    tagstackfinaldiv() {
        this.tagstackfinaldivboolean = true;
        this.showHide = false;
    }
    closetech(item) {
        const index = this.tagStackArray.indexOf(item);
        this.tagStackArray.splice(index, 1);
    }
    share() {
        if (this.tagStackArray.length < 2) {
            this.dlink = false;
            this.shareDialogbox = !this.shareDialogbox;
        }
        if (this.tagStackArray.length >= 2) {
            this.dlink = true;
        }
        this.tagStackArray.forEach(obj => {
            if (!(obj.includes('@'))) {
                var index = this.tagStackArray.indexOf(obj);
                this.tagStackArray.splice(index, 1);
                this.tagStackArrayDL.forEach(obj => {
                    this.tagStackArray.push(obj);
                })
            }
        })
        this.filterShareUserArray = this.tagStackArray;
        var obj = {
            array: this.filterShareUserArray,
            protoid: this.prototype.id,
            type: 'Prototype',
            GroupName: this.groupName,
            shareCount: this.prototype.shareCount
        }
        const notedate = new Date(Date.now());
        const newnotedate = notedate
        this.networkingService.post('/users/savesharedUsers', obj).subscribe(data => {
            this.shareduserID = data.id;
            var adminFormNotification
            if (this.filterShareUserArray.length >= 1) {
                for (let i = 0; i < this.filterShareUserArray.length; i++) {
                    adminFormNotification = {
                        email: this.filterShareUserArray[i],
                        ref_id: this.prototype.id,
                        notificationtag: 'Prototype',
                        prototypeName: this.prototype.title,
                        message: '',
                        action: this.user.email,
                        status: 'shared',
                        notificationDate: newnotedate
                    };
                    this.networkingService.post('/users/notification', adminFormNotification).subscribe((res) => {
                    });
                }
            } else {
                adminFormNotification = {
                    email: this.filterShareUserArray,
                    ref_id: this.prototype.id,
                    notificationtag: 'Prototype',
                    prototypeName: this.prototype.title,
                    message: '',
                    action: this.user.email,
                    status: 'shared',
                    notificationDate: newnotedate
                };
                this.networkingService.post('/users/notification', adminFormNotification).subscribe((res) => {

                });
            }
            this.sharePrototype = true;
            setTimeout(() => {
                this.sharePrototype = false;
            }, 7000);
        });
    }
    dlNameShare() {
        var obj = {
            usergroupname: this.groupName,
            shareduserID: this.shareduserID
        }
        this.networkingService.post('/users/dlnameshare', obj).subscribe((res) => {
            this.dlink = false;
            this.shareDialogbox = false;
            this.Playlistdialogbox = false;
            this.tagStackArray = [];
            this.TagStack = '';
        });
        this.shareProtoDL = true;
        setTimeout(() => {
            this.shareProtoDL = false;
        }, 7000);
    }
    GetFavouriteClick() {
        this.isActive = !this.isActive;
        const requestObj = {
            id: this.prototypeId,
            emailId: this.mail.email,
            userId: this.mail.id,
            protoId: this.prototype.id,
            user_id: this.prototype.user_id,
            title: this.prototype.title,
            userName: this.mail.name,
            likesCount: this.prototype.likesCount,
        };
        if (this.isActive) {
            // this.savetoast = true;
            // setTimeout(() => {
            //     this.savetoast = false;
            // }, 7000);
            window.scrollTo(0, 0);
            this.networkingService.post('/users/favorite', requestObj).subscribe(data => {
                console.log(data)
                this.data.changePrototype(data);
            });
        } else {
            this.networkingService.post('/users/deletefavorite/', requestObj).subscribe(data => {
                this.data.changePrototype(data);

            });
        }
    }
    cancelratingpopup() {
        this.userComments = '';
        this.userstarsCount = 0;
        this.rateShow = false;
    }
    canceldefaultrateShowpopup() {
        this.userComments = '';
        this.userstarsCount = 0;
        this.defaultrateShow = false;
    }
    ignore(event) {
        if (event.target.checked) {
            this.rateFlags = true;
        } else {
            this.rateFlags = false;
        }
    }
    rateReview() {
        this.rateShow = true;
        this.userComments = '';
        this.userstarsCount = 0;
    }
    rateCommentPopup(url) {
        this.userComments = '';
        this.userstarsCount = 0;
        const credentials = {
            username: 'guacadmin',
            password: 'guacadmin',
            token: this.token
        };
        this.networkingService.post('/api/guaca', credentials)
            .subscribe(res => {
                this.token = res;
                this.newWin = window.open(url + this.token, '_blank');
                this.mail = JSON.parse(localStorage.getItem('user'));
                const rateObj = { mail: this.mail.email };
                if (this.newWin) {
                    this.networkingService.post('/users/getrate/', rateObj).subscribe(data => {
                        if (data) {
                            this.rateFlag = data.rateReview;
                            for (var i = 0; i < this.rateFlag.length; i++) {
                                if (this.prototypeId == this.rateFlag[i]) {
                                    this.rateFlags = true;
                                }
                            }
                        }
                        if (!this.rateFlags) {
                            this.defaultrateShow = true;
                        }

                    });
                }
            });
        this.networkingService.post('/proto/previewCount/' + this.prototype.id, { preview: this.prototype.previewCount }).subscribe((response) => {

        });
    }
    chatbotRatingpopup() {
        this.userComments = '';
        this.userstarsCount = 0;
        this.mail = JSON.parse(localStorage.getItem('user'));
        const rateObj = { mail: this.mail.email };
        this.networkingService.post('/users/getrate/', rateObj).subscribe(data => {
            if (data) {
                this.rateFlag = data.rateReview;
                for (var i = 0; i < this.rateFlag.length; i++) {
                    if (this.prototypeId == this.rateFlag[i]) {
                        this.rateFlags = true;
                    }
                }
            }
            if (!this.rateFlags) {
                this.defaultrateShow = true;
            }
        });
    }
    sepWindowproRating(url) {
        this.userComments = '';
        this.userstarsCount = 0;
        this.newWin = window.open(url);
        this.mail = JSON.parse(localStorage.getItem('user'));

        const rateObj = { mail: this.mail.email };
        if (this.newWin) {
            this.networkingService.post('/users/getrate/', rateObj).subscribe(data => {
                if (data) {
                    this.rateFlag = data.rateReview;
                    for (var i = 0; i < this.rateFlag.length; i++) {
                        if (this.prototypeId == this.rateFlag[i]) {
                            this.rateFlags = true;
                        }
                    }
                }
                if (!this.rateFlags) {
                    this.defaultrateShow = true;
                }
            });
        }
        console.log("prev--->", this.prototype);
        this.networkingService.post('/proto/previewCount/' + this.prototype.id, { preview: this.prototype.previewCount }).subscribe((response) => {

        });
    }
    previewProto() {
        console.log("previewProto");
        this.networkingService.post('/proto/previewCount/' + this.prototype.id, { preview: this.prototype.previewCount }).subscribe((response) => {
        });
    }
    rateStore() {
        this.avgRating = 0;
        this.rateShow = false;
        this.defaultrateShow = false;
        for (var i = 0; i < this.reviewArray.length; i++) {
            this.avgRating = (this.avgRating + this.reviewArray[i].userrating);
        }
        this.avgRating = this.avgRating + this.userstarsCount;
        this.avgRating = this.avgRating / (this.reviewArray.length + 1);
        this.avgRating = Math.round(this.avgRating);
        const rateObject = { id: this.prototypeId, avgrating: this.avgRating };
        this.networkingService.post('/search/avgRatingStore/', rateObject).subscribe(data => {
            if (data) {
                this.prototype.rating = this.avgRating;
            }
        });
        this.reviewShow = false;
        this.savetoasts = true;
        window.scrollTo(0, 0);

        setTimeout(() => {
            this.savetoasts = false;
        }, 5000);
        if (this.mail.name) {
            this.users = this.mail.name;
        } else {
            this.users = this.mail.email;
        }
        this.reviewDate = this.time;
        this.reviewDate = this.formateDate(this.reviewDate);
        const queryObject = {
            id: this.prototype.id,
            username: this.users,
            userrating: this.userstarsCount,
            comment: this.userComments,
            date: this.reviewDate,
            userId: this.mail.id,
            oldReview: this.prototype.review,
            rewardPoints: this.mail.rewardPoints
        };
        this.networkingService.post('/search/storeRating/', queryObject).subscribe(data => {
            console.log(data);
            if (data) {
                this.data.changePrototype(data);
                console.log(data, 'asd')
                this.reviewArray.length = 0;
                this.reviewArray = this.reviewArray.concat(data.review);
            }
        });
        this.userComments = '';
        this.userstarsCount = 0;
        this.mail = JSON.parse(localStorage.getItem('user'));
        var obj = { mail: this.mail.email, id: this.prototypeId }
        this.networkingService.post('/users/ratePopup', obj).subscribe((data) => {
        });
    }

    ngOnDestroy() {

        localStorage.removeItem('prototype');
    }
    modalPopUp() {
        if (this.initial === 0) {
            this.showDialog = !this.showDialog;
        }
        this.submitdisable = !this.submitdisable;
    }
    close() {
        this.router.navigateByUrl('/toolbox');
    }
    btnClick(boxUrl) {
        const credentials = {
            username: 'guacadmin',
            password: 'guacadmin',
            token: this.token
        };
        this.networkingService.post('/api/guaca', credentials)
            .subscribe(res => {
                this.token = res;

                window.open(boxUrl + this.token, '_blank');
            });
    }
    removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    public carouselTileLoad(evt: any) { }
    backToPrototypeList() {
        this._location.back();
    }
    getProto() {
        this.value = true;
    }
    edit() {
        this.data.sendPrototypeData(null);
        this.data.changeMessage('addproto');
        var obj = {
            "query": this.prototype.id,
            "action": "view",
            "lang": "en"
        }
        this.router.navigateByUrl('/toolbox/createPrototype?id=' + this.prototype.id + "&action=view");
    }
    reviewsortBySelection(val) {
        this.reviewsortval = val;
        this.reviewersortInput = val;
    }
    detailOnClickOutside(e: Event) {
        this.detailfilter = false;
    }
    approvePrototype(id) {
        const reqObj = {
            status: 'Approved'
        };
        this.networkingService.put('/api/approvePrototype/' + id, reqObj).subscribe(data => {
        });
    }
    playlistDialog() {
        // console.log("working")
        this.popuploading = true;
        this.Playlistdialogbox = true;
        var Obj = {
            user: this.user.id
        }
        this.networkingService.post('/users/playlist/', Obj).subscribe(Response => {
            this.popuploading = false;
            // console.log(Response,"aruenraj")
            this.playlists = Response.playlist;
            this.Radioimage.length = this.playlists.length
        });
    }
    addToPlaylist(playlistName, i, playlist_id) {
        // console.log("working")
        this.playlistNameHtmlview = playlistName;
        for (let k = 0; k < this.Radioimage.length; k++) {
            if (k == i) {
                this.Radioimage[k] = true;
                // console.log("test")
            }
            else {
                this.Radioimage[k] = false;
            }
        }
        this.prototypeToPlaylist = {
            playlistId: playlist_id,
            id: this.prototype.id
        }
    }
    uncheckPlaylist(playlistName, i) {
        this.Radioimage[i] = false;
    }
    prototypeToBeAdded() {
        console.log("working", this.prototypeToPlaylist)
        this.networkingService.put('/users/updatePlaylist', this.prototypeToPlaylist).subscribe((Response) => {
            console.log(Response, "ResponseResponse")
            if (Response == "already added") {
                this.already = true;
                setTimeout(() => {
                    this.already = false;
                }, 7000);
            }

            else {

                this.playlistFlag = true;
                setTimeout(() => {
                    this.playlistFlag = false;
                }, 7000);
                if (this.Playlistdialogbox)
                    this.Playlistdialogbox = !this.Playlistdialogbox;

            }

        });
        this.prototypeToPlaylist = {};
    }
    closeplaylist() {
        this.playlistDialog();
        // this.Playlistdialogbox = false;
        this.Playlistname = '';
    }
    closeplaylistdialog() {
        this.Playlistdialogbox = false;
    }
    closeSharedialog() {
        this.shareDialogbox = false;
        this.Playlistdialogbox = false;
        this.tagStackArray = [];
        this.TagStack = '';
    }
    getserviceday(gettime) {
        var d = new Date(gettime);
        this.dueDate = new Date(d.setDate(d.getDate() + 3)).toLocaleString('en-IN', this.options);
        return this.dueDate;
    }
    vipPlaylistCheck() {
        this.vipPlaylist = !this.vipPlaylist;
    }
    submitData() {
        const playListObj = {
            uploadDate: this.time,
            playlistName: this.Playlistname,
            playlistDescription: this.playlistDescription,
            prototypeId: this.prototype.id,
            vipPlaylist: this.vipPlaylist,
            userId: this.user.id,
            userRole: this.user.userGroup,
            userName: this.user.name,
            dueDate: this.getserviceday(this.time),
            request_id: "REQ" + Math.floor(100000 + Math.random() * 900000)
        }
        this.networkingService.post('/users/createPlaylist', playListObj).subscribe(Response => {
            this.playlistCreated = Response
            if (this.playlistCreated == "already added") {
                this.alreadyaddedplaylist = true;
                setTimeout(() => {
                    this.alreadyaddedplaylist = false;
                }, 5000);

            }
            if (this.playlistCreated != "already added") {
                this.playlistFlag = true;
                setTimeout(() => {
                    this.playlistFlag = false;
                }, 5000);
                this.Playlistdialogbox = !this.Playlistdialogbox;
            }
        });
        this.playlistDescription = '';
    }
    deleteclose() {
        this.playlistFlag = !this.playlistFlag;
        this.data.changePrototype('');
    }
    tabtoggle(value) {
        console.log('value', value);
        this.tabtogglevalue = value;
    }
    // addToPlaylist(playlistName) {
    //     var obj = {
    //         playlistName: playlistName,
    //         id: this.prototype.id,
    //     }
    //     this.networkingService.put('/users/updatePlaylist', obj).subscribe((Response) => {
    //         if (Response == "already added") {
    //             this.already = true;
    //             setTimeout(() => {
    //                 this.already = false;
    //             }, 5000);
    //         }
    //         else {
    //             this.playlistFlag = true;
    //             setTimeout(() => {
    //                 this.playlistFlag = false;
    //             }, 5000);
    //             this.Playlistdialogbox = !this.Playlistdialogbox;
    //         }
    //     });
    // }
    gotoPlaylist() {
        this.existingContent = false;
        this.playlists.length = 0;
    }
    @HostListener('window:scroll', [])
    onWindowScroll() {
        const number = window.pageYOffset;
        if (number > 150) {
            this.detailscrolltop = true;
        } else {
            this.detailscrolltop = false;
        }
    }
}
@Pipe({
    name: 'CapitalizeFirst'
})
export class CapitalizeFirst implements PipeTransform {
    transform(value: string, args: any[]): string {
        if (value === undefined) {
            return '';
        }
        return value.charAt(0).toUpperCase() + value.slice(1);
    }
}
@Pipe({
    name: 'RevHighlightssortPipe'
})
export class RevHighlightssortPipe implements PipeTransform {
    transform(arra: any): any {
        const revHighlightstempSortArr = [];
        for (const i in arra) {
            if (arra.hasOwnProperty(i)) {
                revHighlightstempSortArr[i] = arra[i];
            }
        }
        revHighlightstempSortArr.sort(function (a, b) {
            const firstRate = a.userrating, secondRate = b.userrating;
            if (firstRate > secondRate) {
                return -1;
            } else if (firstRate < secondRate) {
                return 1;
            }
            return 0;
        });
        return revHighlightstempSortArr;
    }
}

@Pipe({
    name: 'ReviewersortPipe'
})
export class ReviewersortPipe implements PipeTransform {
    options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric' ,
    };
    transform(arra: any, reviewersortInput: any): any {
        const reviewertempSortArr = [];
        for (const i in arra) {
            if (arra.hasOwnProperty(i)) {
                reviewertempSortArr[i] = arra[i];
            }
        }
        reviewertempSortArr.forEach((e) => {
            const c = new Date(e.date);
            const d = c.toString();
            e.date = Date.parse(d);
        });
        if (reviewersortInput !== '') {
            if (reviewersortInput === 'Best Rated') {
                reviewertempSortArr.sort(function (a, b) {
                    const firstRate = a.userrating,
                        secondRate = b.userrating;
                    if (firstRate > secondRate) {
                        return -1;
                    }
                    if (firstRate < secondRate) {
                        return 1;
                    }
                    return 0;
                });
                return reviewertempSortArr;
            } else if (reviewersortInput === 'Least Rated') {
                reviewertempSortArr.sort(function (a, b) {
                    const firstRate = a.userrating,
                        secondRate = b.userrating;
                    if (firstRate < secondRate) {
                        return -1;
                    }
                    if (firstRate > secondRate) {
                        return 1;
                    }
                    return 0;
                });
                return reviewertempSortArr;
            } else if (reviewersortInput === 'Recent') {
                reviewertempSortArr.sort(function (a, b) {
                    const firstRate = a.date,
                        secondRate = b.date;
                    if (firstRate > secondRate) {
                        return -1;
                    }
                    if (firstRate < secondRate) {
                        return 1;
                    }
                    return 0;
                });
                return reviewertempSortArr;
            }
        }
        reviewertempSortArr.sort(function (a, b) {
            const firstRate = a.userrating, secondRate = b.userrating;
            if (firstRate > secondRate) {
                return -1;
            } if (firstRate < secondRate) {
                return 1;
            }
            return 0;
        });
        return reviewertempSortArr;
    }

}

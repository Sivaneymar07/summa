import { Component, OnInit, ViewChild, Directive, ElementRef, HostListener, Input, Renderer, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { CategorynameInterface } from '../../shared/categoryname.interface';
import { FileUploader, FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { NgbTabChangeEvent, NgbTabsetConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgClass, CommonModule } from '@angular/common';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { CompleterService, CompleterData } from 'ng2-completer';
import { TextMaskModule } from 'angular2-text-mask';
import { NetWorkingService } from '../../shared/networking.service';
import { DataService } from '../../shared/data.service';
import { Location } from '@angular/common';
import { ImagePreviewDirective } from './image-preview.directive';
import { TranslateService } from '@ngx-translate/core';
import { LoadingModule } from 'ngx-loading';
import { trigger, state, style, animate, transition } from '@angular/animations';


const URL = '/api/imageupload';
@Component({
  selector: 'app-adminform',
  templateUrl: './adminform.component.html',
  styleUrls: ['./adminform.component.css'],
  providers: [],
  animations: [
    trigger('fade', [
        transition(':enter', [
            style({ transform: 'translateX(100%)' }),
            animate(700)
        ]),
        transition('* => void', [
            animate('0.5s 0.5s ease-out', style({
                opacity: 0
            }))
        ])
    ])
]

})
export class AdminformComponent implements OnInit {
  @ViewChild('prototypeUpload') ngbTabSet;
  prototypeEntryFromDB: any;
  adminFlag: any;
  fid: any;
  id: any;
  flag: Boolean;
  Tags: any;
  RejectDialog = false;
  resubmitDialog = false;
  protected dataService: CompleterData;
  protected Accessrestriction: CompleterData;
  public loading = false;
  protected searchData = [
    { color: 'Responsive Web Design', value: '#f00' },
    { color: 'Atomic Design', value: '#0f0' },
    { color: 'Material Design ', value: '#00f' },
    { color: 'Product Management', value: '#0f0' },
    { color: 'Product Development', value: '#00f' },
    { color: 'Process Improvement', value: '#0f0' },
    { color: 'Crypto-currency ', value: '#00f' },
    { color: 'Extended Reality', value: '#00f' },
    { color: 'Android', value: '#0f0' },
    { color: 'IOS', value: '#00f' },
    { color: 'Windows', value: '#00f' },
    { color: 'Marketing', value: '#f00' },
    { color: 'Customer Experience', value: '#00f' },
    { color: 'E-commerce', value: '#00f' },
    { color: 'Experience Design', value: '#0f0' },
    { color: 'Service Design', value: '#00f' },
    { color: 'Process efficiency', value: '#00f' },
    { color: 'Digital transformation', value: '#f00' },
    { color: 'Supply chain', value: '#00f' },
    { color: 'Lean', value: '#0f0' },
    { color: 'Agile', value: '#00f' },
    { color: 'Customer lifecycle', value: '#0f0' },
    { color: 'Travel & Hospitality', value: '#0f0' },
    { color: 'General', value: '#00f' },
    { color: 'Banking & Financial Services', value: '#0f0' },
    { color: 'Energy & Utility', value: '#00f' },
    { color: 'Retail & Consumer Goods', value: '#0f0' },
    { color: 'Insurance', value: '#f00' },
    { color: 'Health Care', value: '#00f' },
    { color: 'Manufacturing & Logistics', value: '#0f0' },
    { color: 'Artificial Intelligence', value: '#f00' },
    { color: 'Invision', value: '#00f' },
    { color: 'Axure', value: '#0f0' },
    { color: 'Enterprise Mobile', value: '#f00' },
    { color: 'Augmented Reality', value: '#00f' },
    { color: 'Blockchain', value: '#0f0' },
    { color: 'Analytics', value: '#f00' },
    { color: 'Virtual Reality', value: '#00f' },
    { color: 'Internet of Things', value: '#0f0' },
    { color: '3D Printing', value: '#f00' },
    { color: 'Working Prototype', value: '#00f' },
    { color: 'Clickable Prototype', value: '#0f0' },
    { color: 'Framework', value: '#f00' },
  ];
  uploadIcon = true;
  uploadIcon_1 = true; uploadIcon_2 = true; uploadIcon_3 = true; uploadIcon_4 = true; addIcon = true;
  subtypeid: string;
  edited = false;
  protoAssests = true;
  technicalDetails = true;
  tabCount = 1;
  deleteproto = false;
  isPrototypeName: boolean;
  isPrototypeDescription: boolean;
  isEmployeeId: boolean;
  isEmployeeName: boolean;
  isUrl: boolean;
  isComment: boolean;
  isCategory: boolean;
  isApplication: boolean;
  isSubNature: boolean;
  isFidelity: boolean;
  isDomain: boolean;
  isFrontEnd: boolean;
  isTag: boolean;
  isBackEnd: boolean;
  isMiddleware: boolean;
  isPrototypeKind: boolean;
  screenshots: any[];
  draftPrototypes: any;
  methodProcesss: string;
  thumbnail_url: any;
  showDialog = false;
  showCancel = false;
  screenshotuploadbutton = false;
  modalPopUpIndex: any = 0;
  disableHostingTab = true;
  disableTechDetailsTab = true;
  submitdisable = false;
  savetoast = false;
  Sharedusers = [];
  updateForm: any;
  editDialog = false;
  tagStackArray = [];
  accessRestrictionArray = [];
  accessControl: string;
  tagstackfinaldivboolean = false;
  verticals: any;
  Fidelities: any;
  frontend: any;
  middleware: any;
  backend: any;
  subtypes: any;
  prototypeKinds: any;
  domains: any;
  Compatabilities: any;
  Factors: any;
  accessRestrictionValue: any;
  Category: any;
  types: any;
  adminFormNotification: any;
  prototypeArray: PrototypeInterface[] = [];
  prototype: PrototypeInterface;
  caregoryName: CategorynameInterface;
  caregoryNameArry: CategorynameInterface[] = [];
  name: any;
  Customer: any;
  urlParams: any;
  PrototypeName: string;
  Technology: string;
  Categories: string;
  type: string;
  subtype: string;
  prototypeKind: string;
  Fidelity: string;
  LDescription: string;
  Domain: string;
  TagStack: string;
  accessRestriction: string;
  showHide: any;
  hostUrl: any;
  ownerID: number;
  Requestername: string;
  Frontend: string;
  Middleware: string;
  Backend: string;
  Comments: string;
  Icon: string;
  HelpGuide: string;
  ExecuteableFile: string;
  Hosted: string;
  user_id: string;
  status: string;
  textfile: any;
  supportingFileName: string;
  supportingFileSize: string;
  author_name: string;
  lastModifiedDate: any;
  dueDate: any;
  uploadDate: any;
  rejectComment: any;
  req_id: string;
  myVar = false;
  showReject = false;
  showApprove = false;
  rejectproto = false;
  mail: any;
  public screenshotsuploader: FileUploader;
  date = new Date();
  duedate = new Date();
  newapprovedate: any;
  newDate: any;
  modifiedDate: any;
  approvedDate: any;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric' ,
  };
  iconActive = false;
  thumbnailActive = false;
  helpguideActive = false;
  errorMessage: string;
  user = {};
  item: any;
  newlimit: number;
  public assetsuploader: FileUploader = new FileUploader({ url: URL });
  public previewImageuploader: FileUploader = new FileUploader({ url: URL, queueLimit: 1 });
  public thumbnailuploader: FileUploader = new FileUploader({ url: URL, queueLimit: 1 });
  public supportingfileuploader: FileUploader = new FileUploader({ url: URL });
  constructor(private networkingService: NetWorkingService, private _location: Location, private completerService: CompleterService, private data: DataService, private route: ActivatedRoute, private router: Router, private translate: TranslateService) {
    this.dataService = completerService.local(this.searchData, 'color', 'color');
    this.Accessrestriction = completerService.local(this.searchData, 'color', 'color');

    // this.prototypeEntryFromDB = this.data.getPrototypeData();
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    this.screenshots = [];
    let obj = { "query": this.urlParams.params.id, "view": true }
    if (this.urlParams.params.id) {
      this.loading = true;
      const reqObj = {
        'query': this.urlParams.params.id,
        'lang': 'en'
      };
      this.networkingService.post('/api/editPrototype', reqObj)
        .subscribe(prototypes => {
          this.loading = false;

          this.prototypeEntryFromDB = prototypes;
          console.log(this.prototypeEntryFromDB, 'fromdb')
          if (this.prototypeEntryFromDB) {
            this.addIcon = false;
            this.id = this.prototypeEntryFromDB.id;
            this.PrototypeName = this.prototypeEntryFromDB.title;
            this.Categories = this.prototypeEntryFromDB.Categories;
            this.type = this.prototypeEntryFromDB.type;
            this.subtype = this.prototypeEntryFromDB.subtype;
            this.prototypeKind = this.prototypeEntryFromDB.prototypeKind;
            this.Fidelity = this.prototypeEntryFromDB.Fidelity;
            this.Domain = this.prototypeEntryFromDB.Domain;
            this.ownerID = this.prototypeEntryFromDB.ownerID;
            this.Requestername = this.prototypeEntryFromDB.Requestername;
            this.Hosted = this.prototypeEntryFromDB.Hosted;
            this.Frontend = this.prototypeEntryFromDB.Frontend;
            this.Middleware = this.prototypeEntryFromDB.Middleware;
            this.Backend = this.prototypeEntryFromDB.Backend;
            this.Comments = this.prototypeEntryFromDB.Comments;
            this.LDescription = this.prototypeEntryFromDB.description;
            this.disableHostingTab = false;
            this.disableTechDetailsTab = false;
            this.screenshots = this.prototypeEntryFromDB.screenshots;
            this.thumbnail_url = this.prototypeEntryFromDB.thumbnail_url;
            this.Icon = this.prototypeEntryFromDB.Icon;
            this.HelpGuide = this.prototypeEntryFromDB.HelpGuide;
            this.tagStackArray = this.prototypeEntryFromDB.tags;
            this.supportingFileName = this.prototypeEntryFromDB.supportingFileName;
            this.supportingFileSize = this.prototypeEntryFromDB.supportingFileSize;
            this.author_name = this.prototypeEntryFromDB.author_name;
            this.uploadDate = this.prototypeEntryFromDB.uploadDate;
            this.approvedDate = this.prototypeEntryFromDB.approvedDate;
            this.accessRestrictionArray = this.prototypeEntryFromDB.accessRestriction;

            if (this.prototypeEntryFromDB.status === 'Rejected') {
              this.RejectDialog = true;
              this.rejectComment = this.prototypeEntryFromDB.rejectFeedback;
              this.rejectproto = true;
            }
          }
        });

    }
    this.newlimit = 4 - this.screenshots.length;
    this.screenshotsuploader = new FileUploader({ url: URL, queueLimit: this.newlimit });
  }
  moveToHostingTab() {
    this.disableHostingTab = false;
  }
  ngOnInit() {
    this.translate.get('upload_proto_proto_Categories').subscribe((res: any) => { this.Category = res; });
    this.translate.get('upload_proto_proto_types').subscribe((res: any) => { this.types = res; });
    this.translate.get('upload_proto_proto_verticals').subscribe((res: any) => { this.verticals = res; });
    this.translate.get('upload_proto_proto_Fidelities').subscribe((res: any) => { this.Fidelities = res; });
    this.translate.get('upload_proto_proto_frontend').subscribe((res: any) => { this.frontend = res; });
    this.translate.get('upload_proto_proto_middleware').subscribe((res: any) => { this.middleware = res; });
    this.translate.get('upload_proto_proto_backend').subscribe((res: any) => { this.backend = res; });
    this.translate.get('upload_proto_proto_NativeApp_subtypes').subscribe((res: any) => { this.subtypes = res; });
    this.translate.get('upload_proto_proto_prototypeKinds').subscribe((res: any) => { this.prototypeKinds = res; });
    this.translate.get('upload_proto_proto_domains').subscribe((res: any) => { this.domains = res; });
    this.translate.get('upload_proto_proto_Compatabilities').subscribe((res: any) => { this.Compatabilities = res; });
    this.translate.get('upload_proto_proto_Factors').subscribe((res: any) => { this.Factors = res; });
    this.translate.get('upload_proto_proto_access').subscribe((res: any) => { this.accessRestrictionValue = res; });
    this.data.currentMessage.subscribe(Response => {
      this.adminFlag = Response;
    });
    this.mail = JSON.parse(localStorage.getItem('user'));
    this.showHide = true;
    this.flag = true;
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    if (!this.prototypeEntryFromDB) {
      const mail = JSON.parse(localStorage.getItem('user'));
      const username = mail.username;
      const empid = mail.empid;
      this.Requestername = username;
      this.ownerID = empid;
    }
    this.previewImageuploader.onAfterAddingFile = addedItem => {
      if (this.previewImageuploader.queue.length > 1) {
        this.previewImageuploader.removeFromQueue(this.previewImageuploader.queue[0]);
        this.Icon = '';
      }
    };
    this.thumbnailuploader.onAfterAddingFile = addedItem => {
      if (this.thumbnailuploader.queue.length > 1) {
        this.thumbnailuploader.removeFromQueue(this.thumbnailuploader.queue[0]);
        this.thumbnail_url = '';
      }
    };
    this.supportingfileuploader.onAfterAddingFile = addedItem => {
      if (this.supportingfileuploader.queue.length > 1) {
        this.supportingfileuploader.removeFromQueue(this.supportingfileuploader.queue[0]);
        this.HelpGuide = '';
        this.supportingFileName = '';
        this.supportingFileSize = '';
      }
    };
    var obj = { mail: this.mail.email }
    this.networkingService.post('/users/shareUsers', obj).subscribe((users) => {
      users.forEach(user => {
        this.Sharedusers.push(user.email);
      })
      var index = this.Sharedusers.indexOf(this.mail.email);
      this.Sharedusers.splice(index, 1);
      this.Accessrestriction = this.completerService.local(this.Sharedusers);
    });
  }
  scrollWindow() {
    window.scrollBy(0, 700);
  }
  removeScreenshot(item) {
    this.screenshots.splice(item, 1);
  }
  screenshotQueueLimit() {
    if ((this.screenshots.length + this.screenshotsuploader.queue.length) === 4) {
      this.screenshotuploadbutton = true;
    }
  }
  movetoTechDetailsTab() {
    this.disableTechDetailsTab = false;
  }
  categoryname() {
    if (this.thumbnail_url === '') {
      this.thumbnailActive = true;
    }
    if (this.HelpGuide === '') {
      this.helpguideActive = true;
    }
    if (this.Icon === '') {
      this.iconActive = true;
    }
    const newcategoryname = {
      PrototypeName: this.PrototypeName,
      Categories: this.Categories
    };
    this.networkingService.post('/api/categoryname', newcategoryname)
      .subscribe(caregoryName => {
        this.caregoryNameArry.push(caregoryName);
        this.scrollWindow();
        this.scrollWindow();
      });
  }
  successMsg() {
    this.edited = true;
  }
  update(method) {
    this.modifiedDate = this.date.toLocaleString('en-IN', this.options);
    window.scrollTo(0, 0);
    this.draftPrototypes = this.prototypeArray;
    var protostatus;
    if (this.draftPrototypes.length > 3) {
      this.id = this.draftPrototypes[0].id;
    } else {
      this.id = this.prototypeEntryFromDB.id;
    }
    if (method === 'Draft') {
      this.editDialog = false;
    } else if (method === 'Pending') {
      this.editDialog = true;
    } else if (method === 'ReSubmit') {
      this.resubmitDialog = true;
    }
    if (this.prototypeEntryFromDB.status === 'Pending') {
      protostatus = 'Pending';
    } else if (this.prototypeEntryFromDB.status === 'Draft' && method === 'Draft') {
      protostatus = 'Draft';
    }
    else if (this.prototypeEntryFromDB.status === 'Draft' && method === 'Pending') {
      protostatus = 'Pending';
    } else if (this.prototypeEntryFromDB.status === 'ReSubmit') {
      protostatus = 'ReSubmit';
    } else if (method === 'ReSubmit') {
      protostatus = 'ReSubmit';
    }
    this.updateForm = {
      id: this.id,
      PrototypeName: this.PrototypeName,
      Categories: this.Categories,
      type: this.type,
      subtype: this.subtype,
      prototypeKind: this.prototypeKind,
      Fidelity: this.Fidelity,
      LDescription: this.LDescription,
      Domain: this.Domain,
      ownerID: this.ownerID,
      Requestername: this.Requestername,
      Frontend: this.Frontend,
      Middleware: this.Middleware,
      Backend: this.Backend,
      Comments: this.Comments,
      Hosted: this.Hosted,
      status: protostatus,
      screenshots: this.screenshots,
      thumbnail_url: this.thumbnail_url,
      Icon: this.Icon,
      HelpGuide: this.HelpGuide,
      tags: this.tagStackArray,
      supportingFileName: this.supportingFileName,
      supportingFileSize: this.supportingFileSize,
      author_name: this.author_name,
      lastModifiedDate: this.modifiedDate,
      approvedDate: this.approvedDate,
      accessRestriction: this.accessRestrictionArray
    };
    this.networkingService.put('/api/updatePrototype/' + this.updateForm.id, this.updateForm).subscribe(data => {
      console.log('saveupdate');
      if (method === 'Draft') {
        this.savetoast = true;
        setTimeout(() => {
          this.savetoast = false;
        }, 7000);
      }
    });
  }
  tagStackdiv(event) {
    if (event.key === 'Enter') {
      this.tagStackArray.push(this.TagStack);
      this.TagStack = '';
    }
  }
  tagStackdivAccess(event) {
    this.accessRestrictionArray.push(this.accessRestriction);
    this.accessRestriction = '';


    const emailobject = { email: this.accessRestriction };
    let checkDL = this.accessRestriction.includes('@');
    if (checkDL) {
      if (!this.accessRestrictionArray.includes(this.accessRestriction)) {
        var obj = this.Sharedusers.filter((a) => {
          if (a == this.accessRestriction) {
            this.accessRestrictionArray.push(this.accessRestriction);
            return a;
          }
        })
      }
      this.accessRestriction = '';
    }
  }
  tagstackfinaldiv() {
    this.tagstackfinaldivboolean = true;
    this.showHide = false;
  }
  addProduct(method) {
    this.requestid();
    const mail = JSON.parse(localStorage.getItem('user'));
    const username = mail.username;
    const newduedate = new Date(this.duedate.setDate(this.date.getDate() + 3));
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    this.approvedDate = '';
    const newProduct = {
      PrototypeName: this.PrototypeName,
      Technology: '',
      Categories: this.Categories,
      type: this.type,
      subtype: this.subtype,
      prototypeKind: this.prototypeKind,
      Fidelity: this.Fidelity,
      category_name: 'asdasd',
      LDescription: this.LDescription,
      Domain: this.Domain,
      ownerID: this.ownerID,
      Requestername: this.Requestername,
      tags: this.tagStackArray,
      Frontend: this.Frontend,
      Middleware: this.Middleware,
      Backend: this.Backend,
      Comments: this.Comments,
      Hosted: this.Hosted,
      categoryUrl: '',

      app_icon: '',
      accronym: 'AR',
      uploadDate: this.newDate,
      rating: '3',
      ratingUrl: './assets/images/star3.png',
      popularity: 0,
      thumbnail_Url: '',
      playstore_Url: '',
      ios_Url: '',
      platform: '',
      prototype_type: 'Clickable Prototype',
      screenshots: [],
      ExecuteableFile: '',
      HelpGuide: '',
      Icon: '',
      user_id: mail.id,
      user_email: mail.email,
      status: method,
      author_name: this.Requestername,
      lastModifiedDate: this.newDate,
      supportingFileName: '',
      supportingFileSize: '',
      dueDate: newduedate.toLocaleString('en-IN', this.options),
      rejectFeedback: '',
      req_id: this.req_id,
      approvedDate: this.approvedDate,
      view: 'false',
      accessRestriction: this.accessRestrictionArray,
      review: [{
        'username': 'Lemuel Fairbrass',
        'userrating': 4,
        'date': '10/30/2017',
        'ProfilePicUrl': './assets/images/icon3.png',
        'comment': 'Never seen a better innovation platform. Kudos.'
      },
      {
        'username': 'Josy Winsborrow',
        'userrating': 4,
        'date': '5/7/2017',
        'ProfilePicUrl': './assets/images/icon2.png',
        'comment': 'No ideation tools available. Would be great if you guys could add that as well.'
      },
      {
        'username': 'Rodi Wynch',
        'userrating': 3,
        'date': '6/11/2017',
        'ProfilePicUrl': './assets/images/icon1.png',
        'comment': 'Semaless UX and rich repository of prototypes. Awesome tool.'
      },
      {
        'username': 'Albie Brower',
        'userrating': 2,
        'date': '6/27/2017',
        'ProfilePicUrl': './assets/images/icon3.png',
        'comment': 'Very nice app in an aesthetically pleasing UI'
      },
      {
        'username': 'Bette-ann Burmingham',
        'userrating': 1,
        'date': '8/3/2017',
        'ProfilePicUrl': './assets/images/icon2.png',
        'comment': 'One of a kind platform. Great job folks!!!'
      },
      {
        'username': 'Bette-ann Burmingham',
        'userrating': 4,
        'date': '8/3/2017',
        'ProfilePicUrl': './assets/images/icon2.png',
        'comment': 'One of a kind platform. Great job folks!!!'
      },
      {
        'username': 'Bette-ann Burmingham',
        'userrating': 2,
        'date': '8/3/2017',
        'ProfilePicUrl': './assets/images/icon2.png',
        'comment': 'One of a kind platform. Great job folks!!!'
      }
      ]
    };
    this.networkingService.post('/api/prototypes', newProduct)
      .subscribe((prototype) => {
        console.log('protoupload', prototype);
        const notedate = new Date(Date.now());
        const newnotedate = notedate;
        if (method === 'Draft') {
          window.scrollTo(0, 0);
          console.log('saved');
          this.savetoast = true;
          setTimeout(() => {
            this.savetoast = false;
          }, 7000);
        }
        if (method !== 'Draft') {
          this.adminFormNotification = {
            email: mail.email,
            ref_id: prototype.id,
            notificationtag: 'Prototype',
            prototypeName: this.PrototypeName,
            message: '',
            action: '',
            status: 'pending',
            notificationDate: newnotedate
          };
          this.networkingService.post('/users/notification', this.adminFormNotification).subscribe((res) => {
            console.log("dsdss", res);
            this.networkingService.get('/users/notification/' + mail.email).subscribe((response) => {
              this.data.profilenotify(response);
            });

          });
        }
        // this.data.notificationData().subscribe((res) => {

        // });

        this.prototypeArray.push(prototype);
      });
    this.addIcon = false;
    this.assetsuploader.clearQueue();
    this.screenshotsuploader.clearQueue();
    this.previewImageuploader.clearQueue();
    this.thumbnailuploader.clearQueue();
    this.supportingfileuploader.clearQueue();
  }
  removeThumbnail() {
    this.thumbnail_url = '';
  }
  removeHelpguide() {
    this.HelpGuide = '';
    this.supportingFileName = '';
    this.supportingFileSize = '';
  }
  removeIcon() {
    this.Icon = '';
  }
  uploadSupportingfile() {
    this.newDate = this.date.toLocaleString('en-IN', this.options);
  }
  uploadAssets() {
    this.newDate = this.date.toLocaleString('en-IN', this.options);
  }
  uploadScreenshots() {
    this.newlimit = 4 - this.screenshots.length;
    this.screenshotsuploader.options.queueLimit = this.newlimit;
    if ((this.screenshots.length + this.screenshotsuploader.queue.length) === 4) {
      this.screenshotuploadbutton = true;
    }
    this.newDate = this.date.toLocaleString('en-IN', this.options);
  }
  uploadThumbnail() {
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    this.thumbnailuploader.onAfterAddingFile = addedItem => {
      if (this.thumbnailuploader.queue.length > 1) {
        this.thumbnailuploader.removeFromQueue(this.thumbnailuploader.queue[0]);
        this.thumbnail_url = '';
      }
    };
  }
  uploadPreviewImage() {
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    this.previewImageuploader.onAfterAddingFile = addedItem => {
      if (this.previewImageuploader.queue.length > 1) {
        this.previewImageuploader.removeFromQueue(this.previewImageuploader.queue[0]);
        this.Icon = '';
      }
    };
  }
  uploadAll(method) {
    const fd = new FormData();
    if (this.assetsuploader.queue.length !== 0 || this.screenshotsuploader.queue.length !== 0 || this.previewImageuploader.queue.length !== 0
      || this.thumbnailuploader.queue.length !== 0 || this.supportingfileuploader.queue.length !== 0) {
      this.screenshotsuploader.queue.forEach((element) => {
        fd.append('screenshots', element._file, element._file.name);
      });
      this.previewImageuploader.queue.forEach((element) => {
        fd.append('previewImage', element._file, element._file.name);
      })
      this.thumbnailuploader.queue.forEach((element) => {
        fd.append('thumbnail', element._file, element._file.name);
      });
      this.supportingfileuploader.queue.forEach((element) => {
        fd.append('supportingFiles', element._file, element._file.name);
      });
      this.networkingService.post(URL, fd).subscribe((output) => {
        if (this.addIcon == true && method == 'Pending') {
          this.addProduct(method);
        } else if (this.addIcon == true && method == 'Draft') {
          this.addProduct(method);
        } else if (this.addIcon == false) {
          this.update(method)
        }
      });
    }
    else if (this.assetsuploader.queue.length == 0 || this.screenshotsuploader.queue.length == 0 || this.previewImageuploader.queue.length == 0
      || this.thumbnailuploader.queue.length == 0 || this.supportingfileuploader.queue.length == 0) {
      if (this.addIcon == true && method == 'Pending') {
        this.addProduct(method);
      }
      else if (this.addIcon == true && method == 'Draft') {
        this.addProduct(method);
      } else if (this.addIcon == false) {
        this.update(method)
      }
    }
  }
  subtypefunction(name) {
    this.subtypeid = 'subType';
    if (name === 'Native app') {
      this.translate.get('upload_proto_proto_NativeApp_subtypes').subscribe((res: any) => { this.subtypes = res; });
    } else if (name === 'Web app') {
      this.translate.get('upload_proto_proto_web_subtypes').subscribe((res: any) => { this.subtypes = res; });
    } else if (name === 'Hybrid app') {
      this.translate.get('upload_proto_proto_hybridApp_subtypes').subscribe((res: any) => { this.subtypes = res; });
    } else if (name === 'Website') {
      this.translate.get('upload_proto_proto_web_subtypes').subscribe((res: any) => { this.subtypes = res; });
    }
  }
  cancel() {
    this.showCancel = !this.showCancel;
  }
  backToPrototypeList() {
    this.data.changeMessage('MyPrototypes');
    this._location.back();
  }
  modalPopUp() {
    if (this.modalPopUpIndex === 0) {
      this.showDialog = !this.showDialog;
      this.modalPopUpIndex++;
    }
    this.submitdisable = true;
  }
  close() {
    this.data.changeMessage('MyPrototypes');
    this.router.navigateByUrl('/toolbox');
  }
  closetech(item) {
    const index = this.tagStackArray.indexOf(item);
    this.tagStackArray.splice(index, 1);
  }
  closetechAcess(item) {
    const index = this.accessRestrictionArray.indexOf(item);
    this.accessRestrictionArray.splice(index, 1);
  }
  gotoPrevStep() {
    console.log(this.ngbTabSet)
    const currentTab = this.ngbTabSet.activeId.replace('tab', '');
    this.tabCount = currentTab - 1;
    this.ngbTabSet.activeId = 'tab' + this.tabCount;
    if (this.tabCount < 1) {
      this.backToPrototypeList();
    }
  }
  focusFunction(focusid) {
    if (focusid === 'ProtoName') {
      this.isPrototypeName = !this.isPrototypeName;
    } else if (focusid === 'protodesp') {
      this.isPrototypeDescription = !this.isPrototypeDescription;
    } else if (focusid === 'empID') {
      this.isEmployeeId = !this.isEmployeeId;
    } else if (focusid === 'eName') {
      this.isEmployeeName = !this.isEmployeeName;
    } else if (focusid === 'url') {
      this.isUrl = !this.isUrl;
    } else if (focusid === 'comments') {
      this.isComment = !this.isComment;
    } else if (focusid === 'category') {
      this.isCategory = !this.isCategory;
    } else if (focusid === 'App') {
      this.isApplication = !this.isApplication;
    } else if (focusid === 'sub') {
      this.isSubNature = !this.isSubNature;
    } else if (focusid === 'Fid') {
      this.isFidelity = !this.isFidelity;
    } else if (focusid === 'dom') {
      this.isDomain = !this.isDomain;
    } else if (focusid === 'fend') {
      this.isFrontEnd = !this.isFrontEnd;
    } else if (focusid === 'TagStack') {
      this.isTag = !this.isTag;
    } else if (focusid === 'bend') {
      this.isBackEnd = !this.isBackEnd;
    } else if (focusid === 'mware') {
      this.isMiddleware = !this.isMiddleware;
    } else if (focusid === 'porkind') {
      this.isPrototypeKind = !this.isPrototypeKind;
    }
  }
  cancelReject() {
    this.showReject = !this.showReject;
  }
  cancelApprove() {
    this.showApprove = !this.showApprove;
  }
  approvePrototype(id, appmail) {
    const newapprovedate = new Date(Date.now());
    this.newapprovedate = this.date.toLocaleString('en-IN', this.options);
    console.log("dgfgs", this.prototypeEntryFromDB.user_id.id, this.prototypeEntryFromDB.user_id.totalPoints);
    console.log("kkkk", id);
    const reqObj = {
      status: 'Approved',
      approvedUser: appmail,
      id: this.prototypeEntryFromDB.user_id.id,
      rewardPoints: this.prototypeEntryFromDB.user_id.totalPoints,
      approvedDate: this.newapprovedate
    };
    const CurrentID = {
      fileName: this.mail.id,
      admin: this.mail.admin
    };
    this.networkingService.put('/api/approvePrototype/' + id, reqObj).subscribe(data => {
      console.log('after approval', data);
      this.data.changeMessage({ id: data[0].req_id, status: 'PrototypeApproved' });
      this.networkingService.post('/api/loadPendingPrototypes/', CurrentID).subscribe(
        (prototypes) => {
          const approveObj = {
            status: 'Approved',
            ref_id: id,
            action: 'Approve'
          };
          console.log("dfdffdfdfffffffffffffffffffffffffffffffffffffff")

          this.router.navigate(['./admin/rbac-dashboard']);
          console.log("qqqqqqqqqqqqqqqqqqqq")
          this.networkingService.put('/users/notification/' + id, approveObj).subscribe(data => {
            this.networkingService.post('/users/getnotification/' + reqObj.approvedUser, {}).subscribe((res) => {
              this.data.profilenotify(res);
            });
          });
        });
    });
  }
  rejectPrototype(id, rejmail) {
    const reqObj = {
      status: 'Rejected',
      rejectComment: this.rejectComment,
      rejectedUser: rejmail
    };
    const CurrentID = {
      fileName: this.mail.id,
      admin: this.mail.admin,
    };
    // this.data.changeSoftAdmin1('true');
    this.networkingService.put('/api/rejectPrototype/' + id, reqObj).subscribe(data => {
      console.log('after rejection', data);
      this.data.changeMessage({ id: data[0].req_id, status: 'PrototypeRejected' });
      this.networkingService.post('/api/loadPendingPrototypes/', CurrentID).subscribe(
        (prototypes) => {
          const rejObj = {
            status: 'Rejected',
            ref_id: id,
            action: 'Reject'
          };
          this.networkingService.put('/users/notification/' + id, rejObj).subscribe(
            (data) => {
              this.networkingService.post('/users/getnotification/' + reqObj.rejectedUser, {}).subscribe((res) => {
                this.data.profilenotify(res);
              });
            });
          this.router.navigate(['/admin/rbac-dashboard']);
        });
    });

  }
  mask: any[] = [/[1-6]/, /\d/, /\d/, /\d/, /\d/, /\d/];
  navClick() {
    // this.data.changeMessage('addprotoremove');
  }
  requestid() {
    this.myVar = !(this.myVar);
    this.req_id = "REQ" + Math.floor(100000 + Math.random() * 900000);
  }
  closerejectbox() {
    this.RejectDialog = false;
  }
  approveDate() {
    // const approvedate = new Date(this.approveDate.setDate(this.date.getDate()));

    this.approvedDate = this.date.toLocaleString('en-IN', this.options);

  }
}

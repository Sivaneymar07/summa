import { Directive, ElementRef, Input, Renderer, OnChanges, SimpleChanges } from '@angular/core';
@Directive({
  selector: '[appImagePreview]'
})
export class ImagePreviewDirective implements OnChanges {
  @Input() image: any;
  constructor(private imageToDisplay: ElementRef, private renderer: Renderer) { }
  ngOnChanges(changes: SimpleChanges) {
    const reader = new FileReader();
    const imageToDisplay = this.imageToDisplay;
    reader.onloadend = function () {
      imageToDisplay.nativeElement.src = reader.result;
    };
    if (this.image) {
      return reader.readAsDataURL(this.image);
    }
  }
}
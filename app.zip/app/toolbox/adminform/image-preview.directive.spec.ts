import { ImagePreviewDirective } from './image-preview.directive';
describe('ImagePreviewDirective', () => {
  it('should create an instance', () => {
    // const directive = new ImagePreviewDirective();
    // expect(directive).toBeTruthy();
  });
});

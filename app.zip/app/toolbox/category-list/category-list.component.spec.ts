// import { async, ComponentFixture, TestBed, inject  } from '@angular/core/testing';
// import { RouterTestingModule } from '@angular/router/testing';
// import { RouterModule, Router, RouterOutlet  } from '@angular/router';
// import {  HttpModule,
//   Response,
//   ResponseOptions,
//   XHRBackend
// } from '@angular/http';
// import { MockBackend } from '@angular/http/testing';

// import { CategoryListComponent } from './category-list.component';
// // import { CategoryService } from '../../shared/category.service';



// class MockRouter {
//     navigate(url: string) { return url; }
// }
// class MockCategoryListComponent {

// }



// describe('CategoryListComponent', () => {
//   let component: CategoryListComponent;
//   let fixture: ComponentFixture<CategoryListComponent>;
//   let categoryService: CategoryService;
//   let spy;
  
//   let de;
//   let el;
//   let compiled;

//   console.log('CategoryListComponent');

//   beforeEach(async() => {

//     console.log('beforeEach 1');
//     TestBed.configureTestingModule({
//       declarations: [ CategoryListComponent ],
//       imports: [
//         RouterTestingModule.withRoutes([
//           {
//             path : '', component : MockCategoryListComponent
//           }
//         ]),
//         HttpModule,
//         RouterModule
//        ],
//        providers: [
//          CategoryService,
//          { provide: XHRBackend, useClass: MockBackend }
//        ]
//     })
//     .compileComponents();
//     // .compileComponents().then( () => {
//     //     fixture = TestBed.createComponent(CategoryListComponent);
//     //     component = fixture.componentInstance;
//     // })

//      fixture = TestBed.createComponent(CategoryListComponent);
//      component = fixture.componentInstance;

//   });

//   beforeEach(async() => {
//     fixture.whenStable().then(() => {

//         console.log('beforeEach 2');
//         categoryService = fixture.debugElement.injector.get(CategoryService);
//         console.log('before detectChanges');
//         // fixture.detectChanges();
//         console.log('after detectChanges');

//         compiled = fixture.debugElement.nativeElement;
//         console.log('compiled');
//         // fixture.detectChanges();

//     });
//   });

//   it('should be created', () => {

//     expect(component).toBeTruthy();

//   });

//   it('should return an Observable<Array<Category>>',
//     inject([CategoryService, XHRBackend], (categoryService, mockBackend) => {


//       const mockResponse = {
//           data: [
//                 {'id': 'chatbot', 'name': 'ChatBot'},
//                 {'id': 'bots', 'name': 'Bots'},
//                 {'id': 'meanstack', 'name': 'Mean Stack'},
//                 {'id': 'internet', 'name': 'Internet of Things'},
//                 {'id': 'react', 'name': 'REACT'},
//                 {'id': 'cognitive', 'name': 'Cognitive Computing'},
//                 {'id': 'aiinsurance', 'name': 'AI Insurance'},
//                 {'id': 'glass', 'name': 'Google Glass'},
//                 {'id': 'fintech', 'name': 'AWS Fintech'},
//                 {'id': 'awsinsurance', 'name': 'AWS Insurance'},
//                 {'id': 'mobile', 'name': 'Enterprise Mobile'},
//                 {'id': 'arretail', 'name': 'AR Retail'},
//                 {'id': 'drones', 'name': 'Drones'},
//                 {'id': 'vrretail', 'name': 'VR Retail'},
//                 {'id': 'uav', 'name': 'Unmanned Air Vehicle'}
//           ]
//         };



//       mockBackend.connections.subscribe((connection) => {
//           connection.mockRespond(new Response(new ResponseOptions({
//             body: JSON.stringify(mockResponse)
//           })));
//         });

//       categoryService.getCategories().subscribe((category) => {
//         console.log('@category' + category.data[0].id);
//         expect(category.data.length).toBe(15);
//         expect(category.data[0].id).toEqual('chatbot');
//         expect(category.data[0].name).toEqual('ChatBot');
//         expect(category.data[14].id).toEqual('uav');
//         expect(category.data[14].name).toEqual('Unmanned Air Vehicle');
//       });

//   }));


//   it('should call Router.naigate with the ID ', inject([Router], (router: Router) => {


//     const spy = spyOn(router, 'navigate');
//     component.onCategoryClick('/chatbot');

//     const navArgs = spy.calls.first().args[0];
//     console.log('---' + navArgs);
//     console.log('---' + component.categories.length);
//     // const id = component.categories[0].id;

//     // expect(navArgs).toBe('/chatbot', 'should nav to Prototype List');

//   }));


// });

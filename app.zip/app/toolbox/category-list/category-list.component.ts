import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../shared/data.service';
import { Pipe, PipeTransform } from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { LoadingModule } from 'ngx-loading';

@Component({
    selector: 'app-category-list',
    templateUrl: './category-list.component.html',
    styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit, OnDestroy {
    categories: any = [];
    public loading: boolean = false;
    RejectDialog: boolean = false;
    value2: any = '';
    MyPrototypes: boolean = true;
    AllPrototypes: boolean = false;
    PendingPrototypes: boolean = true;
    errorMessage: any = '';
    message: string;
    rejected: any;
    auth: any;
    categorySubscription: Subscription;
    flag;
    headerFlag: any;
    categories1: any = [];
    pid: any;
    p_id: any;
    deletetoast: boolean = false;
    deleteDialog: boolean = false;
    showDialog: boolean = false;
    location = '';
    i: any = 0;
    submitdisable: boolean = false;
    proNames: any = [];
    proNames1: any = [];
    prototypes: any = [];
    prototypeSubscription: Subscription;
    adminforms: PrototypeInterface[] = [];
    adminform: PrototypeInterface;
    mail: any;
    classArr: any = [];
    date = new Date();
    newapprovedate: any;
    options = {
        year: 'numeric', month: 'short',
        day: 'numeric' ,
    };
    constructor(private networkingService: NetWorkingService, private route: ActivatedRoute, private router: Router, private data: DataService) { }

    ngOnInit() {
        this.loading = true;
        this.mail = JSON.parse(localStorage.getItem('user'));
        // this.data.currentFlag.subscribe(response => {
        //     if (response !== 'loading') {
        //         this.flag = response;
        //     }
        // });
        // this.data.addmyPrototype('AllPrototypes');
        this.data.currentMessage.subscribe(response => {
            console.log('response', response)
            if (response) {
                this.value2 = response;
            }
        });
        this.location = location.hash;
        this.modalPopUp();
        const CurrentID = {
            fileName: this.mail.id,
            admin: this.mail.admin
        };
        this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
            (prototypes) => {
                this.loading = false;
                this.proNames = prototypes;
            });
        this.networkingService.post('/api/loadPendingPrototypes/', CurrentID).subscribe(
            (prototypes) => {
                this.loading = false;
                this.proNames1 = prototypes;
            });
        this.onCategoryClick('All Categories');
        if (!this.flag) {
            this.networkingService.get('/categories')
                .subscribe(
                    (data: any[]) => {
                        this.loading = false;
                        this.categories1 = data;
                        for (let i = 0; i < data.length; i++) {
                            const temp = data[i].name.toLowerCase();
                            const res = temp.split(' ');
                            const temp_res = res.join('');
                            this.classArr.push(temp_res);
                        }
                    },
                    (error) => console.log(error)
                );
        }

        // this.data.currentFlag2.subscribe(response => {
        //     this.headerFlag = response;
        // });

    }

    toggle(p_id) {
        this.p_id = p_id;
        this.deleteDialog = !this.deleteDialog;
    }
    filter() {
        this.data.changeMessage('AllPrototypes');
        this.onCategoryClick('All Categories');
    }
    filter2() {
        this.data.changeMessage('PendingPrototypes');
    }
    filter1() {
        this.data.changeMessage('MyPrototypes');
    }
    view(id, category, prototype) {
        this.data.changeMessage('MyPrototypes');
        this.data.changePrototype(prototype);
        if (category.indexOf(' ') !== -1) {
            category = category.split(' ');
            category = category[0] + '%20' + category[1];
        }
        this.router.navigateByUrl('/toolbox/' + category + '/' + id);
        window.scrollTo(0, 0);
        if (prototype.status == 'Approved') {
            const reqObj = {
                view: 'false',
            };
            this.networkingService.put('/api/changeApprovedViewStatus/' + prototype._id, reqObj).subscribe((Response) => {

            });

        }
    }
    viewReject(protId) {

        const reqObj = {
            'query': protId,
            'lang': 'en'
        };
        this.networkingService.get('/api/prototypes/' + protId).subscribe(Response => {
            this.loading = false;
            this.rejected = Response[0].rejectFeedback;
            this.auth = Response[0].Requestername;
            this.RejectDialog = true;


        });


    }

    // edit() {
    //     for (let j = 0; j < this.proNames.length; j++) {
    //         if (this.proNames[j].status === 'Draft') {
    //             const reqObj = {
    //                 'query': this.proNames[j]._id,
    //                 'lang': 'en'
    //             };

    //             this.networkingService.post('/api/editPrototype', reqObj)
    //                 .subscribe(adminform => {
    //                     this.adminforms.push(adminform);
    //                     this.data.sendPrototypeData(adminform);
    //                     this.router.navigateByUrl('/createPrototype');


    //                 });
    //         }
    //     }
    // }
    Edit(id) {
        var obj = {
            "query": id,
            "action": "view",
            "lang": "en"
        }
        //   this.data.setadminserviceflag("true");
        this.router.navigateByUrl('/toolbox/createPrototype?id=' + id + "&action=view");
        const reqObj = {
            'query': id,
            'lang': 'en'
        };
        // this.data.changeMessage('addproto');
        // console.log('draft');        
        // this.networkingService.post('/api/editPrototype', reqObj)
        //     .subscribe(adminform => {
        //         console.log('draft');
        //         this.adminforms.push(adminform);
        //         this.data.sendPrototypeData(adminform);
        //         this.router.navigateByUrl('/toolbox/createPrototype');
        //     });
    }
    viewPrototype(id) {
        this.data.changeMessage('true');
        // this.data.changeMessage('addproto');
        const reqObj = {
            'query': id,
            'lang': 'en'
        };
        this.networkingService.post('/api/editPrototype', reqObj)
            .subscribe(adminform => {
                this.data.sendPrototypeData(adminform);
                this.router.navigateByUrl('/toolbox/createPrototype');
            });
    }
    addProto() {
        this.data.sendPrototypeData(null);
        // this.data.changeMessage('addproto');
        this.data.changeMessage('false');
        this.router.navigateByUrl('/toolbox/createPrototype');
    }
    delete() {
        this.networkingService.delete('/api/prototypes/' + this.p_id)
            .subscribe(adminform => {
                this.deletetoast = true;
                const CurrentID = {
                    fileName: this.mail.id
                };
                this.networkingService.post('/api/loadAddedPrototypes/', CurrentID).subscribe(
                    (prototypes) => {
                        this.proNames = prototypes;

                    });
                this.deletetoast = true;
                setTimeout(() => {
                    this.deletetoast = false;
                }, 7000);




            });

        this.deleteDialog = !this.deleteDialog;
        window.scrollTo(0, 0);


    }
    closesignout() {
        this.deleteDialog = !this.deleteDialog;
    }
    closerejectbox() {
        this.RejectDialog = false;




    }
    gotoPrototypeDetail(id, prototype) {
        this.data.changePrototype(prototype);
        this.router.navigate(['../toolbox/all categories/' + id]);
        window.scrollTo(0, 0);

    }

    gotoPrototypeDetailadmin(prototypeId, prototype) {
        this.data.changePrototype(prototype);
        this.router.navigate([prototypeId], {
            relativeTo: this.route
        });
        window.scrollTo(0, 0);
    }
    onCategoryClick(categoryid) {
        const route = this.router.url;
        const splitRoute = route.split('/');
        if (splitRoute.length > 2) {
            this.router.navigate(['../', categoryid], {
                relativeTo: this.route
            });
        } else {
            this.router.navigate([categoryid], {
                relativeTo: this.route
            });
        }
    }
    modalPopUp() {
        if (this.i === 0) {

            this.showDialog = !this.showDialog;
        }
        this.submitdisable = !this.submitdisable;
    }
    approvePrototype(id) {
        const newapprovedate = new Date(Date.now());


        // this.newapprovedate = this.date.toLocaleString('en-IN', tshis.options);
        this.newapprovedate = this.date.toLocaleString('en-IN', this.options);

        const reqObj = {
            status: 'Approved',
            approvedDate: this.newapprovedate
        };
        const CurrentID = {
            fileName: this.mail.id,
            admin: this.mail.admin
        };
        this.networkingService.put('/api/approvePrototype/' + id, reqObj).subscribe(data => {
            this.networkingService.post('/api/loadPendingPrototypes/', CurrentID).subscribe(
                (prototypes) => {
                    this.proNames1 = prototypes;
                });
        });
    }
    rejectPrototype(id) {
        const reqObj = {
            status: 'Rejected'
        };
        const CurrentID = {
            fileName: this.mail.id,
            admin: this.mail.admin
        };
        this.networkingService.put('/api/rejectPrototype/' + id, reqObj).subscribe(data => {
            this.networkingService.post('/api/loadPendingPrototypes/', CurrentID).subscribe(
                (prototypes) => {
                    this.proNames1 = prototypes;

                });
        });
    }


    ngOnDestroy() {

    }
}

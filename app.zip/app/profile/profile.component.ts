import { ObjectAttributeRangeList } from 'aws-sdk/clients/clouddirectory';
import { any } from 'codelyzer/util/function';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { ValidateService } from '../services/validate.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { CompleterService, CompleterData } from 'ng2-completer';
import { NetWorkingService } from '../shared/networking.service';
import { DataService } from '../shared/data.service';
import { FileUploader, FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { ImagePreviewDirective } from '../toolbox/adminform/image-preview.directive';
import { LoadingModule } from 'ngx-loading';
import { TranslateService } from '@ngx-translate/core';

const URL = '/api/dpupload';


@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
    public loading: Boolean = false;
    deleteproto = false;
    editDpPopupflag = false;
    public dpImageUploader: FileUploader = new FileUploader({ url: URL, queueLimit: 1 });
    notification: any;
    _id: any;
    upNotification: any;
    item: any;
    doneBoolean = false;
    skilldoneboolean = false;
    dataflag: Array<Boolean> = [];
    dataflag1: Array<Boolean> = [];
    dataflag33: Array<Boolean> = [];
    dataflag34: Array<Boolean> = [];
    dataflag2 = false;
    dataflag3 = false;
    recommendinterestArray = [];
    recommendskillsArray = [];
    interestSectionBoolean = true;
    skillsArrayRecommendation: Boolean = true;
    interestArrayRecommendation: Boolean = true;
    skillSectionBoolean = true;
    protected dataService: CompleterData;
    protected skillDataService: CompleterData;
    profileCompletion: false;
    progress1: boolean;
    user: any;
    username: string;
    interestArray = [];
    skillsArray = [];
    interest = [];
    skill = [];
    skills = [];
    show = false;
    skillshow = false;
    role: string;
    department: string;
    topRole: string;
    description_urself: string;
    topDepartment: string;
    flag1 = true;
    flag2 = false;
    flag3 = false;
    flag4 = false;
    savetoast = false;
    crowdSourcing: Boolean = false;
    experience: number;
    enterrole: '';
    notifiComment: Boolean = false;
    recommendLength = [];
    notifiPeoplerating: Boolean = false;
    notifiPlaylist: Boolean = false;
    notifiEvent: Boolean = false;
    // notifiRating: Boolean = false;
    notifiPeopleEvent: Boolean = false;
    // profile_view_addskillset: Boolean = false;
    ProfileName: string;
    Initial: string;
    Skills: string;
    Interests: string;
    searchStr: string;
    user2: any;
    userData: any;
    userSettingObj: any;
    userSaveData: any;
    settingsObj: any;
    rewardsPoints: any;
    rewardsLoginPoints: any;
    firstLogin: Boolean = true;
    userRewards: Array<any> = [];
    displayPic: string;
    profileProgress: number;
    profileSection: Boolean;
    skillSetSection: Boolean;
    userStream: Boolean;
    date = new Date();
    newDate: any;
    options = {
        year: 'numeric', month: 'short',
        day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
    };
    // enterrole:'';
    Department = [{
        name: 'Cognizant Digital Business-Interactive Design'
    }, {
        name: 'Cognizant Digital Business-Development'
    }, {
        name: 'Cognizant Digital Business-TechnicalSupport'
    }, {
        name: 'CDB-INT-PnR'
    }, {
        name: 'CDB-INT-DRC-Design'
    }, {
        name: 'CDB-INT-D-DigitalExpDesign-DRC'
    }, {
        name: 'Product Mgr-Mobility'
    }, {
        name: 'CDE-Cloud Lift'
    }, {
        name: 'Cognizant Infra Services'
    }, {
        name: 'Catalyst'
    }, {
        name: 'CDB-INT-Cust-Exp-Channel'
    }, {
        name: 'Others'
    }];
    Role = [{
        name: 'Interaction Designer'
    }, {
        name: 'Developer'
    }, {
        name: 'Support Role'
    }, {
        name: 'Sr. Analyst - Biz Development'
    }, {
        name: 'Manager - Projects'
    }, {
        name: 'Technical Consultant'
    }, {
        name: 'Associate - Projects'
    }, {
        name: 'Technology Lead'
    }, {
        name: 'Product Mgr-Mobility'
    }, {
        name: 'Architect - Technology'
    }, {
        name: 'Sr. Manager - Projects'
    }, {
        name: 'Assoc. Director - Projects'
    }, {
        name: 'Sr. Architect - Technology'
    }, {
        name: 'Senior Director'
    }, {
        name: 'Programmer Analyst'
    }, {
        name: 'Others'
    }];
    recommendedSection = ['Interaction Design', 'Information Design', 'Prototyping', 'Usability Testing'];
    interestSection = ['Material Design', 'IOS', 'RWD', 'Chatbot', 'Omni Channel'];
    protected searchData = [{
        color: 'Artificial Intelligence',
        value: '#f00'
    }, {
        color: 'Artificial ',
        value: '#f00'
    }, {
        color: 'Invision',
        value: '#0f0'
    }, {
        color: 'Axure',
        value: '#00f'
    }, {
        color: 'Block Chain',
        value: '#0ff'
    }, {
        color: 'Enterprise Mobile',
        value: '#f0f'
    }, {
        color: 'Internet of things',
        value: '#ff0'
    }, {
        color: 'Augmented Reality',
        value: '#000'
    }, {
        color: 'Virtual Reality',
        value: '#000'
    }, {
        color: 'Website',
        value: '#000'
    }, {
        color: 'Bluetooth',
        value: '#000'
    }

    ];
    constructor(private validateService: ValidateService,
        private authService: AuthService,
        public toastr: ToastsManager,
        private data: DataService,
        private completerService: CompleterService,
        private networkingService: NetWorkingService,
        private translate: TranslateService
    ) {
        this.dataService = completerService.local(this.interestSection);
        this.skillDataService = completerService.local(this.recommendedSection);
    }

    ngOnInit() {
        this.user2 = JSON.parse(localStorage.getItem('user'));
        const username = this.user2.name;
        this.ProfileName = name;

        for (let i = 0; i < this.interestSection.length; i++) {
            this.dataflag[i] = false;
        }
        for (let i = 0; i < this.recommendedSection.length; i++) {
            this.dataflag1[i] = false;
        }
        this.networkingService.post('/users/getRewardsPoints', { id: this.user2.id }).subscribe(data => {
            this.rewardsPoints = data.totalPoints;
            this.userRewards = data.rewards;

        });

        this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
            this.displayPic = data.displayPicture;
            this.data.changeMessage(data.displayPicture);
            this.data.currentMessage.subscribe(Response => {
                this.displayPic = Response;
            });
            this.userData = {
                ProfileName: data.name,
                Initial: data.Initial,
                role: data.role,
                department: data.department,
                interestArray: data.InterestArray,
                skillsArray: data.skillsArray,
                progressflag0: data.progressFlag,
                progressflag1: data.progressFlag1,
                activityFeedProgress: data.activityFeedProgress,
                progressflag2: data.progressFlag2,
                progressflag3: data.progressFlag3,
                crowdSourcing: data.crowdSourcing,
                enterrole: data.enterrole,
                experience: data.experience,
                description_urself: data.description_urself,
                notifiComment: data.comment,
                notifiPlaylist: data.featuredPlaylist,
            };
            this.userSettingObj = {
                comment: data.comment,
                playlist: data.featuredPlaylist,
                event: data.event,
                peopleEvent: data.peopleEvent,
                userId: data.id,
                rating: data.rating
            };

            this.ProfileName = data.name;
            this.role = data.role;
            this.department = data.department;
            this.crowdSourcing = data.crowdSourcing;
            this.enterrole = data.enterrole;
            this.experience = data.experience;
            this.description_urself = data.description_urself;
            this.notifiComment = data.comment;
            this.notifiPeoplerating = data.rating;
            this.notifiPlaylist = data.featuredPlaylist;
            this.notifiPeopleEvent = data.peopleEvent
            this.profileProgress = data.Profileprogress;
            this.profileSection = data.profile
            this.skillSetSection = data.skillSet
            this.userStream = data.userStream;
            console.log('ps', this.profileSection);
            console.log('ss', this.skillSetSection);

            if (data.ldap === true) {
                for (var i = 0; i < this.Role.length; i++) {
                    if (this.role === this.Role[i].name) {
                        break;
                    }
                }
                if (i === (this.Role.length)) {
                    this.role = 'Others';
                }
                for (let i = 0; i < this.Department.length; i++) {
                    if (this.department === this.Department[i].name) {
                        break;
                    }
                }
                if (i === (this.Department.length)) {
                    this.department = 'Others';
                }
            }
            this.interestArray = data.InterestArray;
            this.skillsArray = data.skillsArray;
            var tempSCount = 0,
                tempICount = 0;
            this.interestArray.forEach(function (e) {
                if (e == 'Interaction Design' || e == 'Information Design' || e == 'Prototyping' || e == 'Usability Testing') {
                    tempSCount += 1;
                }
            })
            if (tempSCount == 4) {
                this.skillsArrayRecommendation = false;
            } else {
                this.skillsArrayRecommendation = true;
            }
            this.interestArray.forEach(function (e) {
                if (e == 'Material Design' || e == 'IOS' || e == 'RWD' || e == 'Chatbot' || e == 'Omni Channel') {
                    tempICount += 1;
                }
            })
            if (tempICount == 5) {
                this.interestArrayRecommendation = false;
            } else {
                this.interestArrayRecommendation = true;
            }
        });
        this.networkingService.post('/users/getnotification/' + this.user2.email, {}).subscribe((res) => {
            this.notification = res;
        });

    }
    backToCategoryList() {
        return true;
    }
    recommended() {
        this.show = !this.show;
        for (let i = 0; i < this.interestSection.length; i++) {
            this.dataflag[i] = false;
        }
        for (let j = 0; j < this.interestArray.length; j++) {
            for (let i = 0; i < this.interestSection.length; i++) {
                if (this.interestArray[j] === this.interestSection[i]) {
                    this.dataflag[i] = true;
                }
            }
        }
    }
    recommended1() {
        this.skillshow = !this.skillshow;
        console.log(this.recommendedSection, "recommendedSection");
        for (let i = 0; i < this.recommendedSection.length; i++) {
            this.dataflag1[i] = false;
        }
        console.log(this.skillsArray, "skillsArray");
        for (let j = 0; j < this.skillsArray.length; j++) {
            for (let i = 0; i < this.recommendedSection.length; i++) {
                if (this.skillsArray[j] === this.recommendedSection[i]) {
                    this.dataflag1[i] = true;
                }
            }
        }
        console.log(this.dataflag1);
    }
    skillsection(event) {
        if (event.key === 'Enter') {
            if (this.skillsArray.length === 0 && !this.skillSetSection)
                this.profileProgress += 20
            const skillssection = this.Skills.split(',');
            if (skillssection.length > 1) {
                for (const i in skillssection) {
                    if (skillssection.hasOwnProperty(i)) {
                        this.skillsArray.push(skillssection[i]);
                    }
                }
            } else {
                this.skillsArray.push(this.Skills);
            }
            const a = this.skillsArray;
            this.skillsArray = a.filter(function (item, pos) {
                return a.indexOf(item) === pos;
            });
            this.Skills = '';
            this.skilldoneboolean = true;
        }
    }
    interestsection(event) {
        if (event.key === 'Enter') {
            if (this.interestArray.length === 0 && this.description_urself !== '' && !this.profileSection)
                this.profileProgress += 5
            const interestsection = this.Interests.split(',');
            if (interestsection.length > 1) {
                for (const i in interestsection) {
                    if (this.interestArray.hasOwnProperty(i)) {
                        this.interestArray.push(interestsection[i]);
                    }
                }
            } else {
                this.interestArray.push(this.Interests);
            }
            const a = this.interestArray;
            this.interestArray = a.filter(function (item, pos) {
                return a.indexOf(item) === pos;
            });
            this.Interests = '';
        }
    }
    deleteclose() {
        this.deleteproto = false;
    }

    onCancel() {
        this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
            if (data !== '') {
                this.ProfileName = data.name;
                this.department = data.department;
                this.role = data.role;
                this.interestArray = data.InterestArray;
                this.skillsArray = data.skillsArray;
                this.enterrole = data.enterrole;
                this.description_urself = data.description_urself;
                this.notifiComment = data.comment;
                this.notifiPeoplerating = data.rating;
                this.notifiPlaylist = data.featuredPlaylist;
                this.notifiPeopleEvent = data.peopleEvent;
                this.profileProgress = data.Profileprogress
            }
            var tempCount = 0;
            this.interestArray.forEach(function (e) {
                if (e == 'Material Design' || e == 'IOS' || e == 'RWD' || e == 'Chatbot' || e == 'Omni Channel') {
                    tempCount += 1;
                }
            })
            if (tempCount == 5) {
                this.interestArrayRecommendation = false;
            } else {
                this.interestArrayRecommendation = true;
            }
        });
    }

    navClick1() {
        this.flag1 = true;
        this.flag2 = false;
        this.flag3 = false;
        this.flag4 = false;
        this.savetoast = false;
    }
    navClick2() {
        this.flag1 = false;
        this.flag3 = false;
        this.flag4 = false;
        this.flag2 = true;
        this.savetoast = false;
    }
    navClick3() {
        this.flag3 = true;
        this.flag1 = false;
        this.flag2 = false;
        this.flag4 = false;
        this.savetoast = false;

    }
    navClick4() {
        this.flag3 = false;
        this.flag1 = false;
        this.flag2 = false;
        this.flag4 = true;
        this.savetoast = false;

    }

    dataEnter(value, index) {
        this.dataflag[index] = !this.dataflag[index];
        if (this.dataflag[index]) {
            this.recommendinterestArray.push(value);
        } else if (!this.dataflag[index]) {
            const i = this.recommendinterestArray.indexOf(value);
            this.recommendinterestArray.splice(i, 1);
        }
        const a = this.recommendinterestArray;
        this.recommendinterestArray = a.filter(function (item, pos) {
            return a.indexOf(item) === pos;
        });
    }

    dataEnter1(value, index) {
        this.dataflag1[index] = !this.dataflag1[index];
        if (this.dataflag1[index]) {
            this.recommendskillsArray.push(value);
        } else if (!this.dataflag1[index]) {
            const i = this.recommendskillsArray.indexOf(value);
            this.recommendskillsArray.splice(i, 1);
        }
        const a = this.recommendskillsArray;
        this.recommendskillsArray = a.filter(function (item, pos) {
            return a.indexOf(item) === pos;
        });
    }

    closeinterest(index) {
        console.log("cross func called", index);
        for (let i = 0; i < this.interestSection.length; i++) {
            if (this.interestSection[i] === this.interestArray[index]) {
                this.dataflag[i] = !this.dataflag[i];
            }
        }
        for (let i = 0; i < this.dataflag.length; i++) {
            this.dataflag34[i] = this.dataflag[i];
        }
        this.interestArray.splice(index, 1);
        var tempCount = 0;
        this.interestArray.forEach(function (e) {
            if (e == 'Material Design' || e == 'IOS' || e == 'RWD' || e == 'Chatbot' || e == 'Omni Channel') {
                tempCount += 1;
            }
        })
        console.log(tempCount);
        if (tempCount == 5) {
            this.interestArrayRecommendation = false;
        } else {
            this.interestArrayRecommendation = true;
        }
    }
    closeinterestSkill(skill, index) {
        for (let i = 0; i < this.recommendedSection.length; i++) {
            if (this.recommendedSection[i] === this.skillsArray[index]) {
                this.dataflag1[i] = !this.dataflag1[i];
            }
        }
        for (let i = 0; i < this.dataflag1.length; i++) {
            this.dataflag33[i] = this.dataflag1[i];
        }
        this.skillsArray.splice(index, 1);
        var tempSCount = 0;
        this.interestArray.forEach(function (e) {
            if (e == 'Interaction Design' || e == 'Information Design' || e == 'Prototyping' || e == 'Usability Testing') {
                tempSCount += 1;
            }
        })
        if (tempSCount == 4) {
            this.skillsArrayRecommendation = false;
        } else {
            this.skillsArrayRecommendation = true;
        }
    }

    data2() {
        this.dataflag2 = !this.dataflag2;
        if (this.dataflag2) {
            this.interestArray.push('RWD');
        }
    }
    done() {
        if (this.interestArray.length === 0 && this.description_urself != '' && !this.profileSection)
            this.profileProgress += 5;
        this.show = !this.show;

        for (let i = 0; i < this.dataflag.length; i++) {
            this.dataflag34[i] = this.dataflag[i];
        }
        for (let i = 0; i < this.dataflag.length; i++) {
            if (this.dataflag[i]) {
                this.interestArray.push(this.interestSection[i]);
            } else if (!this.dataflag[i]) {

                for (let k = 0; k < this.interestArray.length; k++) {
                    if (this.interestSection[i] === this.interestArray[k]) {
                        const j = this.interestArray.indexOf(this.interestSection[i]);
                        this.interestArray.splice(j, 1);
                    }
                }
            }
        }
        const a = this.interestArray;
        this.interestArray = a.filter(function (item, pos) {
            return a.indexOf(item) === pos;
        });
        var tempCount = 0;
        this.interestArray.forEach(function (e) {
            if (e == 'Material Design' || e == 'IOS' || e == 'RWD' || e == 'Chatbot' || e == 'Omni Channel') {
                tempCount += 1;
            }
        })
        console.log(tempCount);
        if (tempCount == 5) {
            this.interestArrayRecommendation = false;
        } else {
            this.interestArrayRecommendation = true;
        }
    }
    done1() {
        if (this.skillsArray.length === 0 && !this.skillSetSection)
            this.profileProgress += 20;
        this.skillshow = !this.skillshow;

        for (let i = 0; i < this.dataflag1.length; i++) {
            this.dataflag33[i] = this.dataflag1[i];
        }
        for (let i = 0; i < this.dataflag1.length; i++) {
            if (this.dataflag1[i]) {
                this.skillsArray.push(this.recommendedSection[i]);
            } else if (!this.dataflag1[i]) {

                for (let k = 0; k < this.skillsArray.length; k++) {
                    if (this.recommendedSection[i] === this.skillsArray[k]) {
                        const j = this.skillsArray.indexOf(this.recommendedSection[i]);
                        this.skillsArray.splice(j, 1);
                    }
                }
            }
        }
        const a = this.skillsArray;
        this.skillsArray = a.filter(function (item, pos) {
            return a.indexOf(item) === pos;
        });
        var tempSCount = 0;
        this.interestArray.forEach(function (e) {
            if (e == 'Interaction Design' || e == 'Information Design' || e == 'Prototyping' || e == 'Usability Testing') {
                tempSCount += 1;
            }
        })
        if (tempSCount == 4) {
            this.skillsArrayRecommendation = false;
        } else {
            this.skillsArrayRecommendation = true;
        }
    }
    cancel() {
        this.show = !this.show;
        for (let i = 0; i < this.dataflag34.length; i++) {
            this.dataflag[i] = this.dataflag34[i];
        }
    }
    cancel1() {
        this.skillshow = !this.skillshow;
        for (let i = 0; i < this.dataflag33.length; i++) {
            this.dataflag1[i] = this.dataflag33[i];
        }
    }

    onSave(section) {
        this.deleteproto = true;

        this.userSaveData = {
            ProfileName: this.ProfileName,
            role: this.role,
            department: this.department,
            interestArray: this.interestArray,
            skillsArray: this.skillsArray,
            crowdSourcing: this.crowdSourcing,
            enterrole: this.enterrole,
            experience: this.experience,
            description_urself: this.description_urself,
            notifiComment: this.notifiComment,
            notifiPlaylist: this.notifiPlaylist,
            profileProgress: this.profileProgress,
            section: section
        };
        const userProfile = {
            user: this.userSaveData,
            emailId: this.user2.email
        };
        if (JSON.stringify(this.userData) === JSON.stringify(this.userSaveData)) {
        } else {
            this.networkingService.post('/users/profile', userProfile).subscribe(data => {
                this.profileProgress = data[0].Profileprogress;
                if (this.profileProgress === 100) {
                    this.profileCompleted(data[0]);
                }
                this.networkingService.post('/users/getnotification/' + this.user2.email, {}).subscribe((resdata) => {
                    this.data.profilenotify(resdata);
                });
                this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
                    this.profileSection = data.profile
                    this.skillSetSection = data.skillSet
                    this.userStream = data.userStream;
                });
            });
            this.savetoast = true;

            setTimeout(() => {
                this.savetoast = false;
            }, 7000);
            window.scrollTo(0, 0);
            this.userData = this.userSaveData;
            this.userSettingObj = this.settingsObj;
        }



    }
    saveActivityFeedSettings() {
        this.deleteproto = true;
        var profileProgress = this.profileProgress;
        if (!this.userStream)
            profileProgress = this.profileProgress + 20;
        this.settingsObj = {
            comment: this.notifiComment,
            playlist: this.notifiPlaylist,

            peopleEvent: this.notifiPeopleEvent,
            userId: this.user2.id,
            rating: this.notifiPeoplerating,
            profileProgress: profileProgress,
            emailId: this.user2.email,
            userStream: false,

        };
        if (JSON.stringify(this.userSettingObj) === JSON.stringify(this.settingsObj)) {

        } else {
            this.networkingService.put('/users/activityFeed', this.settingsObj).subscribe((Response) => {
                this.profileProgress = Response[0].Profileprogress;
                if (this.profileProgress === 100) {
                    this.profileCompleted(Response[0]);
                }
                window.scrollTo(0, 0);
                this.savetoast = true;
                this.networkingService.post('/users/getnotification/' + this.user2.email, {}).subscribe((resdata) => {
                    this.data.profilenotify(resdata);
                });
                this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
                    this.profileSection = data.profile
                    this.skillSetSection = data.skillSet
                    this.userStream = data.userStream;
                });
            });
            this.userSettingObj = this.settingsObj;
            this.userData = this.userSaveData;
        }

    }
    profileCompleted(obj) {
        this.networkingService.post('/users/profileRewardPoints', {
            id: obj.id,
            points: obj.totalPoints
        }).subscribe(res => {
            localStorage.setItem('user', JSON.stringify(res));
            this.networkingService.post('/users/getRewardsPoints', { id: this.user2.id }).subscribe(data => {
                this.rewardsPoints = data.totalPoints;
                this.userRewards = data.rewards;
                this.newDate = this.date.toLocaleString('en-IN', this.options);

                const notificationReward = {
                    email: this.user2.email,
                    ref_id: '',
                    notificationtag: 'profile',
                    message: 'You got XXXTYB points for Profile Completion',
                    notificationDate: this.newDate,
                    status: 'points',
                };
                this.networkingService.post('/users/notification/', notificationReward).subscribe((response) => {
                });

            });
        });
    }
    cancelActivityFeedSettings() {
        this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
            if (data !== '') {
                this.notifiComment = data.comment;
                this.notifiPeoplerating = data.rating;
                this.notifiPlaylist = data.featuredPlaylist;
                this.notifiPeopleEvent = data.peopleEvent;
            }

        });
    }
    editDpPopup(event) {
        if (this.dpImageUploader.queue.length !== 0) {
            this.editDpPopupflag = true;
            return this.editDpPopupflag;
        }
    }
    clearDp() {
        this.dpImageUploader.clearQueue();
    }
    cloaseEditDp() {
        this.editDpPopupflag = false;
        this.dpImageUploader.clearQueue();


    }
    uploadDp() {
        const formData = new FormData();
        const profileName = this.user2.email;
        const dis = this;
        this.dpImageUploader.queue.forEach((element) => {
            formData.append('dp', element._file, element._file.name);
        });
        this.networkingService.post(URL, formData).subscribe((output) => {
            this.loading = true;

            this.networkingService.put('/users/updateDp/', this.user2).subscribe((res) => {
                this.networkingService.post('/users/ViewProfile', { email: this.user2.email }).subscribe(data => {
                    setTimeout(() => {
                        dis.displayPic = data.displayPicture;
                        dis.data.changeMessage(data.displayPicture);
                        dis.data.currentMessage.subscribe(Response => {
                            if (Response !== 'AllPrototypes' && Response !== 'MyPrototypes') {
                                dis.displayPic = Response;
                            }
                            dis.loading = false;

                        });
                    }, 10000);
                });
            });

        });
        this.cloaseEditDp();
    }

}

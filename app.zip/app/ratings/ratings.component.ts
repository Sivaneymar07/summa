import { Component, OnInit } from '@angular/core';
import {RatingModule} from "ngx-rating";
@Component({
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.css']
})
export class RatingsComponent implements OnInit {
  starsCount: number;
  emptyIcon = "-";
  constructor() { }
  ngOnInit() {
  }
}

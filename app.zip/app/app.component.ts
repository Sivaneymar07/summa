import { Component, OnInit, HostListener } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { NgxPermissionsService } from 'ngx-permissions';
import { ActivatedRoute, Router, NavigationEnd, Params } from '@angular/router';
import { DataService } from './shared/data.service';
import {TranslateService} from '@ngx-translate/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  user: any;
  Click = false;
  rememberMe: any;
  checkCondition = true;
  dataLoaded: Promise <Boolean>
  // urlParams: any;
  location: any;
  constructor(
    private router: Router,
    private permissionsService: NgxPermissionsService,
    private data: DataService,
    private translate: TranslateService,
    private route: ActivatedRoute,

    ) {

      translate.setDefaultLang('en');
      translate.use('en');
      // this.location = this.router.url;
      
     }
    ngOnInit() {
      this.router.events.subscribe((event) => {
        if(event instanceof NavigationEnd ) {
        console.log(event.url)
        this.location = event.url;
        this.user = JSON.parse(localStorage.getItem('user'));
        window.scrollTo(0,0);
        }
    
    });

  //   this.router.events.subscribe((event) => {
  //     debugger
  //     this.location = event.url;
  //     if ( this.location == '/login' || this.location == '/landingpage' ) {
  //       this.checkCondition = false;
  //     }
  //     if (event instanceof NavigationEnd ) {
  //       window.scrollTo(0, 0);
  //       debugger
        
  //       console.log("this is the current route or page da mental.............", this.location);
        
  //       // this.route.queryParamMap.subscribe(params => {
  //       //   console.log(params,"paramsparams")
  //       //   this.urlParams = { ...params.keys, ...params };
  //       // });
  //     }

  // });
  // this.route = this.location.path();
  // console.log('This is the current location..', this.route);
    this.user = JSON.parse(localStorage.getItem('user'));
    // console.log("Thus is the location",this.location);
    if (this.user) {
    const perm = [this.user.userGroup];
    this.permissionsService.loadPermissions(perm);

    }
  }
}

import {
  Component, OnInit, Input, Output, OnChanges, EventEmitter,
  trigger, state, style, animate, transition
} from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
@Component({
  selector: 'app-userpermissions',
  templateUrl: './userpermissions.component.html',
  styleUrls: ['./userpermissions.component.css'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class UserpermissionsComponent implements OnInit {
  users: Array<any> = [];
  loading: Boolean = true;
  changeRole: Boolean = false;
  userGroups: Array<any> = [];
  multipleUser: Array<any> = [];
  multipleUserGroup: Array<any> = [];
  check: Boolean;
  userGroup: Array<any> = [];
  constructor(private networkingService: NetWorkingService) { }

  ngOnInit() {
    this.userGroups = [{ name: 'SUPERADMIN' }, { name: 'ADMIN' }, { name: 'CUSTOMER' }];
    this.networkingService.post('/users/getUsers',{}).subscribe(result => {
      this.loading = false;
      this.users = result;
    });
  }
  changedRole() {
    this.changeRole = !this.changeRole;
  }
  change(email, index) {
    const reqObj = {
      'query': {
        email: [email],
        group: this.userGroup[index]
      },
      'lang': 'en'
    };

    this.networkingService.put('/users/updateUserGroup', reqObj).subscribe(data => {

      this.networkingService.post('/users/getUsers',{}).subscribe(result => {
        this.users = result;
      });
      this.changeRole = !this.changeRole;
    });
  }

  multipleCheck(email, event) {
    if (event.toElement.checked) {
      this.multipleUser.push(email);
    } else {
      const index = this.multipleUser.indexOf(email);
      this.multipleUser.splice(index, 1);
    }
  }

  multipleChange() {
    const reqObj = {
      'query': {
        email: this.multipleUser,
        group: this.multipleUserGroup
      },
      'lang': 'en'
    };

    this.networkingService.put('/users/updateUserGroup', reqObj).subscribe(data => {

      this.networkingService.post('/users/getUsers',{}).subscribe(result => {
        this.users = result;
      });
      this.changeRole = !this.changeRole;
    });
  }

}


import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opportunity-details',
  templateUrl: './opportunity-details.component.html',
  styleUrls: ['./opportunity-details.component.css']
})
export class OpportunityDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

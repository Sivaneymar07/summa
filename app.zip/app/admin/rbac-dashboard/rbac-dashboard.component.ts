import { SortableModule } from 'ngx-bootstrap';
import { Component, OnInit, OnDestroy, Output, OnChanges, EventEmitter, trigger, state, style, animate, transition } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../shared/data.service';
import { NetWorkingService } from '../../shared/networking.service';
import { PrototypeInterface } from '../../shared/prototype.interface';
import { ServiceInterface } from '../../shared/service.interface';
import { requestInterface } from '../../shared/viewRequest.interface';
import { LoadingModule } from 'ngx-loading';
import * as moment from 'moment';
import { TranslateService } from '@ngx-translate/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@Component({
    selector: 'app-rbac-dashboard',
    templateUrl: './rbac-dashboard.component.html',
    styleUrls: ['./rbac-dashboard.component.css'],
    animations: [
        trigger('fade', [
            transition(':enter', [
                style({ transform: 'translateX(100%)' }),
                animate(700)
            ]),
            transition('* => void', [
                animate('0.5s 0.5s ease-out', style({
                    opacity: 0
                }))
            ])
        ])
    ]

})
export class RbacDashboardComponent implements OnInit, OnDestroy {
    tabValue = 'PendingRequest';
    headerFlag: any = [];
    reqId: any = [];
    Provisionflag: Boolean = false;
    archive: any = [];
    provisionSetup: any = [];
    prototypes: any = [];
    userData: any = [];
    databasket: any = [];
    public loading: Boolean = false;
    approvesavetoast: Boolean = false;
    crowdassign_savetoast: Boolean = false;
    instanceassign_savetoast: Boolean = false;
    rejectsavetoast: Boolean = false;
    proto_rejectsavetoast: Boolean = false;
    proto_approvesavetoast: Boolean = false;
    public sortInput = 'Request Due By';
    search_flag: Boolean = false;
    sortFlag: Boolean = true;
    // archiveSortFlag: Boolean = true;
    // public archiveSortInput = 'Approved On';
    search: any = [];
    searchdata: any = [];
    tempbasket: any = [];
    temparchive: any = [];
    archiveSearchArray: any = [];
    tempSearchArray: any = [];

    constructor(private networkingService: NetWorkingService, private route: ActivatedRoute,
        private router: Router, private data: DataService, private translate: TranslateService) { }

    ngOnInit() {
        this.provisionSetup = [];
        this.userData = JSON.parse(localStorage.getItem('user'));
        let response;
        this.loading = true;

        this.data.currentMessage.subscribe(res => {
            if (res) {
                response = JSON.stringify(res);
                response = JSON.parse(response);
                this.reqId = response.id;
                if (response.crowd === false && response.status === 'requestApproved') {
                    this.approvesavetoast = true;
                    setTimeout(() => {
                        this.approvesavetoast = false;
                    }, 5000);
                } else if (response.status === 'crowdSourced') {
                    this.crowdassign_savetoast = true;
                    setTimeout(() => {
                        this.crowdassign_savetoast = false;
                    }, 5000);
                } else if (response.status === 'instancesAssigned') {
                    this.instanceassign_savetoast = true;
                    setTimeout(() => {
                        this.instanceassign_savetoast = false;
                    }, 5000);
                } else if (response.status === 'requestRejected') {
                    this.rejectsavetoast = true;
                    setTimeout(() => {
                        this.rejectsavetoast = false;
                    }, 5000);
                } else if (response.status === 'PrototypeRejected') {
                    this.proto_rejectsavetoast = true;
                    setTimeout(() => {
                        this.proto_rejectsavetoast = false;
                    }, 5000);
                } else if (response.status === 'PrototypeApproved') {
                    this.proto_approvesavetoast = true;
                    setTimeout(() => {
                        this.proto_approvesavetoast = false;
                    }, 5000);
                }
            }
        });

        this.approvedRequest();
        const CurrentID = {
            fileName: this.userData.id,
            admin: this.userData.admin
        };
        this.networkingService.post('/users/loadPendingPlaylists/', {}).subscribe(
            (playlists) => {
                this.databasket = this.databasket.concat(playlists);
                this.networkingService.post('/api/loadPendingPrototypes', CurrentID).subscribe((prototypes) => {
                    this.databasket = this.databasket.concat(prototypes);
                    this.getPosts();

                });

            });
    }
    viewPlaylist(id, name) {
        this.data.changePrototype(name);
        this.router.navigateByUrl('/playlist/playlist-details?id=' + id + '&action=view');
    }
    // View Service Request
    viewServiceRequest(id, status) {
        const obj = {
            'query': id,
            'action': 'view',
            'lang': 'en'
        };
        this.data.changeMessage('true');
        if (status === 'Pending' || status === 'Resubmitted') {
            this.router.navigateByUrl('/servicebox/service-request/service-form?id=' + id + '&action=view');
        } else {
            this.router.navigateByUrl('/crowdSourcing?id=' + id);
        }
    }
    // View Prototype
    viewPrototype(id) {
        this.data.changeMessage('true');
        const reqObj = {
            'query': id,
            'lang': 'en'
        };
        this.networkingService.post('/api/editPrototype', reqObj)
            .subscribe(adminform => {
                this.data.sendPrototypeData(adminform);
                this.databasket = this.databasket.concat(adminform);
                this.router.navigateByUrl('/toolbox/createPrototype?id=' + id + '&action=view');
            });
    }
    getPosts() {
        const userObj = JSON.parse(localStorage.getItem('user'));
        const newService = {
            user_id: userObj.id,
            userGroup: userObj.userGroup
        };
        this.networkingService.post('/servicerequest/PendingServiceRequest/', {})
            .subscribe(serviceform => {
                this.loading = false;
                const i = 0;
                this.databasket = this.databasket.concat(serviceform);
                this.tempbasket = this.tempbasket.concat(this.databasket);
            });
    }
    approvedRequest() {
        this.archive.length = 0;
        this.networkingService.post('/api/loadApprovedPrototypes/', {}).subscribe(
            (prototypes) => {
                this.archive = this.archive.concat(prototypes);
                this.networkingService.post('/servicerequest/ApprovedService', {}).subscribe(
                    (requests) => {
                        this.archive = this.archive.concat(requests);
                        this.temparchive = this.temparchive.concat(this.archive);
                    });
            });
    }

    // Tab Switch
    tabChangeValue(changeValue) {
        this.tabValue = changeValue;
        this.sortInput = 'Approved On';
    }
    userconfig(id) {
        this.router.navigateByUrl('/servicebox/instance-assign?id=' + id + '&action=view');
    }
    leftBorderColor(duedata, uploaddata) {
        const options = {
            year: 'numeric',
            month: 'numeric',
            day: 'numeric' ,
        };
        const colorCheck = ['startingDate', 'remainingDate', 'overdue'];
        const curDate = new Date();
        const parsedDuedata = new Date(duedata);
        const parsedUploaddata = new Date(uploaddata);
        const startDate = moment(curDate.toLocaleString('en-US', options), 'MM/DD/YYYY');
        const endDate = moment(parsedUploaddata.toLocaleString('en-US', options), 'MM/DD/YYYY');
        const diffDates = endDate.diff(startDate, 'days');
        if (diffDates === 0) {
            return colorCheck[0];
        } else if (diffDates === -1 || diffDates === -2) {
            return colorCheck[1];
        } else {
            return colorCheck[2];
        }
    }
    provisionflag(id, i) {
        this.provisionSetup.length = this.databasket.length;
        this.provisionSetup[i] = true;
    }
    // Sort by
    sortBySelection(val) {
        if (val === this.sortInput) {
            this.sortFlag = !this.sortFlag;
        } else {
            this.sortFlag = true;
        }
        this.sortInput = val;

    }
    // archiveSortBySelection(archiveVal) {
    //     if (archiveVal === this.archiveSortInput) {
    //         this.archiveSortFlag = !this.archiveSortFlag;
    //     } else {
    //         this.archiveSortFlag = true;
    //     }
    //     this.archiveSortInput = archiveVal;
    // }
    // search based on Request id & request by
    sendSearchData(event) {
        if (this.search.length >= 3 && event.key !== 'Shift') {
            this.search_flag = true;
            this.tempSearchArray.length = 0;
            this.tempbasket.forEach((data) => {
                if ((data.req_id.toLowerCase().includes(this.search.toLowerCase()))) {
                    this.tempSearchArray = this.tempSearchArray.concat(data);
                } else if ((data.Requestername.toLowerCase().includes(this.search.toLowerCase()))) {
                    this.tempSearchArray = this.tempSearchArray.concat(data);
                }
            });
            this.databasket.length = 0;
            this.databasket = this.databasket.concat(this.tempSearchArray);
        } else {
            this.search_flag = false;
            this.databasket.length = 0;
            this.tempSearchArray.length = 0;
            this.databasket = this.databasket.concat(this.tempbasket);
        }
    }
    sendArchiveSearchData(event) {
        if (this.searchdata.length >= 3 && event.key !== 'Shift') {
            this.archiveSearchArray.length = 0;
            this.temparchive.forEach((data) => {
                if ((data.req_id.toLowerCase().includes(this.searchdata.toLowerCase()))) {
                    this.archiveSearchArray = this.archiveSearchArray.concat(data);
                } else if ((data.Requestername.toLowerCase().includes(this.searchdata.toLowerCase()))) {
                    this.archiveSearchArray = this.archiveSearchArray.concat(data);
                }
            });
            this.archive.length = 0;
            this.archive = this.archive.concat(this.archiveSearchArray);
        } else {
            this.archive.length = 0;
            this.archiveSearchArray.length = 0;
            this.archive = this.archive.concat(this.temparchive);
        }
    }
    ngOnDestroy() {
    }
}
// Sort by on due date, request type, status,requested on, approved date
@Pipe({
    name: 'DateSortPipe'
})
export class DateSortPipe implements PipeTransform {
    options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric' ,
    };
    transform(arr: any, sortInput: any, flag: any): any {
        let tempSortArr = [];
        tempSortArr = tempSortArr.concat(arr);
        tempSortArr.forEach((sortLoop) => {
            const reqDueDate = new Date(sortLoop.dueDate);
            const reqUploadDate = new Date(sortLoop.uploadDate);
            const parseReqUploadDate = reqUploadDate.toString();
            const parseReqDueDate = reqDueDate.toString();
            sortLoop.uploadDate = Date.parse(parseReqUploadDate);
            sortLoop.dueDate = Date.parse(parseReqDueDate);
        });
        if (flag) {
            if (sortInput !== '') {
                if (sortInput === 'Request Due By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.dueDate,
                            nameB = secondArray.dueDate;
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Requested On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.uploadDate,
                            nameB = secondArray.uploadDate;
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Status') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.status.toLowerCase(),
                            nameB = secondArray.status.toLowerCase();
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Request By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.Requestername.toLowerCase(),
                            nameB = secondArray.Requestername.toLowerCase();
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Approved On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.approvedDate,
                            nameB = secondArray.approvedDate;
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                }
            }
        } else {
            if (sortInput !== '') {
                if (sortInput === 'Request Due By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.dueDate,
                            nameB = secondArray.dueDate;
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Requested On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.uploadDate,
                            nameB = secondArray.uploadDate;
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Status') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.status.toLowerCase(),
                            nameB = secondArray.status.toLowerCase();
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Request By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.Requestername.toLowerCase(),
                            nameB = secondArray.Requestername.toLowerCase();
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (sortInput === 'Approved On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.approvedDate,
                            nameB = secondArray.approvedDate;
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                }
            }
        }
        return tempSortArr;
    }
}
// Sort based on Approved date
@Pipe({
    name: 'ApprovedDateSortPipe'
})
export class ApprovedDateSortPipe implements PipeTransform {
    options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric' ,
    };
    count = 0;
    stringSort() {

    }
    transform(arr: any, archiveSortInput: any, flag: any): any {
        let tempSortArr = [];
        tempSortArr = tempSortArr.concat(arr);
        tempSortArr.forEach((sortLoop) => {
            const requestApproveDate = new Date(sortLoop.approvedDate);
            const reqUploadDate = new Date(sortLoop.uploadDate);
            const parseReqUploadDate = reqUploadDate.toString();
            const parseReqApproveDate = requestApproveDate.toString();
            sortLoop.approvedDate = Date.parse(parseReqApproveDate);
            sortLoop.uploadDate = Date.parse(parseReqUploadDate);
        });
        if (flag) {
            if (archiveSortInput !== '') {
                if (archiveSortInput === 'Approved On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.approvedDate,
                            nameB = secondArray.approvedDate;
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (archiveSortInput === 'Requested On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.uploadDate,
                            nameB = secondArray.uploadDate;
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (archiveSortInput === 'Request By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.Requestername.toLowerCase(),
                            nameB = secondArray.Requestername.toLowerCase();
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                }
            }
        } else {
            if (archiveSortInput !== '') {
                if (archiveSortInput === 'Approved On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.approvedDate,
                            nameB = secondArray.approvedDate;
                        if (nameA > nameB) {
                            return 1;
                        }
                        if (nameA < nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (archiveSortInput === 'Requested On') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.uploadDate,
                            nameB = secondArray.uploadDate;
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (archiveSortInput === 'Request By') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.Requestername.toLowerCase(),
                            nameB = secondArray.Requestername.toLowerCase();
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                } else if (archiveSortInput === 'Status') {
                    tempSortArr.sort(function (firstArray, secondArray) {
                        const nameA = firstArray.status.toLowerCase(),
                            nameB = secondArray.status.toLowerCase();
                        if (nameA < nameB) {
                            return 1;
                        }
                        if (nameA > nameB) {
                            return -1;
                        }
                        return 0;
                    });
                }
            }
        }
        return tempSortArr;
    }
}

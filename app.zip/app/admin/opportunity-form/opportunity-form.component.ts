import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { LoadingModule } from 'ngx-loading';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FileUploader, FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { NetWorkingService } from '../../shared/networking.service';
import { DataService } from '../../shared/data.service';

@Component({
  selector: 'app-opportunity-form',
  templateUrl: './opportunity-form.component.html',
  styleUrls: ['./opportunity-form.component.css']
})
export class OpportunityFormComponent implements OnInit {
  public serviceAssetUploader: FileUploader = new FileUploader({ url: '/service/upload/' });
  
  constructor(private _location: Location,private networkingservice: NetWorkingService,private route: ActivatedRoute, public router: Router, private data: DataService) { }
  loading = false;
  urlParams: any;
  value = 1;  
  submitDialogform = false;
  Opportunitydescription:any;
  Opportunityowner:any;
  Message:any;
  Status:any;
  createddate:any;
  opportunityid:any;
  clientname:any;
  status = [
    { name: 'Not Reachable' },
    { name: 'Pending Clarification' },
    { name: 'Awaiting Response' },
    { name: 'Closed' }
  ];
  ngOnInit() {
    // this.value = this.value + 1;
    const currentDate = new Date();
    const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    this.createddate = currentDate.getDate() + ' ' + monthNames[currentDate.getMonth()] + ' ' + currentDate.getFullYear();
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    this.value =  parseInt(this.urlParams.params.len);
    this.opportunityid = 'OPP0000' + (this.value +1);
      console.log(this.opportunityid)
      console.log(this.urlParams.params.len,"this.urlParams.len")
      
  
    if (this.urlParams.params.id) {
    this.loading = true;    
      this.networkingservice.post('/opportunities/getopportunitiesform/' + this.urlParams.params.id,{}).subscribe(Response => {
        console.log('123123Response',Response);
        this.loading = false;    
        this.clientname = Response.clientname,
        this.createddate =Response.created_date,
        this.opportunityid =Response.opportunity_id,
        this.Status =Response.opportunity_status,
        this.Opportunityowner =Response.opportunity_owner,
        this.Opportunitydescription=Response.opportunity_description  
      })
    }
  }
  gotoPrevStep() {
    this.loading = false;
    this._location.back();
  }

  savedata(){
    const newOpportunity = {
      clientname:this.clientname,
      createddate:this.createddate,
      opportunityid:this.opportunityid,
      status:this.Status,
      Opportunityowner:this.Opportunityowner,
      Opportunitydescription:this.Opportunitydescription
    }
    this.networkingservice.post('/opportunities/createopportunities', newOpportunity).subscribe(data => {
      this.uploadAssets(data);
    })
    this.submitDialogform = true;
  }
  cancelService(){
    this.clientname = '';
    this.Status = '';
    this.Opportunitydescription = '';
     this.Opportunityowner = '';
  }
  uploadAssets(data) {
    console.log("ddddddddddddddddddddddddddddddddddddddddddddd,", data.opportunity_id)
    const formData = new FormData();
    this.serviceAssetUploader.queue.forEach((element) => {
      formData.append('opportunityAssets', element._file, element._file.name);
    });
    this.networkingservice.post('/opportunity/upload/' + data.opportunity_id + '/singleupload', formData).subscribe((output) => {

      console.log(output)
    });
  }
  sendmessage(){
    const messagecontent ={
      message:this.Message
    }
  }
  submit() {
    this.submitDialogform = !this.submitDialogform;
    this.router.navigate(['/admin/opportunity-tracker']);
  }
}

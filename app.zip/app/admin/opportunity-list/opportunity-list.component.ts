import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { LoadingModule } from 'ngx-loading';
import { Router, ActivatedRoute } from '@angular/router';
import { NetWorkingService } from '../../shared/networking.service';
import { DataService } from '../../shared/data.service';
import { FileUploader, FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { ClickOutsideModule } from 'ng-click-outside';
import { ExcelService } from '../../shared/excel.service';


@Component({
  selector: 'app-opportunity-list',
  templateUrl: './opportunity-list.component.html',
  styleUrls: ['./opportunity-list.component.css']
})
export class OpportunityListComponent implements OnInit {
  opportunityformdata:any;
  loading = false;
  opportunitylist = true;
  opencheckbox = false;
  toggleUp = false;
  selectedFile = null;
  exportdialogbox = false;
  popupCount = 0;
  bulkuploadData: any;
  checkedarray = [];
  public serviceAssetUploader: FileUploader = new FileUploader({ url: '/service/upload/' });
  
  
  constructor(private excelService: ExcelService,private route: ActivatedRoute,private _location: Location,public router: Router,private networkingservice: NetWorkingService,private data: DataService) { }

  ngOnInit() {
    this.loading = true;
    this.getleads();
  }
  getleads(){
    const obj={

    }
    this.networkingservice.post('/opportunities/getopportunities',obj)
    .subscribe(response => {
      this.loading = false;
      this.opportunityformdata = response;
console.log("response",this.opportunityformdata)
    })
  }
  opportunityform(){
    this.opportunitylist = !this.opportunitylist;
    
  }
  gotoform(){
    this.router.navigateByUrl('/admin/opportunity-form?len=' + this.opportunityformdata.length)

  }
  viewdata(id){
    var obj = {
      "query": id,
      "action": "view",
      "lang": "en"
    }
    this.router.navigateByUrl('/admin/opportunity-form?id=' + id + "&action=view");
  }
  bulkPopup(event) {
  // this.opportunitylist = !this.opportunitylist;
  
    if (this.serviceAssetUploader.queue.length !== 0) {
      console.log("serviceAssetUploader", this.serviceAssetUploader)
      this.uploadAsset()
     
  }
  
  } 
  uploadAsset() {
    this.loading = true;
    const formData = new FormData();
    this.serviceAssetUploader.queue.forEach((element) => {
      formData.append('opportunityAssets', element._file, element._file.name);
    });
    console.log("formData", formData)
    this.networkingservice.post('/opportunity/upload/'+ 'opportunityAssetsexecl/' +'bulkupload' ,formData).subscribe((output) => {
      this.loading = false;
      this.bulkuploadData = output;
      console.log(output,"ttessdf")
    this.getleads();
    
    });
    
  }
  onClickedOutside(e: Event) {
    this.popupCount++;
    console.log("asdfasd" , this.popupCount)
    
    if (this.popupCount === 1) {
      this.opportunitylist = true;
      this.popupCount = 0;
    }
  }
  checkbox(){
    this.opencheckbox = !this.opencheckbox;
    this.toggleUp = true;
  }
  checkboxclick(item){
    var opp = {
      "clientname":item.clientname,
      "opportunity_id":item.opportunity_id,
      "created_date":item.created_date,
      "opportunity_owner":item.opportunity_owner,
      "opportunity_description":item.opportunity_description
    };
    this.checkedarray.push(opp);

  }
  exportToExcel() {
    
    this.excelService.exportAsExcelFile(this.checkedarray, 'opportunity');
    this.exportdialogbox = true;
  }
  submit(){
    this.exportdialogbox = !this.exportdialogbox;
    this.opencheckbox = !this.opencheckbox;
    this.toggleUp = false;
    
  }
}

import {
  Component, OnInit, Input, Output, OnChanges, EventEmitter,
  trigger, state, style, animate, transition
} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-popup-dialog',
  templateUrl: './popup-dialog.component.html',
  styleUrls: ['./popup-dialog.component.css'],
  animations: [
    trigger('popupDialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class PopupDialogComponent implements OnInit {
  @Input() closable = true;
  @Input() visible: boolean;
  @Input() isVideoShown;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private router: Router) { }
  ngOnInit() { }
  close() {
    this.isVideoShown = !this.isVideoShown;
    console.log(this.isVideoShown, "Video close popup")
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }
}


import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ValidateService } from '../services/validate.service';
import { Subscription } from 'rxjs/Rx';
import { Location } from '@angular/common';
import { ClickOutsideModule } from 'ng-click-outside';
import { NgxPermissionsService } from 'ngx-permissions';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NetWorkingService } from '../shared/networking.service';
import { LoadingModule } from 'ngx-loading';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  playlistadded = false;
  Playlistid: any;
  initial: any = 0;
  categoryName: any;
  user: any;
  sentUser: any;
  message: string;
  search: string;
  token: string;
  authToken: string;
  item: any;
  loading = false;
  public categoriesNumber: number;
  location = '';
  categoryname = '';
  resObj = [];
  status: any;
  mail = [];
  mailHeader: any;
  notoficationable = false;
  requestObjpro: Object = {};
  userSubscription: Subscription;
  headerFlag: any;
  adminFlag: any;
  playlistDialog = false;
  signoutDialog = false;
  signoutDialogue = false;
  profiledropdown = false;
  signoutDialognew = false;
  zerolengthnotification = false;
  popupCount = 0;
  addProtoFlag: any;
  count = 1;
  notification = [];
  email: String;
  switchuser: Boolean;
  playlistnotified: any;
  displayPic: any;

  constructor(private authService: AuthService,
    private data: DataService,
    private route: ActivatedRoute,
    public router: Router,
    private _location: Location,
    private DataService: DataService,
    private permissionsService: NgxPermissionsService,
    private networkingService: NetWorkingService,

  ) { }
  ngOnInit() {
    this.item = localStorage.getItem('user');
    this.user = JSON.parse(this.item);
    console.log('user is here', this.user);
    if (this.user) {
      if (this.user.ldap) {
        this.mail = this.user.email.split('.');
        this.mailHeader = this.mail[0][0].concat(this.mail[1][0]);
      } else {
        this.mailHeader = this.user.email.slice(0, 2);
      }
      this.networkingService.post('/users/ViewProfile', { email: this.user.email }).subscribe(data => {
        this.displayPic = data.displayPicture;
        this.data.changeMessage(data.displayPicture);
        this.data.currentMessage.subscribe(Response => {
          if (typeof Response === 'string') {
            if (Response.includes('.jpg') || Response.includes('.png') || Response.includes('.jpeg')) {
              this.displayPic = Response;
            }
          }

        });
      });
    }
    this.modalPopUp();

  }


  expiration(Req_id) {
    this.router.navigateByUrl('/servicebox/instance-assign?id=' + Req_id + '&action=extend');
  }
  manage() {
    this.signoutDialogue = !this.signoutDialogue;
  }
  view(id) {
    this.networkingService.get('/api/notificationview/' + id).subscribe((res) => {
      this.data.changePrototype(res[0]);
      this.categoryName = res[0].category_name;
      const pid = res[0].prototype_id;
      if (this.categoryName.indexOf(' ') !== -1) {
        this.categoryName = this.categoryName.split(' ');
        this.categoryName = this.categoryName[0] + '%20' + this.categoryName[1];
      }
      this.router.navigateByUrl('/toolbox/' + this.categoryName + '/' + pid);
      window.scrollTo(0, 0);
    });
    this.zerolengthnotification = false;
  }
  newMessage() {
    this.categoriesNumber = this.router.url.split('/').length - 1;
    if (this.categoriesNumber === 3) {
      this.router.navigateByUrl('/toolbox/All%20Categories');
    }
  }
  toggle() {
    this.profiledropdown = !this.profiledropdown;
  }
  toggleforzerolength() {
    this.zerolengthnotification = !this.zerolengthnotification;
  }
  modalPopUp() {
    if (this.initial === 0) {
      this.initial++;
    }
  }
  signout() {
    this.signoutDialog = !this.signoutDialog;
  }
  closesignout() {
    this.signoutDialog = !this.signoutDialog;
  }

  onLogoutClick() {
    this.authService.logout();
    this.permissionsService.flushPermissions();
    this.router.navigate(['/login']);
    return false;
  }
  navClick() {
    this.data.changeMessage('AllPrototypes');
  }

  ingore() {
    this.playlistDialog = false;
  }
  onClickedOutside(e: Event) {
    this.popupCount++;
    if (this.popupCount === 2) {
      this.profiledropdown = false;
      this.zerolengthnotification = false;
      this.signoutDialogue = false;
      this.popupCount = 0;
    }
  }
}


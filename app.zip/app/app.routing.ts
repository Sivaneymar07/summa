
import { Routes, RouterModule } from '@angular/router';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { ToolboxComponent } from './toolbox/toolbox.component';
import { ServiceboxComponent } from './servicebox/servicebox.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CategoryListComponent } from './toolbox/category-list/category-list.component';
import { PrototypeListComponent, CategoryPipe, SortPipe } from './toolbox/prototype-list/prototype-list.component';
import { PrototypeDetailComponent, ReviewersortPipe, CapitalizeFirst, RevHighlightssortPipe } from './toolbox/prototype-detail/prototype-detail.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdminformComponent } from './toolbox/adminform/adminform.component';
import { ServiceRequestComponent } from './servicebox/service-request/service-request.component';
import { ServiceFormComponent } from './servicebox/service-form/service-form.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './guards/auth.guard';
import { ChatbotComponent } from './chatbot/chatbot.component';
import { SimilarPrototypeComponent } from './similar-prototype/similar-prototype.component';
import { LandingPageComponent, ReversePipe } from './landing-page/landing-page.component';
import { DialogComponent } from './dialog/dialog.component';
import { PopupDialogComponent } from './popup-dialog/popup-dialog.component';
import { SearchComponent } from './search/search.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { UserpermissionsComponent } from './admin/userpermissions/userpermissions.component';
import { ProfileComponent } from './profile/profile.component';
import { AboutteamComponent } from './aboutteam/aboutteam.component';
import { LaunchPadComponent } from './launch-pad/launch-pad.component';
import { InstanceAssignComponent } from './servicebox/instance-assign/instance-assign.component';
import { VerificationComponent } from './verification/verification.component';
import { CrowdSourcingComponent } from './servicebox/crowd-sourcing/crowd-sourcing.component';
import { RbacDashboardComponent, DateSortPipe, ApprovedDateSortPipe } from './admin/rbac-dashboard/rbac-dashboard.component';
import { PlaylistDetailsComponent } from './playlist/playlist-details/playlist-details.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { MyProjectComponent } from './my-project/my-project.component';
import { CampaignComponent } from './campaign/campaign.component';
import { CampaignDetailsComponent } from './campaign/campaign-details/campaign-details.component';
import { CampaignListComponent } from './campaign/campaign-list/campaign-list.component';
import { RatingsComponent } from './ratings/ratings.component';
import { FeatureplaylistComponent } from './playlist/featureplaylist/featureplaylist.component';
import { FeaturePlaylistListComponent } from './playlist/feature-playlist-list/feature-playlist-list.component';
import { AdminComponent } from './admin/admin.component';
import { NotificationComponent } from './notification/notification.component';
import { FavoriteDetailsComponent } from './favorite-details/favorite-details.component';
import { OpportunityFormComponent } from './admin/opportunity-form/opportunity-form.component';
import { OpportunityDetailsComponent } from './admin/opportunity-details/opportunity-details.component';
import { OpportunityListComponent } from './admin/opportunity-list/opportunity-list.component';
import { SeeMoreActivityComponent } from './user-stream/see-more-activity/see-more-activity.component';
import { ProfileListComponent } from './user-stream/profile-list/profile-list.component';
// import { ForgotPasswordComponent } from './forgot-password/forgot-password.component'



const appRoutes: Routes = [
  {
    path: '', redirectTo: 'launch-pad', pathMatch: 'full'
  },
  {
    path: 'landingpage', component: LandingPageComponent, canActivate: [AuthGuard]
  },
  {
    path: 'verification', component: VerificationComponent
  },
  {
    path: 'contactUs', component: ContactUsComponent
  },
  {
    path: 'myProject', component: MyProjectComponent, canActivate: [AuthGuard]
  },
  {
    path: 'admin', component: AdminComponent, canActivate: [AuthGuard],
    children: [
      {
        path: 'rbac-dashboard', component: RbacDashboardComponent, canActivate: [AuthGuard]
      },
      {
        path: 'userpermissions', component: UserpermissionsComponent, canActivate: [AuthGuard]
      },
      {
        path: 'opportunity-tracker', component: OpportunityListComponent, canActivate: [AuthGuard]
      },
      {
        path: 'opportunity-form', component: OpportunityFormComponent, canActivate: [AuthGuard]
      },
      {
        path: 'opportunity-details', component: OpportunityDetailsComponent, canActivate: [AuthGuard]
      }
    ]
  },
  {
    path: 'profile', component: ProfileComponent, canActivate: [AuthGuard]
  },
  {
    path: 'playlist', component: PlaylistComponent, canActivate: [AuthGuard]
  },
  {
    path: 'playlist/playlist-details', component: PlaylistDetailsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'playlist/featureplaylist/:id', component: FeatureplaylistComponent, canActivate: [AuthGuard]
  },
  {
    path: 'playlist/feature-playlist-list', component: FeaturePlaylistListComponent, canActivate: [AuthGuard]
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'launch-pad', component: LaunchPadComponent
  },
  {
    path: 'aboutTeam', component: AboutteamComponent
  },
  {
    path: 'toolbox', component: ToolboxComponent, canActivate: [AuthGuard],
    children: [
      {
        path: 'createPrototype', component: AdminformComponent, canActivate: [AuthGuard]
      },
      {
        path: '', component: CategoryListComponent
      },
      // {path:'',redirectTo:'/toolbox',pathMatch:'full'},
      {
        path: ':id', component: PrototypeListComponent
      },
      {
        path: ':id/:prototypeId', component: PrototypeDetailComponent
      },

    ]
  },
  {
    path: 'campaign', component: CampaignComponent, canActivate: [AuthGuard],
    children: [
      {
        path: ':id', component: CampaignDetailsComponent
      },
      {
        path: '', component: CampaignListComponent
      }
    ]
  },
  {
    path: 'servicebox', component: ServiceboxComponent, canActivate: [AuthGuard],
    children: [
      {
        path: 'service-request/service-form', component: ServiceFormComponent
      },
      {
        path: 'service-request', component: ServiceRequestComponent
      },
      {  
      path: '', component: ServiceRequestComponent
      }
    ]
  },
  {
    path: 'crowdSourcing', component: CrowdSourcingComponent
  },
  {
    path: 'servicebox/instance-assign', component: InstanceAssignComponent, canActivate: [AuthGuard],
  },
  {
    path: 'favorites', component: FavoriteDetailsComponent
  },
  {
    path: 'see-more-activity', component: SeeMoreActivityComponent
  },
  {
    path: 'profileList', component: ProfileListComponent
  },
  // {
  //   path: 'forgot-password', component: ForgotPasswordComponent
  // },
  {
    path: '**', component: PageNotFoundComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [
  HeaderComponent,
  NotificationComponent,
  FooterComponent,
  ToolboxComponent,
  ServiceboxComponent,
  PageNotFoundComponent,
  CategoryListComponent,
  PrototypeListComponent,
  PrototypeDetailComponent,
  ApprovedDateSortPipe,
  AdminformComponent,
  ServiceRequestComponent,
  ServiceFormComponent,
  ChatbotComponent,
  LoginComponent,
  SimilarPrototypeComponent,
  LandingPageComponent,
  DialogComponent,
  PopupDialogComponent,
  SearchComponent,
  PlaylistComponent,
  UserpermissionsComponent,
  ProfileComponent,
  VerificationComponent,
  LaunchPadComponent,
  InstanceAssignComponent,
  AboutteamComponent,
  CrowdSourcingComponent,
  RbacDashboardComponent,
  PlaylistDetailsComponent,
  ContactUsComponent,
  MyProjectComponent,
  CampaignComponent,
  CampaignDetailsComponent,
  CampaignListComponent,
  RatingsComponent,
  FeatureplaylistComponent,
  AdminComponent,
  FeaturePlaylistListComponent,
  FavoriteDetailsComponent,
  OpportunityFormComponent,
  OpportunityDetailsComponent,
  OpportunityListComponent,
  SeeMoreActivityComponent,
  ProfileListComponent,
  // ForgotPasswordComponent
];

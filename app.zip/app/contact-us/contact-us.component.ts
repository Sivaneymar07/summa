import { Component, OnInit,  ViewChild } from '@angular/core';
import { NetWorkingService } from '../shared/networking.service';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})

export class ContactUsComponent implements OnInit {
  user: any;
  saveToast = false;
  entercontactName: boolean;
  entercontactEmail: boolean;
  entercontactMsg: boolean;
  contactName: string;
  contactEmail: string;
  contactMsg: string;
  disableFlag: boolean;
  constructor(private route: ActivatedRoute, private networkingservice: NetWorkingService, private router: Router) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    if ((this.contactName === '  ') || (this.contactEmail === '  ')) {
      this.disableFlag = true;
    } else {
      this.disableFlag = false;
    }
  }
  send() {
    const cdata = { query: this.contactEmail, params: this.contactMsg };
    this.networkingservice.post('/users/sendcontact/', cdata).subscribe(data => {
    });
    this.saveToast = true;
    setTimeout(() => {
      this.saveToast = false;
    }, 7000);
    window.scrollTo(0, 0);
    this.contactName = '  ';
    this.contactEmail = '  ';
    this.contactMsg = '  ';
  }

  setActiveInLogin(){
    this.router.navigateByUrl("/login?action=signUp");
  }
} 

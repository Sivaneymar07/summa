import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../shared/networking.service';
import { DataService } from '../shared/data.service';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  user: any;
  item: any;
  notification = [];
  favorite: Array<any> = [];
  count = 1;
  minuteFlag = true;
  minuteFlag4 = true;
  minuteFlag4c = true;
  hourFlag = false;
  hourFlag4 = false;
  hourFlag4c = false;
  dayFlag = false;
  dayFlag4 = false;
  dayFlag4c = false;
  hour: number;
  hour4: number;
  hour4c: number;
  day: number;
  day4: number;
  day4c: number;
  minute: number;
  minute4: number;
  minute4c: number;
  minuteFlag1 = true;
  hourFlag1 = false;
  dayFlag1 = false;
  hour1: number;
  day1: number;
  minute1: number;
  minuteFlag2 = true;
  hourFlag2 = false;
  dayFlag2 = false;
  hour2: number;
  day2: number;
  minute2: number;
  minuteFlag3 = true;
  dayFlag3 = false;
  hourFlag3 = false;
  day3: number;
  hour3: number;
  minute3: number;
  minuteFlag5 = true;
  dayFlag5 = false;
  hourFlag5 = false;
  hour5: number;
  minute5: number;
  day5: number;
  status: any;
  zerolengthnotification = false;
  categoryName: any;
  Playlistid: any;
  playlistnotified: any;
  playlistDialog = false;
  signoutDialog = false;
  signoutDialogue = false;
  profiledropdown = false;
  signoutDialognew = false;
  loading = false;
  playlistadded = false;
  sentUser: any;
  popupCount = 0;
  viewFav: Boolean = false;
  favorites: any;

  constructor(
    private networkingService: NetWorkingService,
    private data: DataService,
    private DataService: DataService,
    public router: Router,
  ) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    if (this.user) {
      var obj = { mail: this.user.email }
      this.networkingService.post('/users/getfavorite/', obj).subscribe((response) => {
        console.log(obj, response);
        this.favorites = response.favorites;
        this.loading = false;
        this.modalPopUp();
      })
    }
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (this.user) {
          console.log('calling');
          this.modalPopUp();
        }
      }
    });
  }
  modalPopUp() {
    console.log('called');
    var obj = { mail: this.user.email }
    this.networkingService.post('/users/getfavorite/', obj).subscribe((response) => {
      console.log(obj, response);
      this.favorites = response.favorites;
      this.loading = false;
    })
    console.log("hvbbnv ", this.user.userGroup);
    if (this.user.userGroup === 'SUPERADMIN') {
      this.networkingService.post('/users/notifications', {}).subscribe(
        (data: any[]) => {
          console.log("noti-data", data);
          for (let i = 0; i < data.length; i++) {
            if (data[i].notificationtag === 'profile' && data[i].email === this.user.email
              && (data[i].status === 'pending' || data[i].status === 'points')) {
              this.notification.push(data[i]);
              this.count = +1;
              const date1: any = new Date();
              const date2: string = this.notification[i].notificationDate;
              const diffInMs: number = -Date.parse(date2) + Date.parse(date1);
              const diffInHours: number = diffInMs / 1000 / 60 / 60;
              const seconds = (diffInMs / 1000).toFixed(1);
              const minutes = (diffInMs / (1000 * 60)).toFixed(1);
              const hours = (diffInMs / (1000 * 60 * 60)).toFixed(1);
              const days = (diffInMs / (1000 * 60 * 60 * 24)).toFixed(1);
              const min = (Number(minutes));
              const h = Number(hours);
              const d = Number(days);

              if (Number(minutes) > 60) {
                if (Number(hours) > 24) {
                  this.minuteFlag = false;
                  this.dayFlag = true;
                  this.hourFlag = false;
                  this.day = (Math.floor(d));
                } else {
                  this.minuteFlag = false;
                  this.hourFlag = true;
                  this.dayFlag = false;
                  this.hour = (Math.floor(h));
                }

              } else {
                this.minuteFlag = true;
                this.hourFlag = false;
                this.dayFlag = false;
                this.minute = Math.floor(min);
              }
            }
            if (data[i].notificationtag === 'Crowdsource') {
              this.notification.push(data[i]);
              this.count = +1;
              const date1c: any = new Date();
              const date2c: string = this.notification[i].notificationDate;
              const diffInMs4: number = -Date.parse(date2c) + Date.parse(date1c);
              const diffInHours4: number = diffInMs4 / 1000 / 60 / 60;
              const seconds4 = (diffInMs4 / 1000).toFixed(1);
              const minutes4 = (diffInMs4 / (1000 * 60)).toFixed(1);
              const hours4 = (diffInMs4 / (1000 * 60 * 60)).toFixed(1);
              const days4 = (diffInMs4 / (1000 * 60 * 60 * 24)).toFixed(1);
              const min4 = (Number(minutes4));
              const h4 = Number(hours4);
              const d4 = Number(days4);
              console.log(this.day4, this.hour4, this.minute4, 'time');
              if (Number(minutes4) > 60) {
                if (Number(hours4) > 24) {
                  this.minuteFlag4 = false;
                  this.dayFlag4 = true;
                  this.hourFlag4 = false;
                  this.day4 = (Math.floor(d4));
                } else {
                  this.minuteFlag4 = false;
                  this.hourFlag4 = true;
                  this.dayFlag4 = false;
                  this.hour4 = (Math.floor(h4));
                }

              } else {
                this.minuteFlag4 = true;
                this.hourFlag4 = false;
                this.dayFlag4 = false;
                this.minute4 = Math.floor(min4);
              }
              console.log(this.day4, this.hour4, this.minute4, 'time');
            }

            if (data[i].notificationtag === 'Prototype' && data[i].status === 'pending') {
              this.notification.push(data[i]);
              this.count = +1;
              const date1p: any = new Date();
              const date2p: string = this.notification[i].notificationDate;
              const diffInMs1: number = -Date.parse(date2p) + Date.parse(date1p);
              const diffInHours1: number = diffInMs1 / 1000 / 60 / 60;
              const seconds1 = (diffInMs1 / 1000).toFixed(1);
              const minutes1 = (diffInMs1 / (1000 * 60)).toFixed(1);
              const hours1 = (diffInMs1 / (1000 * 60 * 60)).toFixed(1);
              const days1 = (diffInMs1 / (1000 * 60 * 60 * 24)).toFixed(1);
              const min1 = (Number(minutes1));
              const h1 = Number(hours1);
              const d1 = Number(days1);
              if (Number(minutes1) > 60) {
                if (Number(hours1) > 24) {
                  this.minuteFlag1 = false;
                  this.dayFlag1 = true;
                  this.hourFlag1 = false;
                  this.day1 = (Math.floor(d1));
                } else {
                  this.minuteFlag1 = false;
                  this.hourFlag1 = true;
                  this.dayFlag1 = false;
                  this.hour1 = (Math.floor(h1));
                }

              } else {
                this.minuteFlag1 = true;
                this.hourFlag1 = false;
                this.dayFlag1 = false;
                this.minute1 = Math.floor(min1);
              }
            }
            if (data[i].notificationtag === 'ServiceRequest' && (data[i].status === 'pending' ||
              data[i].status === 'points' || data[i].status === 'Approved' || data[i].status === 'Rejected' ||
              data[i].status === 'Reverted' || data[i].status === 'Fulfilled' || data[i].status === 'Resubmitted')) {
              this.notification.push(data[i]);
              this.count = +1;
              if (data[i].notificationtag === 'ServiceRequest') {
                const date1s: any = new Date();
                const date2s: string = data[i].notificationDate;
                const diffInMs2: number = -Date.parse(date2s) + Date.parse(date1s);
                const diffInHours2: number = diffInMs2 / 1000 / 60 / 60;

                const seconds2 = (diffInMs2 / 1000).toFixed(1);
                const minutes2 = (diffInMs2 / (1000 * 60)).toFixed(1);
                const hours2 = (diffInMs2 / (1000 * 60 * 60)).toFixed(1);
                const days2 = (diffInMs2 / (1000 * 60 * 60 * 24)).toFixed(1);
                const min2 = (Number(minutes2));
                const h2 = Number(hours2);
                const d2 = Number(days2);
                if (Number(minutes2) > 60) {
                  if (Number(hours2) > 24) {
                    this.minuteFlag2 = false;
                    this.dayFlag2 = true;
                    this.hourFlag2 = false;
                    this.day2 = (Math.floor(d2));
                  } else {
                    this.minuteFlag2 = false;
                    this.hourFlag2 = true;
                    this.dayFlag2 = false;
                    this.hour2 = (Math.floor(h2));
                  }

                } else {
                  this.minuteFlag2 = true;
                  this.hourFlag2 = false;
                  this.dayFlag2 = false;
                  this.minute2 = Math.floor(min2);
                }
              }
            }
            if (data[i].notificationtag === 'Playlist' && (data[i].status === 'Pending' ||
              data[i] === 'points' || data[i].status === 'Approved' || data[i].status === 'Rejected')) {
              this.notification.push(data[i]);
              const date1pl: any = new Date();
              const date2pl: string = this.notification[i].notificationDate;
              const diffInMs3: number = -Date.parse(date2pl) + Date.parse(date1pl);
              const diffInHours3: number = diffInMs3 / 1000 / 60 / 60;

              const seconds3 = (diffInMs3 / 1000).toFixed(1);
              const minutes3 = (diffInMs3 / (1000 * 60)).toFixed(1);
              const hours3 = (diffInMs3 / (1000 * 60 * 60)).toFixed(1);
              const days3 = (diffInMs3 / (1000 * 60 * 60 * 24)).toFixed(1);
              const min3 = (Number(minutes3));
              const h3 = Number(hours3);
              const d3 = Number(days3);
              if (Number(minutes3) > 60) {
                if (Number(hours3) > 24) {
                  this.minuteFlag3 = false;
                  this.dayFlag3 = true;
                  this.hourFlag3 = false;
                  this.day3 = (Math.floor(d3));
                } else {
                  this.minuteFlag3 = false;
                  this.hourFlag3 = true;
                  this.dayFlag3 = false;
                  this.hour3 = (Math.floor(h3));
                }
              } else {
                this.minuteFlag3 = true;
                this.hourFlag3 = false;
                this.dayFlag3 = false;
                this.minute3 = Math.floor(min3);
              }
            }
            if (this.notification) {
              this.status = true;
            } else {
              this.status = false;
            }
          }
        },
        (error) => console.log(error)
      );
    } else {
      this.networkingService.post('/users/getnotification/' + this.user.email, {}).subscribe((resdata) => {
        this.data.profilenotify(resdata);
        console.log("get-noti", resdata);
      });
      this.data.MyprofileNotification.subscribe(res => {
        this.notification = [];
        for (let i = 0; i < res.length; i++) {
          if (res[i].notificationtag === 'profile') {
            if (res[i].status === 'pending' || res[i].status === 'points') {
              this.notification.push(res[i]);
              // console.log("inside profile",this.notification);
            } else {
              this.notification = [];
            }
          } else if (res[i].notificationtag === 'Prototype' || res[i].notificationtag === 'ServiceRequest' ||
            res[i].notificationtag === 'Playlist' || res[i].notificationtag === 'Campaign') {
            if (res[i].status === 'pending' || res[i].status === 'Approved' || res[i].status === 'Rejected' ||
              res[i].status === 'Expiring' || res[i].status === 'shared' || res[i].status === 'Fulfilled' ||
              res[i].status === 'Resubmitted' || res[i].status === 'points') {
              this.notification.push(res[i]);
            }
          }
          for (let k = 0; k < this.notification.length; k++) {
            if (this.notification[k].status === 'pending' || this.notification[k].status === 'Approved' ||
              this.notification[k].status === 'Rejected' || this.notification[k].status === 'Expiring' ||
              this.notification[k].status === 'shared' || this.notification[k].status === 'Deleted' || res[i].status === 'points') {
              this.status = true;
              this.count = +1;
              if (this.notification[k].notificationtag === 'profile') {
                const date1: any = new Date();
                const date2: string = this.notification[k].notificationDate;
                const diffInMs: number = -Date.parse(date2) + Date.parse(date1);
                const diffInHours: number = diffInMs / 1000 / 60 / 60;
                const seconds = (diffInMs / 1000).toFixed(1);
                const minutes = (diffInMs / (1000 * 60)).toFixed(1);
                const hours = (diffInMs / (1000 * 60 * 60)).toFixed(1);
                const days = (diffInMs / (1000 * 60 * 60 * 24)).toFixed(1);
                const min = (Number(minutes));
                const h = Number(hours);
                const d = Number(days);
                if (Number(minutes) > 60) {
                  if (Number(hours) > 24) {
                    this.minuteFlag = false;
                    this.dayFlag = true;
                    this.hourFlag = false;
                    this.day = (Math.floor(d));
                  } else {
                    this.minuteFlag = false;
                    this.hourFlag = true;
                    this.dayFlag = false;
                    this.hour = (Math.floor(h));
                  }
                } else {
                  this.minuteFlag = true;
                  this.hourFlag = false;
                  this.dayFlag = false;
                  this.minute = Math.floor(min);
                }
              }
              if (this.notification[k].notificationtag === 'Prototype') {
                const date1p: any = new Date();
                const date2p: string = this.notification[k].notificationDate;
                const diffInMs1: number = -Date.parse(date2p) + Date.parse(date1p);
                const diffInHours1: number = diffInMs1 / 1000 / 60 / 60;
                const seconds1 = (diffInMs1 / 1000).toFixed(1);
                const minutes1 = (diffInMs1 / (1000 * 60)).toFixed(1);
                const hours1 = (diffInMs1 / (1000 * 60 * 60)).toFixed(1);
                const days1 = (diffInMs1 / (1000 * 60 * 60 * 24)).toFixed(1);
                const min1 = (Number(minutes1));
                const h1 = Number(hours1);
                const d1 = Number(days1);
                if (Number(minutes1) > 60) {
                  if (Number(hours1) > 24) {
                    this.minuteFlag1 = false;
                    this.dayFlag1 = true;
                    this.hourFlag1 = false;
                    this.day1 = (Math.floor(d1));
                  } else {
                    this.minuteFlag1 = false;
                    this.hourFlag1 = true;
                    this.dayFlag1 = false;
                    this.hour1 = (Math.floor(h1));
                  }
                } else {
                  this.minuteFlag1 = true;
                  this.hourFlag1 = false;
                  this.dayFlag1 = false;
                  this.minute1 = Math.floor(min1);
                }
              }
              if (this.notification[k].notificationtag === 'ServiceRequest') {
                const date1s: any = new Date();
                const date2s: string = this.notification[k].notificationDate;
                const diffInMs2: number = -Date.parse(date2s) + Date.parse(date1s);
                const diffInHours2: number = diffInMs2 / 1000 / 60 / 60;

                const seconds2 = (diffInMs2 / 1000).toFixed(1);
                const minutes2 = (diffInMs2 / (1000 * 60)).toFixed(1);
                const hours2 = (diffInMs2 / (1000 * 60 * 60)).toFixed(1);
                const days2 = (diffInMs2 / (1000 * 60 * 60 * 24)).toFixed(1);
                const min2 = (Number(minutes2));
                const h2 = Number(hours2);
                const d2 = Number(days2);
                if (Number(minutes2) > 60) {
                  if (Number(hours2) > 24) {
                    this.minuteFlag2 = false;
                    this.dayFlag2 = true;
                    this.hourFlag2 = false;
                    this.day2 = (Math.floor(d2));
                  } else {
                    this.minuteFlag2 = false;
                    this.hourFlag2 = true;
                    this.dayFlag2 = false;
                    this.hour2 = (Math.floor(h2));
                  }
                } else {
                  this.minuteFlag2 = true;
                  this.hourFlag2 = false;
                  this.dayFlag2 = false;
                  this.minute2 = Math.floor(min2);
                }
              }
              if (this.notification[k].notificationtag === 'Playlist') {
                const date1pl: any = new Date();
                const date2pl: string = this.notification[k].notificationDate;
                const diffInMs3: number = -Date.parse(date2pl) + Date.parse(date1pl);
                const diffInHours3: number = diffInMs3 / 1000 / 60 / 60;
                const seconds3 = (diffInMs3 / 1000).toFixed(1);
                const minutes3 = (diffInMs3 / (1000 * 60)).toFixed(1);
                const hours3 = (diffInMs3 / (1000 * 60 * 60)).toFixed(1);
                const days3 = (diffInMs3 / (1000 * 60 * 60 * 24)).toFixed(1);
                const min3 = (Number(minutes3));
                const h3 = Number(hours3);
                const d3 = Number(days3);
                if (Number(minutes3) > 60) {
                  if (Number(hours3) > 24) {
                    this.minuteFlag3 = false;
                    this.dayFlag3 = true;
                    this.hourFlag3 = false;
                    this.day3 = (Math.floor(d3));
                  } else {
                    this.minuteFlag3 = false;
                    this.hourFlag3 = true;
                    this.dayFlag3 = false;
                    this.hour3 = (Math.floor(h3));
                  }
                } else {
                  this.minuteFlag3 = true;
                  this.hourFlag3 = false;
                  this.dayFlag3 = false;
                  this.minute3 = Math.floor(min3);
                }
              }
              if (this.notification[k].notificationtag === 'Campaign') {
                const date14c: any = new Date();
                const date24c: string = this.notification[k].notificationDate;
                const diffInMs4c: number = -Date.parse(date24c) + Date.parse(date14c);
                const diffInHours4c: number = diffInMs4c / 1000 / 60 / 60;
                const seconds4c = (diffInMs4c / 1000).toFixed(1);
                const minutes4c = (diffInMs4c / (1000 * 60)).toFixed(1);
                const hours4c = (diffInMs4c / (1000 * 60 * 60)).toFixed(1);
                const days4c = (diffInMs4c / (1000 * 60 * 60 * 24)).toFixed(1);
                const min4c = (Number(minutes4c));
                const h4c = Number(hours4c);
                const d4c = Number(days4c);
                if (Number(minutes4c) > 60) {
                  if (Number(hours4c) > 24) {
                    this.minuteFlag4c = false;
                    this.dayFlag4c = true;
                    this.hourFlag4c = false;
                    this.day4c = (Math.floor(d4c));
                  } else {
                    this.minuteFlag4c = false;
                    this.hourFlag4c = true;
                    this.dayFlag4c = false;
                    this.hour4c = (Math.floor(h4c));
                  }
                } else {
                  this.minuteFlag4c = true;
                  this.hourFlag4c = false;
                  this.dayFlag4c = false;
                  this.minute4c = Math.floor(min4c);
                }
              }

            } else {
              this.status = false;
            }

          }
        }
      });
    }
  }
  toggleforFav() {
    this.viewFav = !this.viewFav;
  }
  toggleforzerolength() {
    this.zerolengthnotification = !this.zerolengthnotification;
  }
  profileRoute() {
    this.zerolengthnotification = false;
  }

  view(id) {
    this.networkingService.get('/api/notificationview/' + id).subscribe((res) => {
      this.data.changePrototype(res[0]);
      this.categoryName = res[0].category_name;
      const pid = res[0].prototype_id;
      if (this.categoryName.indexOf(' ') !== -1) {
        this.categoryName = this.categoryName.split(' ');
        this.categoryName = this.categoryName[0] + '%20' + this.categoryName[1];
      }
      this.router.navigateByUrl('/toolbox/' + this.categoryName + '/' + pid);
      window.scrollTo(0, 0);
    });
  }
  PlaylistPopup(Playlistid, sentuser) {
    // this.Playlistid = Playlistid;
    this.playlistDialog = true;
    this.loading = true;
    this.sentUser = sentuser;
    const getplaylists = {
      playlistid: this.Playlistid,
      notificationplaylist: 'notification'
    };
    this.networkingService.post('/users/getPlaylist', getplaylists).subscribe(Response => {
      this.playlistnotified = Response;
    });
  }
  addToMyPlaylist() {
    const obj = {
      array: this.user.id,
      playlistid: this.Playlistid,
    };
    this.networkingService.post('/users/pushUsers', obj).subscribe(Response => {
      console.log(Response);
    });
    this.playlistDialog = false;
    this.playlistadded = true;
    setTimeout(() => {
      this.playlistadded = false;
    }, 7000);
  }
  closeplaylistdialog() {
    this.playlistDialog = false;
  }
  ingore() {
    this.playlistDialog = false;
  }
  onClickedOutside(e: Event) {
    this.popupCount++;
    if (this.popupCount === 2) {
      this.profiledropdown = false;
      this.zerolengthnotification = false;
      this.viewFav = false;
      this.signoutDialogue = false;
      this.popupCount = 0;
    }
  }
  gotoPrototypeDetail(id, prototype) {
    this.viewFav = false;
    this.data.changePrototype(prototype);
    this.router.navigate(['../toolbox/All Categories/' + id]);
    window.scrollTo(0, 0);

  }
  goToFavDetail() {
    this.data.changeMessage(this.router.url)
  }
}

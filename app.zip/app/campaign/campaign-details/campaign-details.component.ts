import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { NetWorkingService } from '../../shared/networking.service';
import { LoadingModule } from 'ngx-loading';

@Component({
  selector: 'app-campaign-details',
  templateUrl: './campaign-details.component.html',
  styleUrls: ['./campaign-details.component.css']
})
export class CampaignDetailsComponent implements OnInit {
  date = new Date();
  newDate: any;
  public loading = false;
  skills = [];
  tcDialog = false;
  showEnrolled: Boolean;
  enrollPopup: Boolean = false;
  successPopup: Boolean = false;
  serviceId: String;
  serviceDetails = [];
  serviceFlag = true;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric'
  };
  enterRole: '';
  constructor(private route: ActivatedRoute, private router: Router, private networkingservice: NetWorkingService) { }

  ngOnInit() {
    this.showEnrolled = false;
    this.loading = true;
    const route = this.router.url;
    const splitRoute = route.split('/');
    this.serviceId = splitRoute[2];
    const campaignid = { req_id: this.serviceId };
    const userObj = JSON.parse(localStorage.getItem('user'));
    this.networkingservice.post('/servicerequest/viewcampaignDetails/', campaignid).subscribe(data => {
      this.serviceDetails = data[0];
      this.skills = data[0].skillsetneeded;
      // if (data[0].status !== 'Fulfilled') {
      //   this.serviceFlag = false;
      // }
    });
    this.networkingservice.post('/servicerequest/getenrollment', userObj)
      .subscribe(data => {
        this.loading = false;
        for (let i = 0; i <= data.length; i++) {
          if (data[i]) {
            if (data[i].service_id === this.serviceId) {
              this.showEnrolled = true;
            }
          }
        }
      });
  }
  submit() {
    this.successPopup = !this.successPopup;
  }
  enroll() {
    this.successPopup = true;
    this.enrollPopup = !this.enrollPopup;
  }
  cancelEnrollment() {
    this.enrollPopup = !this.enrollPopup;
    this.enterRole = '';
  }
  enrollPosition() {
    if (this.skills.length === 1) {
      this.enrollPopup = false;
      this.successPopup = true;
      this.nominate(this.serviceId);
    } else {
      this.enrollPopup = true;
    }

  }
  nominate(id) {
    if (this.skills.length === 1) {
      this.enterRole = this.skills[0];
    }
    this.showEnrolled = true;
    const userObj = JSON.parse(localStorage.getItem('user'));
    const nominee = { query: userObj.id };
    const campaignid = { req_id: id };
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    this.networkingservice.post('/servicerequest/viewcampaignDetails/', campaignid).subscribe(data => {
      const enrollments = {
        service_id: data[0].id,
        user_id: userObj.id,
        enrollment_date: this.newDate,
        role: this.enterRole
      };
      this.networkingservice.post('/users/enrolluser/', enrollments).subscribe(enrolldata => {
      });
    });
  }
  terms() {
    this.tcDialog = !this.tcDialog;
  }
  backToMyProject() {
    this.router.navigate(['/myProject'], {
      relativeTo: this.route
    });
  }

}

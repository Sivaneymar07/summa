import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { LoadingModule } from 'ngx-loading';

@Component({
  selector: 'app-campaign-list',
  templateUrl: './campaign-list.component.html',
  styleUrls: ['./campaign-list.component.css']
})
export class CampaignListComponent implements OnInit {
  campaign = [];
  campaignCount = 0;
  public loading = false;
   emptyArray = [];
  constructor(private networkingservice: NetWorkingService, private route: ActivatedRoute, private router: Router) { }
  ngOnInit() {
    this.loading = true;
    const userObj = JSON.parse(localStorage.getItem('user'));
          this.networkingservice.post('/users/getcampaign/', {}).subscribe(
      (services) => {
        this.loading = false;
        this.campaign = services;
        for (let i = 0; i < this.campaign.length; i++) {
          this.campaign[i].show = true;
        }
        this.networkingservice.post('/servicerequest/getenrollment', userObj)
          .subscribe(data => {
            this.loading = false;
            if (data.length > 0) {
              for (let i = 0; i <= data.length; i++) {
                for (let j = 0; j < services.length; j++) {
                  if (services[j]) {
                    if (data[i].service_id === services[j].id) {
                      this.campaign[j].show = false;
                    }
                  }
                }
                this.emptyArray = this.campaign;
                for (let k = 0; k < this.campaign.length; k++) {
                  if (this.emptyArray[k].show === false) {
                    this.emptyArray.splice(k, 1);
                  }
                }
                this.campaignCount = this.emptyArray.length;
              }
            } else {
              this.emptyArray = services;
              this.campaignCount = this.emptyArray.length;
            }
             console.log(this.emptyArray, 'campaign count');
          });
      });
  }
  backToMyProject() {
    this.router.navigate(['/myProject'], {
      relativeTo: this.route
    });
  }
  onCampaignClick(id) {
    this.router.navigate(['/campaign/' + id], {
      relativeTo: this.route
    });

  }
}

import { Component, OnInit } from '@angular/core';
import { RatingModule } from "ngx-rating";
import { NgxCarousel } from 'ngx-carousel';
// import {PrototypeService} from '../shared/prototype.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { CommonInterface } from '../shared/common.interface';
import { DataService } from '../shared/data.service';
import { NetWorkingService } from '../shared/networking.service';

@Component({
    selector: 'app-similar-prototype',
    templateUrl: './similar-prototype.component.html',
    styleUrls: ['./similar-prototype.component.css']
})
export class SimilarPrototypeComponent implements OnInit {
    public similarcarouselTile: NgxCarousel;
    prototypes = [];
    public proto: any[] = [];
    routeArray = [];
    show_carousel = true;
    id: string;
    value: any;
    routes: string;
    prototypeFileName = '';
    carouselTileItems = [];
    public carousel: any[] = [];
    prototypeSubscription: Subscription;

    constructor(private networkingService: NetWorkingService, private data: DataService,
        private route: ActivatedRoute, private router: Router) {
        this.proto;
    }
    ngOnInit() {
        this.route.params.subscribe(
            (params) => {
                this.prototypeFileName = params['id'];
                this.routes = (this.router.url);
                this.routeArray = this.routes.split('/');
                this.id = this.routeArray[this.routeArray.length - 1];
                const currentID = {
                    fileName: this.id,
                    currentFile: this.prototypeFileName
                };
                this.networkingService.post('/api/similarprototypes/', currentID).subscribe(
                    (prototypes) => {
                        this.proto = prototypes;
                    });
            });
        this.similarcarouselTile = {
            grid: {
                xs: 2,
                sm: 3,
                md: 3,
                lg: 6,
                all: 0
            },
            slide: 5,
            speed: 400,
            animation: 'lazy',
            load: 2,
            point: {
                visible: true
            },
            touch: true,
            loop: true,
            easing: 'ease'
        };
    }
    gotoPrototypeDetail(prototypeId, prototype) {
        this.data.changePrototype(prototype);
        this.router.navigate(['../', prototypeId], {
            relativeTo: this.route
        });
        window.scrollTo(0, 0);
    }
    public carouselTileLoad(evt: any) { }
}

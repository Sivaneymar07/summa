import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimilarPrototypeComponent } from './similar-prototype.component';

describe('SimilarPrototypeComponent', () => {
  let component: SimilarPrototypeComponent;
  let fixture: ComponentFixture<SimilarPrototypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimilarPrototypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimilarPrototypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

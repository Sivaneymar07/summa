import { CompileTemplateSummary } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service';
import { NetWorkingService } from '../shared/networking.service';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { NgxCarousel } from 'ngx-carousel';
import { LoadingModule } from 'ngx-loading';
import { MomentModule } from 'angular2-moment';
import * as moment from 'moment';

@Component({
  selector: 'app-my-project',
  templateUrl: './my-project.component.html',
  styleUrls: ['./my-project.component.css']
})
export class MyProjectComponent implements OnInit {
  viewPopup: any = [];
  campaign = [];
  projectCount = 0;
  archiveCount = 0;
  public carouselTile: NgxCarousel;
  public loading = false;
  email: any;
  serviceRequestDetails: string;
  campaignFlag = false;
  myProjects = [];
  archive = [];
  instanceUrl = [];
  authToken: string;
  choose_tab = 'ActiveProjects';
  showEnrolled = false;
  showLegend = true;
  rowIndex = 0;
  minusq = [];
  campaignCount = 0;
  showCarousel = true;
  activeEnrollment = [];
  emptyArray = [];
  constructor(private data: DataService, private networkingservice: NetWorkingService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.loading = true;
    this.networkingservice.post('/users/getcampaign/', {}).subscribe(
      (services) => {
        this.loading = false;
        this.campaign = services;
        for (let i = 0; i < this.campaign.length; i++) {
          this.campaign[i].show = true;
        }
        this.networkingservice.post('/servicerequest/getenrollment', userObj)
          .subscribe(data => {
            this.loading = false;
            if (data.length > 0) {
              for (let i = 0; i <= data.length; i++) {
                for (let j = 0; j < services.length; j++) {
                  if (services[j]) {
                    if (data[i].service_id === services[j].id) {
                      this.campaign[j].show = false;
                    }
                  }
                }
                this.emptyArray = this.campaign;
                for (let k = 0; k < this.campaign.length; k++) {
                  if (this.emptyArray[k].show === false) {
                    this.emptyArray.splice(k, 1);
                  }
                }
                this.campaignCount = this.emptyArray.length;
              }
            } else {
              this.emptyArray = services;
              this.campaignCount = this.emptyArray.length;
            }
          });
        console.log(this.campaignCount, 'campaigncount');
      });

    const userObj = JSON.parse(localStorage.getItem('user'));
    this.email = userObj.email;

    this.networkingservice.post('/servicerequest/getserviceinstancerequest', userObj)
      .subscribe(getserviceinstancerequest => {
        for (let i = 0; i < getserviceinstancerequest.length; i++) {
          getserviceinstancerequest[i].services_id.duration = this.timeinterval(getserviceinstancerequest[i].services_id.approvedDate, getserviceinstancerequest[i].services_id.dueDate);
          if (getserviceinstancerequest[i].services_id.status === 'Expired') {
            this.archive.push(getserviceinstancerequest[i].services_id);
            this.archiveCount = this.archive.length;
          } else if (getserviceinstancerequest[i].services_id.status === 'Fulfilled') {
            this.myProjects.push(getserviceinstancerequest[i].services_id);
          }
          this.instanceUrl.push(getserviceinstancerequest[i].instance_id.url);
        }
        this.projectCount = this.myProjects.length;
        this.showLegendfunc();
      });

    this.networkingservice.post('/servicerequest/getactiveenrollments', userObj)
      .subscribe(data => {
        console.log(data, 'statusdata');
        this.projectCount = this.myProjects.length;
        this.activeEnrollment = data;
        for (let i = 0; i < data.length; i++) {
          const id = { id: data[i].service_id.id };
          const assignedusers = [];
          if (data[i].service_id.status === 'Pending Provisioning') {
            this.networkingservice.post('/servicerequest/getassignedusers', id).subscribe(datas => {
              data[i].service_id.status = 'rejected';
              for (let j = 0; j < datas.assigned_users.length; j++) {
                if (datas.assigned_users[j].id === userObj.id) {
                  data[i].service_id.status = 'Pending Provisioning';
                }
              }
            });
            data[i].service_id.duration = this.timeinterval(data[i].service_id.approvedDate, data[i].service_id.dueDate);
            data[i].service_id.enrolledUser = true;
            this.myProjects.push(data[i].service_id);
          } else if (data[i].service_id.status === 'Fulfilled') {
            let rejectflag = true;
            this.networkingservice.post('/servicerequest/getassignedusers', id).subscribe(datas => {
              data[i].service_id.status = 'rejected';
              for (let j = 0; j < datas.assigned_users.length; j++) {
                if (datas.assigned_users[j].id === userObj.id) {
                  data[i].service_id.status = 'Fulfilled';
                  rejectflag = false;
                }
                if (j === (datas.assigned_users.length - 1)) {
                  if (rejectflag) {
                    data[i].service_id.duration = this.timeinterval(data[i].service_id.approvedDate, data[i].service_id.dueDate);
                    data[i].service_id.enrolledUser = true;
                    this.myProjects.push(data[i].service_id);
                  }
                }
              }
            });
          } else if (data[i].service_id.status === 'Pending Resources') {
            data[i].service_id.duration = this.timeinterval(data[i].service_id.approvedDate, data[i].service_id.dueDate);
            data[i].service_id.enrolledUser = true;
            this.myProjects.push(data[i].service_id);
          }

        }
        this.projectCount = this.myProjects.length;
        this.showLegendfunc();
      });

    this.carouselTile = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };

  }
  viewpopup(index) {
    this.viewPopup.length = this.myProjects.length;
    this.viewPopup[index] = true;
  }
  timeinterval(startTime, endTime) {
    const start = moment(startTime);
    const end = moment(endTime);
    return end.diff(start, 'days');
  }
  getMyStyles(index) {
    for (let j = 1; j <= 8; j++) {
      if (index % 8 === (j - 1)) {
        const myStyles = {
          'background-image': 'url(./assets/images/campaign_management/projects/bnnr' + j + '.png)'
        };
        return myStyles;
      }
    }
  }
  hideCarousel(details) {
    this.showCarousel = !this.showCarousel;
    this.serviceRequestDetails = details;
  }
  onCampaignClick(id) {
    this.router.navigate(['/campaign/' + id], {
      relativeTo: this.route
    });

  }
  onCampaigListClick() {
    this.router.navigate(['/campaign'], {
      relativeTo: this.route
    });
  }
  nominate(id) {
    this.showEnrolled = !this.showEnrolled;
    const userObj = JSON.parse(localStorage.getItem('user'));
    const nominee = { query: userObj.id };
    this.networkingservice.put('/servicerequest/nominateuser/' + id, nominee).subscribe(data => {
    });
  }
  showenviron(env_id, i) {
    this.rowIndex = i + 1;
    this.minusq[i] = true;
  }
  minusfun(i) {
    this.minusq[i] = false;
    this.rowIndex = 0;
  }
  showLegendfunc() {
    console.log('inside legend', this.projectCount);
    if (this.projectCount === 1) {
      this.showLegend = true;
      console.log(this.showLegend, 'trueeeeeeeeeee');
      setTimeout(() => {
        this.showLegend = false;
      }, 7000);
    } else {
      this.showLegend = false;
    }
  }
  launch(i) {
    const viewRequest = {
      req_id: 'this.services[i],',
    };
    this.networkingservice.post('/servicerequest/viewRequest', viewRequest)
      .subscribe(requestForm => {
        this.loading = false;
        this.authToken = requestForm;
        window.open(this.instanceUrl[i] + this.authToken, '_blank');
      });
  }
  filter(tab_value) {
    this.choose_tab = tab_value;
  }
}

import { Component, OnInit, Input, Output, OnChanges, EventEmitter, trigger, state, style, animate, transition, HostListener } from '@angular/core';
import { ScrollToService, ScrollToConfigOptions, ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
import { Location } from '@angular/common';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'app-launch-pad',
  templateUrl: './launch-pad.component.html',
  styleUrls: ['./launch-pad.component.css']
})

export class LaunchPadComponent implements OnInit {
  isVideoShown = false;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  // isVideoShown: Boolean = true;
  isVideoPlayed: Boolean = false;
  isVideoReplayed: Boolean = false;
  location: string;
  pause: boolean;
  factory: Boolean = false;
  conceptBuilder: Boolean = false;
  serviceRequest: Boolean = false;
  detailscrolltop: Boolean = false;
  nav: Boolean = false;
  user: any;
  value2 = 'concept-builder';
  footerDisplay: Boolean = true;


  constructor(private _scrollToService: ScrollToService, private _location: Location, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
  }
  playvideo() {
    this.isVideoShown = true;
    this.isVideoReplayed = false;
    this.pause = true;
  }
  close() {
    console.log("close is called!!!")
    this.isVideoShown = false;
  }
  videoEnded() {
    this.isVideoShown = false;
    this.isVideoPlayed = true;
    this.isVideoReplayed = true;
  }
  pauseOrPlay(video) {
    console.log('pause');
    this.isVideoReplayed = false;
    this.isVideoPlayed = true;
    if (this.pause) {
      video.play();
      this.pause = !this.pause;
    }
    else {
      video.pause();
      this.pause = !this.pause;
    }
  }
  public triggerScrollTo(location) {
    const config: ScrollToConfigOptions = {
      target: location,
      duration: 1500,
      easing: 'easeOutElastic',
      offset: 0
    };

    this._scrollToService.scrollTo(config);
    this.detailscrolltop = false;
  }
  box(value) {
    this.value2 = value;
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const number = window.pageYOffset;
    if (number > 150) {
      this.detailscrolltop = true;
    } else {
      this.detailscrolltop = false;
    }

    if (number < 100) {
      this.footerDisplay = true;
      console.log(this.footerDisplay, 'footer');
    } else {
      this.footerDisplay = false;
    }
    if (number > 550 && number < 2250) {
      this.nav = true;
    } else {
      this.nav = false;
    }
    if (number > 150) {
      this.factory = true;
      this.conceptBuilder = false;
      this.serviceRequest = false;
    } else { this.factory = false; }
    if (number > 1050) {
      this.conceptBuilder = true;
      this.factory = false;
      this.serviceRequest = false;
    } else { this.conceptBuilder = false; }
    if (number > 1750) {
      this.factory = false;
      this.conceptBuilder = false;
      this.serviceRequest = true;
    } else { this.serviceRequest = false; }

  }

  setActiveInLogin() {
    this.router.navigateByUrl('/login?action=signUp');
  }
}

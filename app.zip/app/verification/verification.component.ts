import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { NetWorkingService } from '../shared/networking.service';



@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.css']
})

export class VerificationComponent implements OnInit {
  urlParams: any;
  loading: boolean;
  user: any;
  constructor(private route: ActivatedRoute, private router: Router, private networkingservice: NetWorkingService) { }

  ngOnInit() {
    this.loading = true;
    this.user = JSON.parse(localStorage.getItem('user'));
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });

    this.networkingservice.post('/users/verification', { usertoken: this.urlParams.params.token }).subscribe(
      (verified) => {
        this.loading = false;

      });
  }

  approveUser() {
    this.networkingservice.post('/users/Verifyuser', this.user).subscribe((res) => {
      console.log(res)
    })
  }

}

import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../shared/networking.service';
import { DataService } from '../shared/data.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { LoadingModule } from 'ngx-loading';
import { NgxCarousel } from 'ngx-carousel';
import { Subscription } from 'rxjs/Rx';
import { Response } from '@angular/http/src/static_response';
import { CompleterService, CompleterData } from 'ng2-completer';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { trigger, state, style, animate, transition } from '@angular/animations';


@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css'],
  animations: [
    trigger('fade', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(700)
      ]),
      transition('* => void', [
        animate('0.5s 0.5s ease-out', style({
          opacity: 0
        }))
      ])
    ])
  ]

})
export class PlaylistComponent implements OnInit {
  public similarcarouselTile: NgxCarousel;
  public carouselTile: NgxCarousel;
  playlistCreated: any;
  vipplaylists: any;
  user_id: any;
  delete_id: any;
  user: any;
  dueDate: any
  playlistID: any;
  sharePlaylistDL: boolean = false;
  dataService: CompleterData;
  groupName: any;
  deleteDialog: boolean = false;
  shareDialogbox: boolean = false;
  dlink: boolean = false;
  shareduserID: any;
  showHide: any;
  tagStackArray = [];
  tagStackArrayDL = [];
  Sharedusers_id = [];
  SharedPlaylistusers = [];
  userdoesntexists: boolean = false;
  TagStack: string;
  tagstackfinaldivboolean: boolean = false;
  filterShareUserArray = [];
  Sharedusers = [];
  sharedUserDL = [];
  loading: boolean = false;
  playlistname: any;
  playlistDescription: any;
  mail: any;
  playlistFlag: boolean = false;
  sharePlaylist: boolean = false;
  playlistFlagAlreadyCreated: boolean = false;
  Playlistdialogbox: boolean = false;
  alreadyaddedplaylist: boolean = false;
  Playlistname: any;
  showCarousel: boolean = false;
  showCarousels: boolean = true;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric'
  };
  time: string = new Date().toLocaleString('en-IN', this.options);
  softMessage: boolean = false;
  constructor(private networkingService: NetWorkingService, private data: DataService, private completerService: CompleterService, private route: ActivatedRoute, public router: Router) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    this.loading = true;
    this.showHide = true;
    this.getplaylist();
    this.similarcarouselTile = {
      grid: {
        xs: 2,
        sm: 3,
        md: 3,
        lg: 5,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
    this.carouselTile = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };
    //Fetch Users
    var obj = { mail: this.user.email }
    this.networkingService.post('/users/shareUsers', obj).subscribe((users) => {
      users.forEach(user => {
        this.Sharedusers.push(user.email);
        this.SharedPlaylistusers.push(user)
      })
      var index = this.Sharedusers.indexOf(this.user.email);
      this.Sharedusers.splice(index, 1);
      this.dataService = this.completerService.local(this.Sharedusers);
    });
    //Fetch users ends here
    //Fetch DL
    this.networkingService.post('/users/shareUsersDL', obj).subscribe((users) => {
      users.forEach(user => {
        if (user.userGroupName) {
          // this.Sharedusers.push(user.userGroupName);

        }
        this.sharedUserDL.push(user);
        // console.log("sharedUserDL",this.sharedUserDL)
      })
    });
    //Fetch DL ends here

  }
  getplaylist() {
    const getplaylists = {
      userId: this.user.id,
    }
    this.networkingService.post('/users/getPlaylist', getplaylists).subscribe(Response => {
      this.loading = false;
      this.playlistCreated = Response.playlist;
      this.vipplaylists = Response.vipPlaylists;
      console.log(this.playlistCreated, "playlistCreated");
      console.log(this.vipplaylists, "vipplaylists");

    });
  }
  gotoPlaylist() {
    this.router.navigateByUrl('/playlist/playlist-form');

  }
  // creating a playlist
  submitData() {

    this.softMessage = true;
    console.log("this.user.id", this.user.id)
    const playListObj = {
      uploadDate: this.time,
      // vipPlaylist: this.vipPlaylist,
      playlistName: this.Playlistname,
      userRole: this.user.userGroup,
      userId: this.user.id,
      playlistDescription: this.playlistDescription,
      userName: this.user.name,
      dueDate: this.getserviceday(this.time),
      request_id: "REQ" + Math.floor(100000 + Math.random() * 900000)

    }
    this.networkingService.post('/users/createPlaylist', playListObj).subscribe(Response => {
      if (Response == "already added") {
        this.loading = false;
        this.alreadyaddedplaylist = true;
        setTimeout(() => {
          this.alreadyaddedplaylist = false;
        }, 7000);

      }

      if (Response != "already added") {
        this.loading = false;

        this.playlistFlagAlreadyCreated = true;
        setTimeout(() => {
          this.playlistFlagAlreadyCreated = false;
        }, 7000);
        this.playlistCreated = Response
        this.getplaylist();
        this.Playlistdialogbox = !this.Playlistdialogbox;
      }
    });

  }
  // creating a playlist ends here

  // viewing the playlist details
  viewplaylist(id, playlistname) {
    localStorage.setItem("playlistName", playlistname)
    this.data.changePrototype(playlistname);
    var obj = {
      "query": id,
      "action": "view",
      "lang": "en"
    }
    this.router.navigateByUrl('/playlist/playlist-details?id=' + id + "&action=view");

  }
  // viewing the playlist details ends here

  toggleDeletePopup(id, playlistname) {
    this.delete_id = id;
    this.playlistname = playlistname;
    this.deleteDialog = !this.deleteDialog;

  }
  closesignout() {
    this.deleteDialog = !this.deleteDialog;
  }
  deleteplaylist() {
    var obj = {
      playlistname: this.playlistname,
      emailId: this.user.email
    }
    this.networkingService.post('/users/deletePlaylist/' + this.delete_id, obj).subscribe(data => {
      this.getplaylist();
      this.loading = false;
    });

    this.deleteDialog = !this.deleteDialog;
    this.playlistFlag = true;
    setTimeout(() => {
      this.playlistFlag = false;
    }, 7000);
  }
  gotoPrototypeDetail(prototypeId, prototype) {
    this.data.changePrototype(prototype);
    this.router.navigate(['../toolbox/Artificial%20Intelligence/', prototypeId], {
      relativeTo: this.route
    });
    window.scrollTo(0, 0);
  }
  closeplaylistdialog() {
    this.tagStackArray = [];
    this.TagStack = '';
    this.shareDialogbox = false;
    this.Playlistdialogbox = false;
  }
  closeplaylist() {
    this.Playlistdialogbox = false;
    this.Playlistname = '';
  }
  createPlaylistPopup() {
    this.playlistDescription = "";
    this.Playlistname = "";
    this.Playlistdialogbox = true;

  }
  sharePlaylistPopup(id) {
    this.playlistID = id;
    this.tagStackArray = [];
    this.TagStack = '';
    this.groupName = '';
    this.filterShareUserArray = [];
    this.dlink = false;
    this.shareDialogbox = !this.shareDialogbox;
    var obj = { mail: this.user.email }
    this.networkingService.post('/users/shareUsers', obj).subscribe((users) => {
      this.Sharedusers = users;
    });
  }
  filterShareUsers(value, event) {
    if (event.toElement.checked) {
      this.filterShareUserArray.push(value);
    }
    else {
      var index = this.filterShareUserArray.indexOf(value)
      this.filterShareUserArray.splice(index, 1);
    }
  }
  // sharing a playlist starts here
  share() {
    if (this.tagStackArray.length < 2) {
      this.dlink = false;
      this.shareDialogbox = !this.shareDialogbox;
    }
    if (this.tagStackArray.length >= 2) {
      this.dlink = true;
    }
    this.tagStackArray.forEach(obj => {
      if (!(obj.includes('@'))) {
        var index = this.tagStackArray.indexOf(obj);
        this.tagStackArray.splice(index, 1);
        this.tagStackArrayDL.forEach(obj => {
          this.tagStackArray.push(obj);
        })
      }
    })
    this.filterShareUserArray = this.tagStackArray;
    for (let i = 0; i < this.SharedPlaylistusers.length; i++) {
      for (let j = 0; j < this.filterShareUserArray.length; j++) {
        if (this.filterShareUserArray[j].includes('@')) {
          if (this.filterShareUserArray[j] === this.SharedPlaylistusers[i].email) {
            this.Sharedusers_id.push(this.SharedPlaylistusers[i].id)
          }
        } else {
          this.Sharedusers_id.push(this.filterShareUserArray[j]);

        }
      }
    }
    const a = this.Sharedusers_id;
    this.Sharedusers_id = a.filter(function (item, pos) {
      return a.indexOf(item) === pos;
    });
    var obj = {
      array: this.Sharedusers_id,
      playlistid: this.playlistID,
      type: 'Playlist',
      GroupName: this.groupName
    }
    const notedate = new Date(Date.now());
    const newnotedate = notedate
    this.networkingService.post('/users/savesharedUsers', obj).subscribe(data => {
      // this.networkingService.post('/users/pushUsers', obj).subscribe(Response => {
      this.shareduserID = data.id;
      var adminFormNotification
      if (this.filterShareUserArray.length >= 1) {
        for (let i = 0; i < this.filterShareUserArray.length; i++) {
          adminFormNotification = {
            email: this.filterShareUserArray[i],
            ref_id: this.playlistID,
            notificationtag: 'Playlist',
            prototypeName: this.playlistname,
            message: '',
            action: this.user.email,
            status: 'shared',
            notificationDate: newnotedate
          };
          this.networkingService.post('/users/notification', adminFormNotification).subscribe((res) => {
          });
        }
      } else {
        adminFormNotification = {
          email: this.filterShareUserArray,
          ref_id: this.playlistID,
          notificationtag: 'Playlist',
          prototypeName: this.playlistname,
          message: '',
          action: this.user.email,
          status: 'shared',
          notificationDate: newnotedate
        };
        this.networkingService.post('/users/notification', adminFormNotification).subscribe((res) => {
        });
      }

      // });
      this.sharePlaylist = true;
      setTimeout(() => {
        this.sharePlaylist = false;
      }, 7000);
    });

    if (this.filterShareUserArray.length >= 2) {
      this.dlink = true;
    }
    // this.shareDialogbox = !this.shareDialogbox;

  }
  // sharing a playlist ends here

  dlnameshare() {
    var obj = {
      usergroupname: this.groupName,
      shareduserID: this.shareduserID
    }
    this.networkingService.post('/users/dlnameshare', obj).subscribe((res) => {
      this.shareDialogbox = !this.shareDialogbox;
      this.dlink = false;
    });
    this.sharePlaylistDL = true;
    setTimeout(() => {
      this.sharePlaylistDL = false;
    }, 7000);
  }

  tagStackdiv(event) {
    var emailobject = { email: this.TagStack };
    var checkDL = this.TagStack.includes('@');
    if (checkDL) {
      this.networkingService.post('/servicerequest/validatetoyboxuser', emailobject)
        .subscribe(userexist => {
          console.log(userexist, "userexist");
          //   var assignresponse = userexist;
          if (userexist == "user doesn't exist") {
            this.userdoesntexists = true;
          }
          else if (userexist == "user does exist") {
            this.tagStackArray.push(this.TagStack);
            this.TagStack = '';

          }
        })
    } else {
      var obj = this.sharedUserDL.filter(a => {
        if (a.userGroupName == this.TagStack) {
          this.tagStackArray.push(this.TagStack);
          return a;
        }
      })
      console.log(obj);
      obj.forEach(obj => {
        obj.emailID.forEach(email => {
          // console.log(email,"email");
          this.tagStackArrayDL.push(email);
        })
        // this.tagStackArray.push(obj)
        // console.log("this.tagStackArray",obj);
      })
      if (this.tagStackArray.length >= 2) {
        this.dlink = true;
      }
      this.TagStack = '';
    }


  }
  tagstackfinaldiv() {
    this.tagstackfinaldivboolean = true;
    this.showHide = false;
  }
  closetech(item) {
    const index = this.tagStackArray.indexOf(item);
    this.tagStackArray.splice(index, 1);
  }
  AddMorePrototypes(playlistName, playlistId) {
    this.data.changePrototype({ id: playlistId, name: playlistName });
    this.router.navigateByUrl('/toolbox/All%20Categories')
  }
  hideCarousel() {

    this.showCarousels = !this.showCarousels;
    this.showCarousel = !this.showCarousel;

  }
  viewFeaturedPlaylistDetails(i) {
    this.router.navigateByUrl('/playlist/featureplaylist/' + i);

  }
  getserviceday(gettime) {
    var d = new Date(gettime);
    console.log("date", d);
    this.dueDate = new Date(d.setDate(d.getDate() + 3)).toLocaleString('en-IN', this.options);
    // console.log("servicedatedate", this.dueDate);
    return this.dueDate;
  }
  viewfeatureplaylistList() {
    this.router.navigateByUrl('/playlist/feature-playlist-list');

  }
  public carouselTileLoad(evt: any) { }
}

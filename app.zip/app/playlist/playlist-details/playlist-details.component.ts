import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { NetWorkingService } from '../../shared/networking.service';
import { Location } from '@angular/common';
import { DataService } from '../../shared/data.service';
import { LoadingModule } from 'ngx-loading';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-playlist-details',
  templateUrl: './playlist-details.component.html',
  styleUrls: ['./playlist-details.component.css'],
  animations: [
    trigger('fade', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(700)
      ]),
      transition('* => void', [
        animate('0.5s 0.5s ease-out', style({
          opacity: 0
        }))
      ])
    ])
  ]

})
export class PlaylistDetailsComponent implements OnInit {
  urlParams: any;
  Playlistname = '';
  chkbox = false;
  vipPlaylist = false;
  playlistNameHtmlView = '';
  playlistDescription = '';
  playlistDescriptionHtmlview = '';
  prototypes = [];
  playlistCreated = [];
  featureplaylistdetails: boolean = false;
  protoid: any;
  delete_id: any;
  deletedprototype: any;
  deleteDialog = false;
  editPlaylistDetailsPopup = false;
  playlistName: any;
  user: any;
  loading = false;
  playlistFlag = false;
  playlistFlagApprove = false;
  status: String
  PlaylistId: String
  // vipPlaylist: Boolean = false;
  constructor(private data: DataService, private networkingService: NetWorkingService, private route: ActivatedRoute, public router: Router, private _location: Location) { }

  ngOnInit() {
    this.data.changePrototype('');
    this.user = JSON.parse(localStorage.getItem('user'));
    this.loading = true;
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    if (this.urlParams.params.id) {
      this.networkingService.post('/api/prototypes/' + this.urlParams.params.id, {}).subscribe(Response => {
        // console.log("asdfghjkl", Response);
        this.loading = false;
        this.prototypes = Response[0].prototypes;
        this.Playlistname = Response[0].name;
        this.PlaylistId = Response[0].id;
        this.playlistDescription = Response[0].playlistDescription;
        this.playlistDescriptionHtmlview = Response[0].playlistDescription;
        this.status = Response[0].status
        this.data.prototype.subscribe(Response => {
          console.log("saba", Response)
          // var response = JSON.stringify(Response);
          // response = JSON.parse(response);
          this.playlistName = Response
          console.log(this.playlistName, typeof Response)
          if (this.playlistName != '' && typeof Response !== 'object') {
            console.log("sasasa")
            localStorage.setItem("playlistName", this.playlistName)
          }
          else {
            this.playlistName = localStorage.getItem("playlistName")
          }
        });

      });
      if (this.urlParams.params.ftplay == "true") {
        this.featureplaylistdetails = true;
        console.log("this.isthisdraft")
      }
    }


  }
  backToCategoryList() {
    this.loading = false;
    this._location.back();
  }
  toggle(id, protoname) {
    this.delete_id = id;
    this.deletedprototype = protoname;
    this.deleteDialog = !this.deleteDialog;
  }
  closesignout() {
    this.deleteDialog = !this.deleteDialog;
  }
  vipPlaylistCheck() {
    this.chkbox = !this.chkbox;
    this.vipPlaylist = !this.vipPlaylist;
    console.log("vip playlist", this.vipPlaylist)
  }
  deleteplaylist() {
    var obj = {
      prototype_id: this.delete_id
    }
    this.networkingService.put('/users/deleteprototype/' + this.urlParams.params.id, obj).subscribe(Response => {
      this.loading = false;
      this.prototypes = Response[0].prototypes;
    });
    this.deleteDialog = !this.deleteDialog;
    this.playlistFlag = true;
    setTimeout(() => {
      this.playlistFlag = false;
    }, 7000);
  }
  AddMorePrototypes() {
    console.log("this.Playlist", this.PlaylistId)
    this.data.changePrototype({ id: this.PlaylistId, name: this.Playlistname });
    // console.log("playlist name is : ", this.Playlistname);
    this.router.navigateByUrl('/toolbox/All%20Categories')
  }
  // vipPlaylistCheck() {
  //   this.vipPlaylist = !this.vipPlaylist;
  //   console.log("vip playlist", this.vipPlaylist)
  // }
  ngOnDestroy() {
    localStorage.removeItem('playlistName')
  }

  editPlaylistDetails() {
    this.chkbox = false;
    this.vipPlaylist = false;
    this.editPlaylistDetailsPopup = !this.editPlaylistDetailsPopup;
  }
  closeplaylistdialog() {
    this.editPlaylistDetailsPopup = false;

  }

  closeplaylist() {
    this.editPlaylistDetailsPopup = false;
    this.Playlistname = this.playlistName;
    this.playlistDescription = this.playlistDescriptionHtmlview;
    // this.Playlistname = '';
  }


  submitData() {
    // console.log("this.playlistDescription",this.playlistDescription);
    // console.log("this.user.id",this.user.id);
    const notedate = new Date(Date.now());
    const newnotedate = notedate
    const playlistDescriptionObj = {
      userGroup: this.user.userGroup,
      playlistDescription: this.playlistDescription,
      playlistId: this.urlParams.params.id,
      vipPlaylist: this.vipPlaylist,
      plname: this.Playlistname,
      requesterName: this.user.name ? this.user.name : this.user.email
    }
    if (this.playlistDescription !== '') {
      this.networkingService.put('/users/playlistDescription', playlistDescriptionObj).subscribe(Response => {
        // this.data.changePlayListName(this.playlistName);
        console.log(Response);
        const adminFormNotification = {
          email: this.user.email,
          ref_id: this.urlParams.params.id,
          notificationtag: 'Playlist',
          prototypeName: this.Playlistname,
          message: '',
          action: '',
          status: 'Pending',
          notificationDate: newnotedate
        };
        this.networkingService.post('/users/notification', adminFormNotification).subscribe((res) => {
        });
        this.playlistName = Response.name,
          this.Playlistname = Response.name,
          this.playlistNameHtmlView = Response.name,
          this.playlistDescription = Response.playlistDescription,
          this.playlistDescriptionHtmlview = Response.playlistDescription
        // console.log("this.playlistDescriptionCreated",this.playlistDescriptionCreated);
        this.playlistFlagApprove = true;
        setTimeout(() => {
          this.playlistFlagApprove = false;
        }, 7000);
      });
    }
    else {
      // console.log("shouldn't be empty");
    }
    this.editPlaylistDetailsPopup = false;
    this.playlistDescription = '';

  }
  approvePlaylist() {
    this.networkingService.put('/users/approvePlaylist/' + this.urlParams.params.id, { userId: this.user.id, userName: this.user.name }).subscribe(Response => {
      console.log(Response)
      const approveObj = {
        status: 'Approved',
        ref_id: this.urlParams.params.id,
        action: 'Approve'
      };
      this.networkingService.put('/users/notification/' + this.urlParams.params.id, approveObj).subscribe(data => {
        this.networkingService.get('/users/notification/' + this.user.email).subscribe((res) => {
          this.data.profilenotify(res);
        });
      });
      this.router.navigateByUrl('/playlist')

    });
  }
  rejectPlaylist() {
    this.networkingService.put('/users/rejectPlaylist/' + this.urlParams.params.id, {}).subscribe(Response => {
      // console.log(Response)
      this.router.navigateByUrl('/playlist')
    });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeaturePlaylistListComponent } from './feature-playlist-list.component';

describe('FeaturePlaylistListComponent', () => {
  let component: FeaturePlaylistListComponent;
  let fixture: ComponentFixture<FeaturePlaylistListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeaturePlaylistListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeaturePlaylistListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

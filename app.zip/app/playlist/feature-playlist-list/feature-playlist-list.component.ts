import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
import { LoadingModule } from 'ngx-loading';
import { Location } from '@angular/common';
import { NgxCarousel } from 'ngx-carousel';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DataService } from '../../shared/data.service';


@Component({
  selector: 'app-feature-playlist-list',
  templateUrl: './feature-playlist-list.component.html',
  styleUrls: ['./feature-playlist-list.component.css']
})
export class FeaturePlaylistListComponent implements OnInit {
user:any;
public similarcarouselTile: NgxCarousel;
loading=false;
vipplaylists=[];
  constructor(private networkingService: NetWorkingService,private _location: Location, public router: Router,private data: DataService) { }

  ngOnInit() {
    this.loading=true;    
    this.user = JSON.parse(localStorage.getItem('user'));
    this.getplaylist();
    this.similarcarouselTile = {
      grid: {
        xs: 2,
        sm: 3,
        md: 3,
        lg: 5,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
  }
  getplaylist() {
    const getplaylists = {
      userId: this.user.id,
    }
    console.log("userId", getplaylists);
    this.networkingService.post('/users/getPlaylist', getplaylists).subscribe(Response => {
      this.loading = false;
      this.vipplaylists = Response.vipPlaylists;
      console.log("playlist details",  this.vipplaylists);
    });
  }
  backToCategoryList() {
    this.loading = false;
    this._location.back();
  }
  viewplaylist(id, playlistname) {
    localStorage.setItem("playlistName", playlistname)
    this.data.changePrototype(playlistname);
    var obj = {
      "query": id,
      "action": "view",
      "lang": "en"
    }
    this.router.navigateByUrl('/playlist/playlist-details?id=' + id + "&action=view,&ftplay=true");

  }
}

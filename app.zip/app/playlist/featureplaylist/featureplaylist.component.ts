import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NetWorkingService } from '../../shared/networking.service';
import { LoadingModule } from 'ngx-loading';
import { NgxCarousel } from 'ngx-carousel';
import { Location } from '@angular/common';

@Component({
  selector: 'app-featureplaylist',
  templateUrl: './featureplaylist.component.html',
  styleUrls: ['./featureplaylist.component.css']
})
export class FeatureplaylistComponent implements OnInit {

  constructor(private route: ActivatedRoute, private networkingService: NetWorkingService, private _location: Location) { }

  public similarcarouselTile: NgxCarousel;
  playlistId: String;
  loading = false;
  playlistCreated: any;
  vipplaylists: any;
  ngOnInit() {
    this.loading = true;
    
    this.route.params.subscribe((params) => {
      this.playlistId = params['id']
      // console.log("sabaa", this.playlistId)
    })
    this.getplaylist();
    this.similarcarouselTile = {
      grid: {
        xs: 2,
        sm: 3,
        md: 3,
        lg: 6,
        all: 0
      },
      slide: 6,
      speed: 400,
      animation: 'lazy',
      load: 2,
      point: {
        visible: true
      },
      touch: true,
      loop: true,
      easing: 'ease'
    };
  }
  getplaylist() {
    const getplaylists = {
      playlistId: this.playlistId,
    }
    // console.log("user_id", getplaylists);
    this.networkingService.post('/users/getvipPlaylist', getplaylists).subscribe(Response => {
      this.loading = false;
      // this.playlistCreated = Response.playlist;
      this.vipplaylists = Response;
      // console.log("playlist details", Response);
    });
  }
  gotoPrevStep() {
    this.loading = false;
    this._location.back();
  }

}

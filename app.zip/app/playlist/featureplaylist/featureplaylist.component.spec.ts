import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureplaylistComponent } from './featureplaylist.component';

describe('FeatureplaylistComponent', () => {
  let component: FeatureplaylistComponent;
  let fixture: ComponentFixture<FeatureplaylistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeatureplaylistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeatureplaylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

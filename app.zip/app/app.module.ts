import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Http, HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { LoadingModule } from 'ngx-loading';
import { ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
// import { SlickModule } from 'ngx-slick';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CarouselConfig } from 'ngx-bootstrap/carousel';
import { CarouselModule } from 'ngx-bootstrap';
import { LazyLoadImagesModule } from 'ngx-lazy-load-images';
import { AppComponent } from './app.component';
import { CategoryPipe, SortPipe } from './toolbox/prototype-list/prototype-list.component';
import { ReviewersortPipe, RevHighlightssortPipe, CapitalizeFirst } from './toolbox/prototype-detail/prototype-detail.component';
import { ReversePipe } from './landing-page/landing-page.component';
import { DateSortPipe, ApprovedDateSortPipe } from './admin/rbac-dashboard/rbac-dashboard.component';
import { DataService } from './shared/data.service';
import { ExcelService } from './shared/excel.service';
import { NetWorkingService } from './shared/networking.service';
import { AuthGuard } from './guards/auth.guard';
import { ValidateService } from './services/validate.service';
import { AuthService } from './services/auth.service';
import { NgxCarouselModule } from 'ngx-carousel';
import 'hammerjs';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ClickOutsideModule } from 'ng-click-outside';
import { MomentModule } from 'angular2-moment';
import { FileUploadModule } from 'ng2-file-upload';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TextMaskModule } from 'angular2-text-mask';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { Ng2CompleterModule } from 'ng2-completer';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ImagePreviewDirective } from './toolbox/adminform/image-preview.directive';
import { NgxPaginationModule } from 'ngx-pagination';
import { CookieModule } from 'ngx-cookie';
import { RatingModule } from 'ngx-rating';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppRoutingModule, routingComponents } from './app.routing';
import { UserStreamComponent } from './user-stream/user-stream.component';
import { FollowersComponent } from './user-stream/followers/followers.component';
import { ActivityFeedComponent } from './user-stream/activity-feed/activity-feed.component';
import { ActiveCampaignComponent } from './user-stream/active-campaign/active-campaign.component';
// import { OpportunityTrackerComponent } from './opportunity-tracker/opportunity-tracker.component';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { ProfileListComponent } from './user-stream/profile-list/profile-list.component';

// import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    CategoryPipe,
    SortPipe,
    RevHighlightssortPipe,
    ReviewersortPipe,
    DateSortPipe,
    ReversePipe,
    ImagePreviewDirective,
    CapitalizeFirst,
    UserStreamComponent,
    FollowersComponent,
    ActivityFeedComponent,
    ActiveCampaignComponent,
    ProfileListComponent,
    // ForgotPasswordComponent

    

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    ChartsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    FormsModule,
    LoadingModule,
    FileUploadModule,
    ClickOutsideModule,
    BrowserAnimationsModule,
    TextMaskModule,
    NgxPageScrollModule,
    Ng2CompleterModule,
    LazyLoadImagesModule,
    ScrollToModule.forRoot(),
    MomentModule,
    RatingModule,
    BsDropdownModule.forRoot(),
    ToastModule.forRoot(),
    NgxPermissionsModule.forRoot(),
    NgxCarouselModule,
    NgbModule.forRoot(),
    CarouselModule.forRoot(),
    NgxPaginationModule,
    CookieModule.forRoot()
  ],
  providers: [DataService, NetWorkingService, ValidateService, AuthService, AuthGuard, ExcelService ],
  bootstrap: [AppComponent]
})
export class AppModule { }

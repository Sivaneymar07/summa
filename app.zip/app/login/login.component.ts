import { Component, OnInit,ViewChild } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { ValidateService } from '../services/validate.service';
import { NetWorkingService } from '../shared/networking.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPermissionsService } from 'ngx-permissions';
import { DataService } from '../shared/data.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('ti') ngbTabSet;  
  i = 0;
  j = 0;
  k = 0;
  togglePwd1 = 'password';
  togglePwd2 = 'password';
  togglePwd3 = 'password';
  username: String;
  email: String;
  password: String;
  errorMsg: boolean;
  pwdError: boolean;
  confirm: String;
  emailRegister: String;
  passwordRegister: String;
  forgotPwdDiv : boolean;
  admin: Boolean;
  public loading = false;
  tcDialog = false;
  forgotPwdEmail : any;
  validEmail =[];
  emailFlag : boolean = false;
  forgotPwdPassword : any;
  confirmPwd : any;
  term = '';
  date = new Date();
  newDate: any;
  setRememberMe: any;
  rememberMe: Boolean = false;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
  };
  urlParams:any;

  constructor(private validateService: ValidateService,
    private route: ActivatedRoute,
    private authService: AuthService,
    private networkingservice: NetWorkingService,
    private router: Router,
    public toastr: ToastsManager,
    private data: DataService,
    private permissionsService: NgxPermissionsService,
    vcr: ViewContainerRef) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    console.log(this.ngbTabSet,"asdasdasdasd")
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    console.log("URL Params",this.urlParams.params.action);
    if(this.urlParams.params.action == 'signUp'){
      this.ngbTabSet.activeId = "tab-selectbyid2";
      console.log("Active Class of Login Page",this.ngbTabSet.activeId);
    }
  }

  onLoginSubmit() {
    this.loading = true;
    const user = {
      email: this.email,
      password: this.password,
      rememberMe: this.rememberMe
    };

    // authenticate user
    this.networkingservice.post('/users/authenticate', user).subscribe(data => {
      this.loading = false;
      if (data.success) {
        const perm = [data.user.userGroup];
        if (data.user.rememberMe === true) {
          // this.data.setRememberMe('true');
        } else if (data.user.rememberMe === false) {
          // this.data.setRememberMe('false');
        }
        this.permissionsService.loadPermissions(perm);
        if (data.user.admin === true) {
          this.authService.storeUserData(data.token, data.user, data.guaData);
          this.toastr.success('Welcome, ' + data.user.username);
          this.router.navigate(['/landingpage']);
        } else {
          this.authService.storeUserData(data.token, data.user, data.guaData);
          this.router.navigate(['/landingpage']);
        }
      } else {
        if (data.msg === 'User not found !') {
          this.email = '';
          this.password = '';
        } else {
          this.password = '';
        }
        this.toastr.error(data.msg);
        this.router.navigate(['/login']);
      }
    });
  }

  // register new user
  onRegisterSubmit() {
    const user = {
      emailRegister: this.emailRegister,
      passwordRegister: this.passwordRegister,
      confirm: this.confirm,
      admin: this.admin
    };
    if (!this.validateService.validateEmail(user.emailRegister)) {
      return false;
    }
    if (!this.validateService.validatePassword(user.passwordRegister)) {
      return false;
    }
    if (!this.validateService.validateConfirmPassword(user.passwordRegister, user.confirm)) {
      this.toastr.error('Password and Confirm Password do not match');
      return false;
    }
    this.networkingservice.post('/users/register', user).subscribe(data => {
      if (data.success) {
        this.toastr.success('You are successfully registered !   Please check your mail to verify it');
        this.newDate = this.date.toLocaleString('en-IN', this.options);
        const notification = {
          email: this.email,
          ref_id: '',
          notificationtag: 'profile',
          message: 'Complete your Profile',
          action: '/profile',
          status: 'pending',
          notificationDate: this.newDate,
        };
        this.networkingservice.post('/users/notification', notification).subscribe((res) => {
          const notificationReward = {
            email: this.email,
            ref_id: '',
            notificationtag: 'profile',
            message: 'You got XXXTYB points for FirstLogin ',
            action: '/profile',
            notificationDate: this.newDate,
            status: 'points',
          };
          this.networkingservice.post('/users/notification', notificationReward).subscribe((response) => {
            this.data.profilenotify(response);
          });
        });
      } else {
        this.toastr.error('E-mail Already Exists !');

        this.router.navigate(['/login']);
      }
    });

    this.email = this.emailRegister;
    this.emailRegister = '';
    this.passwordRegister = '';
    this.confirm = '';
  }

  // validate password
  passwordValid() {
    const user = {
      emailRegister: this.emailRegister,
      passwordRegister: this.passwordRegister,
      confirm: this.confirm,
      admin: this.admin
    };
    if (!this.validateService.validateConfirmPassword(user.passwordRegister, user.confirm)) {
      this.errorMsg = true;
    } else {
      this.errorMsg = false;
    }
  }
  togglePassword1() {
    this.i++;
    if (this.i % 2 !== 0) {
      this.togglePwd1 = 'text';
    } else {
      this.togglePwd1 = 'password';
    }
  }
  togglePassword2() {
    this.j++;
    if (this.j % 2 !== 0) {
      this.togglePwd2 = 'text';
    } else {
      this.togglePwd2 = 'password';
    }
  }
  togglePassword3() {
    this.k++;
    if (this.k % 2 !== 0) {
      this.togglePwd3 = 'text';
    } else {
      this.togglePwd3 = 'password';
    }
  }
  terms() {
    this.tcDialog = !this.tcDialog;
  }
  showForgotPwd(){
    this.forgotPwdDiv = true;
  }
  emailValid(){
    this.validEmail = this.forgotPwdEmail.split('@');
    if(this.validEmail[1]=='cognizant.com'){
      this.emailFlag = true;
    }
  }
  onForgotPwdSubmit(){
    const user = {
      email: this.forgotPwdEmail,
      password: this.forgotPwdPassword,
      confirmPwd: this.confirmPwd
    };
    if (!this.validateService.validateEmail(user.email)) {
      return false;
    }
    if (!this.validateService.validatePassword(user.password)) {
      return false;
    }
    if (!this.validateService.validateConfirmPassword(user.password, user.confirmPwd)) {
      this.toastr.error('Password and Confirm Password do not match');
      return false;
    }

    this.networkingservice.post('/users/forgotPassword', user).subscribe(data => {
      if (data.success) {
        this.toastr.success('Password changed successfully. You can login using the new password');
      }
      setTimeout((router: Router) => {
      this.forgotPwdDiv = false;
      },5000);  //5s

  }
    )}
}

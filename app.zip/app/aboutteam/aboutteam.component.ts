import { Component, OnInit } from '@angular/core';
import { NgClass } from '@angular/common';
import { ScrollToService, ScrollToConfigOptions, ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
import { HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aboutteam',
  templateUrl: './aboutteam.component.html',
  styleUrls: ['./aboutteam.component.css']
})
export class AboutteamComponent implements OnInit {
  user: any;
  mousehovered = false;
  base = true;
  overlay = false;
  overlayImage = true;
  detailscrolltop = false;
  constructor(private _scrollToService: ScrollToService, private router: Router) { }
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
  }
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const number = window.pageYOffset;
    if (number > 150) {
      this.detailscrolltop = true;
    } else {
      this.detailscrolltop = false;
    }
  }
  AppRowMouseHover(e) {
    this.overlay = true;
    this.overlayImage = false;
  }
  AppRowMouseLeave(e) {
    this.overlay = false;
    this.overlayImage = true;
  }
  public triggerScrollTo(location) {
    const config: ScrollToConfigOptions = {
      target: location,
      duration: 1500,
      easing: 'easeOutElastic',
      offset: 0
    };
    this._scrollToService.scrollTo(config);
    this.detailscrolltop = false;
  }
  setActiveInLogin() {
    this.router.navigateByUrl('/login?action=signUp');
  }
}

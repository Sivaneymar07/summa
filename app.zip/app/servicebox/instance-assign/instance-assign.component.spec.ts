import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstanceAssignComponent } from './instance-assign.component';

describe('InstanceAssignComponent', () => {
  let component: InstanceAssignComponent;
  let fixture: ComponentFixture<InstanceAssignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstanceAssignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstanceAssignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

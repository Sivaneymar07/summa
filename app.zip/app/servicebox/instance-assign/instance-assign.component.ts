import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
import { LoadingModule } from 'ngx-loading';
import { ServiceInterface} from '../../shared/service.interface';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Location } from '@angular/common';
import { DataService } from '../../shared/data.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-instance-assign',
  templateUrl: './instance-assign.component.html',
  styleUrls: ['./instance-assign.component.css']
})

export class InstanceAssignComponent implements OnInit {
 public loading = false;
 newapprovedate: any;
 noOfInstances = 10;
 OperatingSystem: Array<any> = [];
 PrototypePlatform: Array<any> = [];
 userEmail: Array<any> = [];
 fromDate: Array<any> = [];
 toDate: Array<any> = [];
 requestinstances: any;
 array: any;
 tempp: any;
 servicerequest: any;
 envfields: any;
 urlParams: any;
 req_id: any;
 Assigntoast = false;
 maxtoDate: any;
 serviceforms: ServiceInterface[] = [];
 seriveinstanceArray = [];
 assignflag = false;
 requesteremail = String;
 updateinstanceArray = [];
 crowdsourcearr = [];
 emailflagcount= 0;
 teckStacksRequested: string;
 emailcount: Array<any>= [];
 tempDate: Array<any>= [];
 date= new Date();
 requestedNoInstances: number;
 exchangeDay: any;
 newDateFormat: String;
 extendflag: boolean;
 userconfigure: boolean;
 sample_maxdate = [];
 userDateAssignArray = [];
 dropdowndate;
 serviceinstance;
crowdconfig = false;
  userdoesntexists: Array<boolean> = [];
  mail: any;
   OS: any;
    Prototypeplatform: any;
options = {
    year: 'numeric', month: 'short',
    day: 'numeric' ,
  };
  options_digit = {
    year: 'numeric', month: '2-digit',
    day: '2-digit' ,
  };
    extensiondateoptions = {
   month: '2-digit',
    day: '2-digit' ,
      year: 'numeric'
  };

 constructor(private networkingservice: NetWorkingService, private route: ActivatedRoute,
  private _location: Location, private router: Router, private data: DataService, private translate: TranslateService) { }

  ngOnInit() {
    this.translate.get('operating_systems').subscribe((res: any) => { this.OS = res; });
    this.translate.get('prototyping_platform').subscribe((res: any) => { this.Prototypeplatform = res; });
    this.dropdowndate = this.date.toLocaleString('en-IN', this.options_digit);
    this.mail = JSON.parse(localStorage.getItem('user'));
    this.tempDate = this.dropdowndate.split('/');
    this.newDateFormat = this.tempDate.join('-');
    this.extendflag = false;
    this.route.queryParamMap.subscribe(params => {
    this.urlParams = {...params.keys, ...params};
    });
    if (this.urlParams.params.action  === 'extend') {
      this.extendflag = true;
    }
  const obj = {'query': this.urlParams.params.id, 'lang': 'en', 'view': true};
  this.networkingservice.post('/servicerequest/getServiceRequests', obj)
 .subscribe(service => {
  this.servicerequest = service;
  this.req_id = service.req_id;
  this.userconfigure = service.userconfigure;
  this.requesteremail = service.email_address;
  if (service.userconfigure === false) {
    this.crowdconfig = false;
  } else if (service.userconfigure === true) {
      this.crowdconfig = true;
      this.assignflag = true;
      service.assigned_users.forEach((user) => {
        this.crowdsourcearr.push(user.email);
      });
  }
      const serviceinsatnce = service.serviceInstance;
        const currentDate = new Date();
            this.requestinstances = this.servicerequest.serviceInstance;
            this.requestedNoInstances = this.requestinstances.length;
            const teckStackarray = [];
           for (let i = 0; i < this.requestinstances.length; i++) {
             if (teckStackarray.length === 0) {
               teckStackarray.push(serviceinsatnce[i].PrototypePlatformField);
             } else {
               for (let j = 0; j < teckStackarray.length; j++) {
                 if (teckStackarray[j] !== serviceinsatnce[i].PrototypePlatformField) {
                   teckStackarray.push(serviceinsatnce[i].PrototypePlatformField);
                 }
               }
             }
            if (this.extendflag === false) {
            let newapprovedate = serviceinsatnce[i].DurationNeededField;
          newapprovedate = new Date(newapprovedate).toLocaleString('en-IN', this.extensiondateoptions);
          newapprovedate = newapprovedate.split('/').reverse();
      newapprovedate = newapprovedate.join('-');
       this.requestinstances[i].DurationNeededField = newapprovedate;
      } else if (this.extendflag === true) {
                    let newapprovedate = this.requestinstances[i].provision_date_to;
              newapprovedate = new Date(newapprovedate).toLocaleString('en-IN', this.extensiondateoptions);
              newapprovedate = newapprovedate.split('/').reverse();
               newapprovedate = newapprovedate.join('-');
               this.requestinstances[i].provision_date_to = newapprovedate;
              }
            this.userEmail.push(this.requestinstances[i].assignedto);
            this.fromDate.push(this.requestinstances[i].provision_date_from);
            this.toDate.push(this.requestinstances[i].provision_date_to);
           }
           this.teckStacksRequested = teckStackarray.join(',');
  });
  }
   backToservicerequest() {
    this.loading = false;
      this._location.back();
   }
   assignflagfun(i) {
     this.userdoesntexists[i] = false;
     if (this.emailcount.length !== 0 ) {
    this.emailcount[i] = false;
     }
       this.assignflag = false;
   }
   emailvalidation(i) {
     this.emailflagcount = 0;
  if (this.userEmail[i]) {
     const emailobject = {
      email : this.userEmail[i]
     };
      this.networkingservice.post('/servicerequest/validatetoyboxuser', emailobject)
      .subscribe(userexist => {
        const assignresponse = userexist;
          if (assignresponse === 'user doesn\'t exist') {
          this.userdoesntexists[i] = true;
        } else if (assignresponse === 'user does exist') {
           this.emailcount[i] = true;
           for (let j = 0; j <= this.requestinstances.length; j++) {
             if (this.emailcount[j] === true) {
               this.emailflagcount++;
             }
           }
            if (this.emailflagcount === this.requestinstances.length) {
            this.assignflag = true;
           }
        }
      });
   }
   }
   updateinstances() {
    const requestinstances = this.servicerequest.serviceInstance;
    this.data.changeMessage({id: this.req_id, status: 'instancesAssigned'});
    const newapprovedate = new Date(Date.now());
    this.newapprovedate = this.date.toLocaleString('en-IN', this.options);
     for (let i = 0 ; i < this.requestinstances.length; i++) {
       let operationsystem;
       let prototypeplatform;
      if (this.crowdconfig === false) {
        operationsystem = requestinstances[i].OperatingSystemField,
        prototypeplatform = requestinstances[i].PrototypePlatformField;
      } else if (this.crowdconfig === true) {
        operationsystem = this.OperatingSystem[i],
        prototypeplatform = this.PrototypePlatform[i];
      }
       const updateinstance = {
         OperatingSystemField : operationsystem,
         PrototypePlatformField: prototypeplatform,
         id : this.requestinstances[i].id,
        assignedto : this.userEmail[i],
        service_id : this.urlParams.params.id,
        provision_date_from : this.fromDate[i],
        provision_date_to : this.toDate[i],
        approvedDate: this.newapprovedate,
        requesteremail : this.requesteremail,
        userConfigure: this.userconfigure,
       };
        if (typeof(this.userEmail[i]) === 'object') {
        updateinstance.assignedto = this.userEmail[i].email;
       }
     const userAssignInstanceDate = {
      email : this.userEmail[i],
      startDate:  this.fromDate[i],
      endDate: this.toDate[i]
     };
     this.userDateAssignArray.push(userAssignInstanceDate);
      this.updateinstanceArray.push(updateinstance);
     }
          for (let j = 0; j <= this.updateinstanceArray.length - 1; j++) {
             let maxdate = this.updateinstanceArray[j].provision_date_to.split('-');
              const month_maxdate = maxdate[1];
                const year_maxdate = maxdate[2];
                const  day_maxdate = maxdate[0];
                  maxdate = [day_maxdate, month_maxdate, year_maxdate].join('/');
            this.sample_maxdate.push(new Date(maxdate));
     }
     const maxDate = new Date(Math.max.apply(null, this.sample_maxdate));
    this.updateinstanceArray.push({tilldate: maxDate});
    this.networkingservice.post('/servicerequest/assigninstances', this.updateinstanceArray)
     .subscribe(updateinstancesresponse => {
       this.loading = false;
       const assignresponse = updateinstancesresponse;
        if (this.mail.userGroup === 'SUPERADMIN') {
        this.router.navigateByUrl('/admin/rbac-dashboard');
        } else {
          this.router.navigateByUrl('/servicebox/service-request');
        }
        this.Assigntoast = true;
  });
   }
   viewdetails() {
     this.router.navigateByUrl('/servicebox/service-request/service-form?id=' + this.urlParams.params.id + '&action=view');
   }
  extendfun() {
   const extendedarray = [ ];
for (let i = 0 ; i < this.requestinstances.length ; i++) {
  const fromdate = this.fromDate[i].toLocaleString('en-IN', this.options);
  const todate = this.toDate[i].toLocaleString('en-IN', this.options);
  const extendobj = {
    id : this.requestinstances[i].id,
    service_reqid: this.urlParams.params.id,
    provision_date_from : fromdate,
    provision_date_to : todate
   };
    extendedarray.push(extendobj);
}
 this.networkingservice.post('/servicerequest/ExtendRequest', extendedarray)
  .subscribe(successresponse => {
    if (successresponse = 'success') {
    this.router.navigate(['/servicebox/service-request']);
  }
  });
}}


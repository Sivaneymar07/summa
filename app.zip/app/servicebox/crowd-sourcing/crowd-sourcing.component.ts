import { Component, OnInit } from '@angular/core';
import { NetWorkingService } from '../../shared/networking.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DataService } from '../../shared/data.service';
import { CompleterService, CompleterData } from 'ng2-completer';
import { ClickOutsideModule } from 'ng-click-outside';
import { HostListener } from '@angular/core';
import * as moment from 'moment';
import { ScrollToService, ScrollToConfigOptions, ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-crowd-sourcing',
  templateUrl: './crowd-sourcing.component.html',
  styleUrls: ['./crowd-sourcing.component.css'],
  animations: [
    trigger('fade', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(700)
      ]),
      transition('* => void', [
        animate('0.5s 0.5s ease-out', style({
          opacity: 0
        }))
      ])
    ])
  ]
})
export class CrowdSourcingComponent implements OnInit {
  serviceRequest: any;
  date = new Date();
  todaydate: Date;
  instancedata = [];
  urlParams: any;
  showcrowdsource: Boolean = false;
  roleArray: Array<any> = [];
  developer: any;
  selectedReassign: any;
  reassigneduser: any;
  Interests: string;
  addresourcespopup = false;
  dataflag: Array<Boolean> = [];
  dataflag1: Array<Boolean> = [];
  interestSection = [];
  crowdreassign: Boolean = false;
  deleteresourcesavetoast: Boolean = false;
  closepopup: Boolean = false;
  public dataService: CompleterData;
  Resources = [];
  CrowdSources = [];
  selectedRoles = [];
  selectedNomineeRoles = [];
  assignResources = [];
  addingtemparra = [];
  multipleRes: Boolean = false;
  enrollnominees = [];
  mailShow: any;
  showButtonDiv: Boolean = false;
  resourceOpted: Boolean = false;
  reassignindex: number;
  lengthNeeded: number;
  loading: Boolean = true;
  skills = '';
  Roles: String;
  text: String;
  reassignedindex: any;
  fromDate: any;
  mail = [];
  changepopup: Array<Boolean> = [];
  approvesavetoast: Boolean = false;
  showdatepicker: Boolean = false;
  SkillSet: any;
  serviceLifeSpanFrom: any;
  serviceLifeSpanTo: any;
  serviceLifeSpanFromPicker: any;
  serviceLifeSpanToPicker: any;
  selectedRoleval: any;
  developer_crowdTs: any;
  addresourcesdrop = false;
  environments: any;
  reqId: any;
  number: number;
  crowdsourcing: Array<any> = [];
  reassignUser = [];
  options1 = {
    year: 'numeric', month: '2-digit',
    day: '2-digit',
  };
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric'
  };
  newDate: any;
  unavailableResources = [];
  positioncrowdsourcing: Boolean = false;
  RolePosition: string;
  UX_Campaign = [];
  VD_Campaign = [];
  Dev_Campaign = [];
  Resources_id = [];
  saveDialog = false;
  savedresourcessavetoast = false;
  popupCount = 0;
  devLength = [];
  developersenrolled = [];
  uxenrolled = [];
  vdenrolled = [];
  detailscrolltop = false;
  tempEnrolled = [];
  resourceRoles = ['UX', 'VD', 'DEVELOPER'];
  queryObject = {};
  developercount = 0;
  uxcount = 0;
  vdcount = 0;

  constructor(private route: ActivatedRoute, private networkingservice: NetWorkingService,
    private translate: TranslateService,
    private router: Router, private completerService: CompleterService, private data: DataService,
    private _scrollToService: ScrollToService) {
    this.dataService = completerService.local(this.resourceRoles);
  }

  ngOnInit() {
    this.translate.get('SkillSet').subscribe((res: any) => { this.SkillSet = res; });
    this.translate.get('developer_crowdTs').subscribe((res: any) => { this.developer_crowdTs = res; });
    this.translate.get('selectedRoleval').subscribe((res: any) => { this.selectedRoleval = res; });
    let response;
    this.data.currentMessage.subscribe(res => {
      response = JSON.stringify(res);
      response = JSON.parse(response);
      this.reqId = response.id;
      if (response.crowd === true && response.status === 'requestApproved') {
        this.approvesavetoast = true;
        setTimeout(() => {
          this.approvesavetoast = false;
        }, 5000);
      }
    });
    const userObj = JSON.parse(localStorage.getItem('user'));
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    this.queryObject = { 'query': this.urlParams.params.id, 'lang': 'en', 'view': true };
    this.networkingservice.post('/servicerequest/getServiceRequests', this.queryObject).subscribe(data => {
      this.serviceRequest = data;
      const currentDate = new Date();
      const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
      this.serviceLifeSpanFrom = currentDate.getDate() + ' ' + monthNames[currentDate.getMonth()];
      this.serviceLifeSpanFromPicker = this.formateDate(currentDate);
      this.todaydate = this.serviceLifeSpanFromPicker;
      if (this.serviceRequest.Fidelity === 'Low Fidelity') {
        const dayWrapper = moment(currentDate);
        var b = dayWrapper.add(4, 'week');
        b.format();
      } else if (this.serviceRequest.Fidelity === 'High Fidelity') {
        const dayWrapper = moment(currentDate);
        var b = dayWrapper.add(8, 'week');
        b.format();
      }
      const enddate = new Date(b.format()).toISOString();
      const todate = new Date(enddate);
      this.serviceLifeSpanTo = todate.getDate() + ' ' + monthNames[todate.getMonth()];
      this.serviceLifeSpanToPicker = this.formateDate(todate);
      if (this.serviceRequest.status === 'Pending Provisioning') {
        this.networkingservice.post('/servicerequest/assigned_crowd', { id: this.serviceRequest.id }).subscribe(data => {
          data.forEach((e) => {
            this.Resources.push(e.user_id);
          });
        });
      } else {
        this.networkingservice.post('/servicerequest/savednext2days', {}).subscribe(data => {
          this.networkingservice.post('/servicerequest/getsavedResources', { id: this.serviceRequest.id }).subscribe(data => {
            if (data.length !== 0) {
              console.log("one",this.serviceRequest)
              this.Resources = data;
              this.Resources.forEach(function (r) {
                this.serviceRequest[0].savedResourceRole.forEach(function (d, index) {
                  console.log("sdjklsdjklsdjklsdjklsdjklsdjklsdjkl")
                  // if (r.email == d.email) {
                  //   console.log("check")
                  //   r.enterrole = d.role;
                  //   // data.splice(index, 1);
                  // }
                });
              });
              console.log("this.resources", this.Resources)
              // for (let i = 0; i < this.Resources.length; i++) {
              //   this.Resources[i].enterrole = this.serviceRequest.savedResourceRole[i];
              // }
              for (let i = 0; i < this.Resources.length; i++) {
                // const years_months = (this.Resources[i].experience / 12);
                // const years = years_months.toFixed(1);
                // this.Resources[i].experience = years;
                if (this.Resources[i].enterrole === 'Developer') {
                  this.developercount++;
                } else if (this.Resources[i].enterrole === 'UX Designer') {
                  this.uxcount = 1;
                } else if (this.Resources[i].enterrole === 'Visual Designer') {
                  this.vdcount = 1;
                }
              }
              if (this.serviceRequest.skillsetneeded == null) {
                this.unavailableResources = [{ 'UX': [''], 'VD': [''], 'DEVELOPER': [''] }];
                if (this.serviceRequest.Fidelity === 'Low Fidelity') {
                  if (this.developercount === 0) {
                    this.devLengthTile(2);
                    this.unavailableResources[0].DEVELOPER.length = 0;
                  }
                } else {
                  this.devLengthTile(this.developercount);
                }
                if (this.uxcount === 0) {
                  this.unavailableResources[0].UX.length = 0;
                }
                if (this.vdcount === 0) {
                  this.unavailableResources[0].VD.length = 0;
                }
              } else {
                this.lowfidelitysavedTile();
                this.getNominees(this.queryObject);
              }
            } else {
              console.log("two")
              this.serviceFunction();
            }
          });
        });
      }
    });
  }
  serviceFunction() {
    const obje = {
      'fromDate': new Date(), 'toDate': this.serviceLifeSpanToPicker,
      'lang': 'en', query: this.serviceRequest.techStackArray, 'fidelity': this.serviceRequest.Fidelity
    };
    if (this.serviceRequest.Fidelity === 'Low Fidelity') {
      this.getInstanceLowFidelity(obje, this.queryObject);
    } else {
      this.getInstanceHighFidelity(obje, this.queryObject);
    }
  }
  getNominees(obj) {
    this.networkingservice.post('/servicerequest/getnominees/', obj).subscribe(data => {
      if (data.length === 0 && this.serviceRequest.skillsetneeded == null) {
        if (this.serviceRequest.Fidelity === 'Low Fidelity') {
          if (this.unavailableResources[0].DEVELOPER.length === 0) {
            this.devLengthTile(2);
          }
        } else if (this.serviceRequest.Fidelity === 'High Fidelity') {
          if (this.unavailableResources[0].DEVELOPER.length === 0) {
            this.devLengthTile(0);
          } else if (this.unavailableResources[0].DEVELOPER.length === 1) {
            this.devLengthTile(1);
          } else if (this.unavailableResources[0].DEVELOPER.length === 2) {
            this.devLengthTile(2);
          }
        }
      } else {
        this.UX_Campaign = data.filter(elem => elem.role === 'UX');
        this.UX_Campaign.forEach(e => {
          this.uxenrolled.push(e.user_id);
        });
        this.VD_Campaign = data.filter(elem => elem.role === 'VD');
        this.VD_Campaign.forEach(e => {
          this.vdenrolled.push(e.user_id);
        });
        this.Dev_Campaign = data.filter(elem => elem.role === 'DEVELOPER');
        this.Dev_Campaign.forEach(e => {
          this.developersenrolled.push(e.user_id);
        });
        if (this.uxenrolled.length === 1) {
          this.uxenrolled[0].enterrole = 'UX Designer';
        }
        if (this.vdenrolled.length === 1) {
          this.vdenrolled[0].enterrole = 'Visual Designer';
        }
        if (this.serviceRequest.skillsetneeded.includes('DEVELOPER') && this.serviceRequest.Fidelity === 'High Fidelity') {
          this.lengthNeeded = 3 - this.unavailableResources[0].DEVELOPER.length;
          if (this.lengthNeeded >= this.developersenrolled.length) {
            this.devLengthTile(3 - this.lengthNeeded);
            if (this.developersenrolled.length === 0) {
              for (let i = 0; i < this.lengthNeeded; i++) {
                this.Dev_Campaign.length = 0;
              }
            } else if (this.developersenrolled.length <= 3) {
              for (let i = 0; i < this.lengthNeeded; i++) {
                this.Dev_Campaign.length = 1;
              }
            }
          } else {
            for (let i = 0; i < this.lengthNeeded; i++) {
              this.Dev_Campaign.length = 2;
            }
            this.devLengthTile(3 - this.lengthNeeded);
          }
          if (this.unavailableResources[0].DEVELOPER.length === 3) {
            this.devLengthTile(2);
            this.unavailableResources[0].DEVELOPER.length = 2;
          }
        }
      }
      for (let i = 0; i < this.Resources.length; i++) {
        const years_months = (this.Resources[i].experience / 12);
        const years = years_months.toFixed(1);
        this.Resources[i].experience = years;
      }
    });

  }
  backToCategoryList() {
    this.router.navigate(['/admin/rbac-dashboard'], {
      relativeTo: this.route
    });
  }
  formateDate(dateValue) {
    const dropdowndate = dateValue.toLocaleString('en-IN', this.options1);
    const tempDate = dropdowndate.split('/').reverse().join('-');
    return tempDate;
  }
  getInstanceLowFidelity(obje, obj) {
    const ref = this;
    function promise() {
      return new Promise((resolve, reject) => {
        ref.networkingservice.post('/servicerequest/getInstanceLowFidelity', obje).subscribe(data => {
          ref.roleUIchanges(data);
          ref.mailPopupChangeslowfidelity(data);
          ref.initializetext();
          if (obj != null) {
            ref.getNominees(obj);
          }
          resolve('success');
        });
      });
    }
    async function main() {
      const response = await promise();
      return response;
    }
    main().then((res) => {
      return res;
    });
  }
  getInstanceHighFidelity(obje, obj) {
    const ref = this;
    function promise() {
      return new Promise((resolve, reject) => {
        ref.networkingservice.post('/servicerequest/getInstanceHighFidelity', obje).subscribe(data => {
          ref.roleUIchanges(data);
          ref.mailPopupChangeshighfidelity(data);
          ref.initializetext();
          if (obj != null) {
            ref.getNominees(obj);
          }
          resolve('success');
        });
      });
    }
    async function main() {
      const response = await promise();
      return response;
    }
    main().then((res) => {
      return res;
    });
  }
  roleUIchanges(data) {
    data.DEVELOPER.forEach(e => {
      e.enterrole = 'Developer';
    });
    data.UX.forEach(e => {
      e.enterrole = 'UX Designer';
    });
    data.VD.forEach(e => {
      e.enterrole = 'Visual Designer';
    });
  }
  mailPopupChangeslowfidelity(data) {
    this.Resources = [];
    this.unavailableResources = [];
    this.instancedata = [];
    this.instancedata = this.instancedata.concat(data.UX);
    this.instancedata = this.instancedata.concat(data.VD);
    this.instancedata = this.instancedata.concat(data.DEVELOPER);

    if (this.serviceRequest.skillsetneeded == null) {
      this.unavailableResources.push(data);
      if (this.unavailableResources[0].UX.length === 0) {
        this.roleArray.push('UX');
      }
      if (this.unavailableResources[0].VD.length === 0) {
        this.roleArray.push('VD');
      } if (this.unavailableResources[0].DEVELOPER.length === 0) {
        this.roleArray.push('DEVELOPER');
      }
    } else {
      this.roleArray = [];
      this.devLength = [];
      this.lowfidelitysavedTile();
      // this.getNominees(this.queryObject);
    }
    this.Resources = this.Resources.concat(this.instancedata);
    for (let i = 0; i < this.Resources.length; i++) {
      this.mailShow = this.Resources[i].email;
      if (this.Resources[i].ldap) {
        this.mail = this.mailShow.split('.');
        this.Resources[i].Initial = this.mail[0][0].concat(this.mail[1][0]);
      } else {
        this.Resources[i].Initial = this.Resources[i].name[0].concat(this.Resources[i].name[1]);
      }
    }
  }
  /* getting tile after saved resources*/
  lowfidelitysavedTile() {
    const obj = { UX: [''], VD: [''], DEVELOPER: [''] };
    this.roleArray = [];
    for (let i = 0; i < this.serviceRequest.skillsetneeded.length; i++) {
      this.roleArray.push(this.serviceRequest.skillsetneeded[i]);

      if (this.serviceRequest.skillsetneeded[i] === 'VD') {
        obj.VD.length = 0;
      } else if (this.serviceRequest.skillsetneeded[i] === 'UX') {
        obj.UX.length = 0;
      } else if (this.serviceRequest.skillsetneeded[i] === 'DEVELOPER') {
        this.devLengthTile(2);
      }
    }
    this.unavailableResources.pop();
    this.unavailableResources.push(obj);
  }
  mailPopupChangeshighfidelity(data) {
    this.Resources = [];
    this.unavailableResources = [];
    this.instancedata = [];
    this.instancedata = this.instancedata.concat(data.UX);
    this.instancedata = this.instancedata.concat(data.VD);
    this.instancedata = this.instancedata.concat(data.DEVELOPER);
    if (this.serviceRequest.skillsetneeded == null) {
      this.unavailableResources.push(data);
      if (this.unavailableResources[0].UX.length === 0) {
        this.roleArray.push('UX');
      }
      if (this.unavailableResources[0].VD.length === 0) {
        this.roleArray.push('VD');
      } if (this.unavailableResources[0].DEVELOPER.length < 3) {
        this.roleArray.push('DEVELOPER');
      }
    } else {
      this.roleArray = [];
      this.devLength = [];
      const obj = { UX: [''], VD: [''], DEVELOPER: [''] };
      for (let i = 0; i < this.serviceRequest.skillsetneeded.length; i++) {
        if (this.serviceRequest.skillsetneeded[i] === 'VD') {
          obj.VD.length = 0;
          this.unavailableResources.push(obj);
        } else if (this.serviceRequest.skillsetneeded[i] === 'UX') {
          obj.UX.length = 0;
          this.unavailableResources.push(obj);
        }
        if (this.serviceRequest.skillsetneeded[i] === 'DEVELOPER') {
          obj.DEVELOPER = data.DEVELOPER;
          this.unavailableResources.push(obj);
        }
      }
    }
    this.Resources = this.Resources.concat(this.instancedata);
    for (let i = 0; i < this.Resources.length; i++) {
      this.mailShow = this.Resources[i].email;
      if (this.Resources[i].ldap) {
        this.mail = this.mailShow.split('.');
        this.Resources[i].Initial = this.mail[0][0].concat(this.mail[1][0]);
      } else {
        this.Resources[i].Initial = this.Resources[i].name[0].concat(this.Resources[i].name[1]);
      }
    }
  }
  devLengthTile(len) {
    for (let i = len; i < 3; i++) {
      this.devLength.push(i);
    }
  }
  onDateChange() {
    this.roleArray = [];
    this.Resources = [];
    this.instancedata = [];
    let tempdate = new Date(this.serviceLifeSpanFromPicker);
    const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    this.serviceLifeSpanFrom = tempdate.getDate() + ' ' + monthNames[tempdate.getMonth()];
    tempdate = new Date(this.serviceLifeSpanToPicker);
    this.serviceLifeSpanTo = tempdate.getDate() + ' ' + monthNames[tempdate.getMonth()];
    const obje = {
      'fromDate': this.serviceLifeSpanFromPicker, 'toDate': this.serviceLifeSpanToPicker,
      'lang': 'en', query: this.serviceRequest.techStackArray, 'fidelity': this.serviceRequest.Fidelity
    };
    if (this.serviceRequest.Fidelity === 'Low Fidelity') {
      this.getInstanceLowFidelity(obje, null);
    } else {
      this.getInstanceHighFidelity(obje, null);
    }
    this.showdatepicker = false;
  }
  reassignFun(index) {
    this.reassignedindex = index;
    this.changepopup[index] = !this.changepopup[index];
  }
  deleteFieldValue(index) {
    this.changepopup[index] = !this.changepopup[index];
    this.Resources.splice(index, 1);
    this.deleteresourcesavetoast = true;
    setTimeout(() => {
      this.deleteresourcesavetoast = false;
    }, 5000);
  }
  assignCrowd(index, role) {
    if (role === 'Developer') {
      this.Roles = 'DEVELOPER';
    } else if (role === 'UX Designer') {
      this.Roles = 'UX';
    } else if (role === 'Visual Designer') {
      this.Roles = 'VD';
    }
    const obj = { query: this.Roles };
    this.getRoleResources(obj);
    this.changepopup[index] = !this.changepopup[index];
    this.crowdreassign = !this.crowdreassign;
    this.triggerScrollTo('HeaderWrapper');
    for (const i in this.CrowdSources) {
      if (this.CrowdSources.hasOwnProperty(i)) {
        this.reassignUser[i] = false;
      }
    }
  }
  addFieldValue() {
    this.triggerScrollTo('HeaderWrapper');
    this.addresourcespopup = true;
    const skillset = { query: 'UX' };
    this.getRoleResources(skillset);
  }
  interestsection(event) {
    this.showButtonDiv = true;
    this.tempEnrolled = this.tempEnrolled.concat(this.roleArray);
    const interestsection = this.Interests.split(',');
    if (interestsection.length > 1) {
      for (const i in interestsection) {
        if (this.interestsection.hasOwnProperty(i)) {
          this.roleArray.push(interestsection[i].toLocaleUpperCase());
        }
      }
    } else {
      this.showButtonDiv = true;
      this.roleArray.push(this.Interests.toLocaleUpperCase());
    }
    const a = this.roleArray;
    this.roleArray = a.filter(function (item, pos) {
      return a.indexOf(item) === pos;
    });
    this.Interests = '';
  }
  initializetext() {
    this.text = 'There is an active crowd campaign for building ' + this.serviceRequest.Preferredplatform +
      ' based ' + this.serviceRequest.Fidelity + ' prototype for ' + this.serviceRequest.Clientname + '. We would be needing ' +
      this.roleArray + '. \n\nClientName : ' + this.serviceRequest.Clientname + '\nTech Category : ' +
      this.serviceRequest.Preferredplatform + '\nProject Time Line : ' +
      this.serviceRequest.dueDate + '-' + this.serviceRequest.tilldate + '\nRequired Roles :' + this.roleArray +
      '\n\nKindly make sure that your profile information is complete in Toybox.This will help in the selection process.\nYou will receive confirmation mailer if your nomination is accepted.\n';
  }
  closeinterest(index) {
    this.showcrowdsource = true;
    for (let i = 0; i < this.interestSection.length; i++) {
      if (this.interestSection[i] === this.roleArray[index]) {
        this.dataflag[i] = !this.dataflag[i];
      }
    }
    for (let i = 0; i < this.dataflag.length; i++) {
      this.dataflag1[i] = this.dataflag[i];
    }
    this.roleArray.splice(index, 1);
    this.initializetext();
  }
  launchCampaign(role) {
    const temp = [role];
    this.positioncrowdsourcing = false;
    this.showcrowdsource = false;
    let roles;
    if (role) {
      roles = { enteredrole: temp };
    } else {
      roles = { enteredrole: this.roleArray };
    }
    this.newDate = this.date.toLocaleString('en-IN', this.options);
    const campaigndetails = {
      roleentered: roles,
      campaigneddate: this.newDate
    };
    this.networkingservice.post('/users/campaign/' + this.serviceRequest.id, campaigndetails).subscribe(data => {
      this.serviceRequest = data;
      this.devLength.length = 0;
      this.lowfidelitysavedTile();
      this.showcrowdsource = false;
    });
  }
  sendmail(role) {
    if (role) {
      const skills = { query: role.toUpperCase(), params: this.serviceRequest, text: this.text };
      this.networkingservice.post('/users/sendmailvd/', skills).subscribe(data => {
      });
    } else {
      for (let i = 0; i < this.roleArray.length; i++) {
        const skills = { query: this.roleArray[i].toUpperCase(), params: this.serviceRequest, text: this.text };
        this.networkingservice.post('/users/sendmailvd/', skills).subscribe(data => {
        });
      }
    }
  }
  cancel() {
    this.showcrowdsource = false;
    this.positioncrowdsourcing = false;
  }
  saveResources() {
    this.saveDialog = true;
  }
  saveCrowdResources() {
    this.Resources_id = [];
    const savedResourceRole = [];
    this.Resources.forEach((e) => {
      this.Resources_id.push(e.id);
      savedResourceRole.push({ email: e.email, role: e.enterrole });
    });
    const res_obj = {
      id: this.serviceRequest.id,
      resources: this.Resources_id,
      savedResourceRole: savedResourceRole
    };
    console.log("asdjfklasdjlasdfasdffffffff", this.Resources)


    this.networkingservice.put('/servicerequest/saveCrowdResources', res_obj).subscribe(data => {
    });
    this.saveDialog = false;
    this.savedresourcessavetoast = true;
    setTimeout(() => {
      this.savedresourcessavetoast = false;
    }, 5000);
  }
  cancelCrowdResources() {
    this.saveDialog = false;
  }
  userconfig() {
    const obj = { 'query': this.urlParams.params.id, 'lang': 'en', 'view': true };
    this.data.changeMessage({ id: this.serviceRequest.req_id, status: 'crowdSourced' });
    this.Resources.forEach((e) => {
      this.assignResources.push({ user_id: e.id, email: e.email });
    });
    const assignResourcesdetails = {
      assignResources: this.assignResources,
      serviceLifeSpanFromPicker: this.serviceLifeSpanFromPicker,
      serviceLifeSpanToPicker: this.serviceLifeSpanToPicker
    };
    this.networkingservice.put('/servicerequest/assigncrowd/' + this.serviceRequest.id, assignResourcesdetails).subscribe(data => {
      this.Resources = data;
    });
    this.router.navigateByUrl('/admin/rbac-dashboard');

    const notedate = new Date(Date.now());
    const newnotedate = notedate;
    this.networkingservice.post('/servicerequest/getnominees/', obj).subscribe(data => {
      for (let i = 0; i < data.length; i++) {
        let approveFlag = true;
        for (let j = 0; j < this.assignResources.length; j++) {
          if (data[i].user_id.id === this.assignResources[j].user_id) {
            approveFlag = false;
            const campaignNotification = {
              email: data[i].user_id.email,
              ref_id: '',
              action: '',
              notificationtag: 'Campaign',
              message: 'You are selected for the campaign request',
              status: 'Approved',
              notificationDate: newnotedate,
              serviceRequest: data[i].service_id.ServiceRequested
            };
            this.networkingservice.post('/users/notification', campaignNotification).subscribe((res) => {
            });
          }
        }
        if (approveFlag) {
          const campaignNotification = {
            email: data[i].user_id.email,
            ref_id: '',
            action: '',
            notificationtag: 'Campaign',
            message: 'You are rejected for the campaign request',
            status: 'Rejected',
            notificationDate: newnotedate,
            serviceRequest: data[i].service_id.req_id
          };
          this.networkingservice.post('/users/notification', campaignNotification).subscribe((res) => {
          });
        }
      }
    });
  }
  cancelcrowd() {
    this.router.navigateByUrl('/admin/rbac-dashboard');
  }
  reassignCrowd() {
    this.reassigneduser = this.selectedReassign;
    this.crowdreassign = !this.crowdreassign;
    this.developersenrolled.splice(this.reassignindex, 1, this.Resources[this.reassignedindex]);
    this.Resources.splice(this.reassignedindex, 1, this.CrowdSources[this.reassignindex]);
    this.reassignUser = [];
  }
  cancelreassign() {
    this.closepopup = !this.closepopup;
  }
  closeanotherRes() {
    this.selectedRoleval = 'UX';
  }
  canceladdanotherresource() {
    this.addresourcespopup = !this.addresourcespopup;
    this.selectedRoles = [];
    this.selectedRoleval = 'UX';
    this.addresourcesdrop = false;
  }
  addingResources() {
    this.Resources = this.Resources.concat(this.addingtemparra);
    this.Resources = this.removeDuplicates(this.Resources, 'email');
    this.addresourcespopup = !this.addresourcespopup;
    this.addingtemparra = [];
    this.selectedRoles = [];
    this.selectedRoleval = 'UX';
    this.addresourcesdrop = false;
  }
  addingNomineeResources() {
    if (this.Roles === 'UX') {
      this.unavailableResources[0].UX.length = 1;
    } else if (this.Roles === 'VD') {
      this.unavailableResources[0].VD.length = 1;
    } else if (this.Roles === 'DEVELOPER') {
      if (this.serviceRequest.fidelity === 'Low Fidelity') {
        this.unavailableResources[0].DEVELOPER.length = 4;
      } else {
        this.devLength.pop();
      }
    }
    this.Resources = this.Resources.concat(this.addingtemparra);
    this.addingtemparra.forEach(arr => {
      this.enrollnominees.splice(this.enrollnominees.indexOf(arr), 1);
    });
    this.developersenrolled = this.enrollnominees;
    this.multipleRes = !this.multipleRes;
    this.addingtemparra = [];
  }
  cancelNomineeResources() {
    this.multipleRes = false;
  }
  resourcesfilter(skills) {
    this.selectedRoleval = skills;
    this.selectedNomineeRoles.length = 0;
    if (!skills) {
      return;
    }
    const skillset = { query: skills };
    this.getRoleResources(skillset);
  }
  getNomineeResources(skills) {
    console.log("coming", this.VD_Campaign)
    this.enrollnominees = [];
    if (skills === 'UX') {
      this.uxenrolled.forEach((e) => {
        this.enrollnominees.push(e);
      });
      this.enrollnominees.forEach((e) => {
        e.enterrole = 'UX Designer';
      });
    } else if (skills === 'VD') {
      this.vdenrolled.forEach((e) => {
        this.enrollnominees.push(e);
      });
      this.enrollnominees.forEach((e) => {
        e.enterrole = 'Visual Designer';
      });
    } else if (skills === 'DEVELOPER') {
      this.developersenrolled.forEach((e) => {
        this.enrollnominees.push(e);
      });
      this.enrollnominees.forEach((e) => {
        e.enterrole = 'Developer';
      });
    }
    console.log("enrollnominees", this.enrollnominees)
    if (this.enrollnominees.length > 0) {
      this.resourceOpted = true;
    } else {
      this.resourceOpted = false;
    }
    // this.enrollnominees.forEach((nominees) => {
    //   const years_months = (nominees.experience / 12);
    //   const years = years_months.toFixed(1);
    //   nominees.experience = years;
    // });
  }
  getRoleResources(skillset) {
    this.enrollnominees = [];
    const object = { skillset: skillset, fromDate: new Date(), toDate: this.serviceLifeSpanToPicker };
    this.networkingservice.post('/users/getCrowdSourcingData', object).subscribe(data => {
      this.Resources.forEach(function (r) {
        data.forEach(function (d, index) {
          if (r.id === d.id) {
            data.splice(index, 1);
          }
        });
      });
      if (data.length === 0) {
        if (skillset.query === 'DEVELOPER') {
          this.enrollnominees = [];
          this.developersenrolled.forEach(e => {
            this.enrollnominees.push(e);
          });
        } else if (skillset.query === 'VD') {
          this.enrollnominees = [];
          this.vdenrolled.forEach(e => {
            this.enrollnominees.push(e);
          });
        } else if (skillset.query === 'UX') {
          this.enrollnominees = [];
          this.uxenrolled.forEach(e => {
            this.enrollnominees.push(e);
          });
        }
        data = this.enrollnominees;
      }
      data.forEach(resource => {
        const years_months = (resource.experience / 12);
        const years = years_months.toFixed(1);
        resource.experience = years;
        if (resource.enterrole === 'DEVELOPER') {
          resource.enterrole = 'Developer';
        } else if (resource.enterrole === 'UX') {
          resource.enterrole = 'UX Designer';
        } else if (resource.enterrole === 'VD') {
          resource.enterrole = 'Visual Designer';
        }
      });
      this.CrowdSources = data;
    });
  }
  getUserName(reassignindex) {
    for (const i in this.CrowdSources) {
      if (this.CrowdSources.hasOwnProperty(i)) {
        this.reassignUser[this.CrowdSources[i]] = false;
      }
    }
    this.reassignindex = reassignindex;
    this.selectedReassign = this.CrowdSources[reassignindex];
    this.reassignUser = [];
    this.reassignUser[reassignindex] = true;
  }
  getUserCheckedName(i, flag) {
    if (!flag) {
      this.selectedRoles.push(i);
      this.addingtemparra.push(this.CrowdSources[i]);
    } else {
      this.selectedRoles.splice(this.selectedRoles.indexOf(i), 1);
      this.addingtemparra.splice(this.addingtemparra.indexOf(this.CrowdSources[i]), 1);
    }
  }
  getUserNomineeCheckedName(nomineesindex, flag) {
    if (!flag) {
      this.selectedNomineeRoles.push(nomineesindex);
      this.addingtemparra.push(this.enrollnominees[nomineesindex]);
    } else {
      this.selectedNomineeRoles.splice(this.selectedNomineeRoles.indexOf(nomineesindex), 1);
      this.addingtemparra.splice(this.addingtemparra.indexOf(this.enrollnominees[nomineesindex]), 1);
    }
  }
  removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }
  cancelassigncrowd() {
    this.crowdreassign = !this.crowdreassign;
    this.showcrowdsource = false;
    this.reassignUser = [];
  }
  crowdsource() {
    this.showcrowdsource = !this.showcrowdsource;
  }
  canceldatepopup() {
    this.showdatepicker = false;
  }
  public triggerScrollTo(location) {
    const config: ScrollToConfigOptions = {
      target: location,
      duration: 1500,
      easing: 'easeOutElastic',
      offset: 0
    };
    this._scrollToService.scrollTo(config);
  }
  /*-----------------date functionality------------*/
  datepicker() {
    this.showdatepicker = !this.showdatepicker;
  }
  crowdsourceRole(role) {
    this.RolePosition = role;
    this.positioncrowdsourcing = true;
  }
  onClickedOutside(e: Event) {
    this.showcrowdsource = false;
    this.addresourcesdrop = false;
    this.showdatepicker = false;
    this.changepopup[this.reassignedindex] = false;
  }
  onClickedOutside2(event) {
    this.popupCount++;
    if (this.popupCount === 2) {
      this.changepopup[this.reassignedindex] = false;
      this.showdatepicker = false;
      this.popupCount = 0;
    }
  }
  /**********resources from nominees******** */
  assignNominees(role, i) {
    this.addingtemparra = [];
    this.selectedNomineeRoles.length = 0;
    this.Roles = role;
    this.multipleRes = true;
    this.getNomineeResources(this.Roles);
    this.triggerScrollTo('HeaderWrapper');
    for (const j in this.enrollnominees) {
      if (this.enrollnominees.hasOwnProperty(j)) {
        this.reassignUser[j] = false;
      }
    }
  }
  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.number = window.pageYOffset;
    if (this.number > 150) {
      this.detailscrolltop = true;
    } else {
      this.detailscrolltop = false;
    }
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbTabChangeEvent, NgbTabsetConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ServiceInterface } from '../../shared/service.interface';
import { TextMaskModule } from 'angular2-text-mask';
import { HostListener } from '@angular/core';
import { CompleterService, CompleterData } from 'ng2-completer';
import { NetWorkingService } from '../../shared/networking.service';
import { DataService } from '../../shared/data.service';
import { Location } from '@angular/common';
import { FileUploader, FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { ImagePreviewDirective } from '../../toolbox/adminform/image-preview.directive';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-service-form',
  templateUrl: './service-form.component.html',
  styleUrls: ['./service-form.component.css']
})
// -----------------------------flag details-----------------------
// techstackfinaldivboolean : techstack flag,
// submitDialog : submit Dialog popup,
// loading : loading flag,
// updatedialog : update dialog popup,
// deleteDialog : delete an environment Dialog popup,
// showHide : details onbehalf on someone else flag
// delenvironflag : deleting the environment flags
// showHide1 : request onbehalf on someone else flag
// updatebtn : update functionality flag
// approveflag : approve confirmation popup,
// revertflag: revert confirmation popup,
// rejectflag : reject confirmation popup,
// disabled = mouse disable one submit button;
// disableOnNext =  mouse disable one next button;;
// disabled1 =  mouse disable one next button;;
// -----------------------------flag details-----------------------
export class ServiceFormComponent implements OnInit {
  @ViewChild('t') ngbTabSet;
  public serviceAssetUploader: FileUploader = new FileUploader({ url: '/service/upload/' });
  protected searchStr: string;
  protected dataService: CompleterData;
  protected searchData = [
    'Windows AxureRP',
    'Windows Mean Stack',
    'Windows Balsamiq',
    'Linux AxureRP',
    'Linux Mean Stack',
    'Linux Balsamiq',
    'Mac AxureRP',
    'Mac Mean Stack',
    'Mac Balsamiq'
  ];
  adminFormNotification: any;
  techstackfinaldivboolean = false;
  techStackArray = [];
  submitDialog = false;
  updatedialog = false;
  loading = false;
  deleteDialog = false;
  showHide: boolean;
  delete_id: any;
  term = '';
  adminserviceflag: any;
  result: any;
  servicerejectComment: any;
  delenvironflag = false;
  showHide1 = false;
  number: number;
  delindex: any;
  count = 0;
  updatebtn = false;
  deleteRequest = false;
  onbehalfflag: Boolean = false;
  deleteEnvironment = false;
  duration = [];
  submit_id: any;
  tabCount = 1;
  tab1: boolean;
  tab2: boolean;
  tab3: boolean;
  tab4: boolean;
  tab5: boolean;
  tab6: boolean;
  tab7: boolean;
  tab8: boolean;
  tab9: boolean;
  tab10: boolean;
  tab11: boolean;
  tab12: boolean;
  tab13: boolean;
  Role: string;
  approveflag = false;
  revertflag = false;
  rejectflag = false;
  status = [];
  ServiceRequested: string;
  Requestername: string;
  email_address: string;
  Phonenumber: number;
  servicedate: any;
  userconfigure: Boolean = false;
  onbehalfname: string;
  onbehalfemail: string;
  onbehalfphonenumber: any;
  Clientname: string;
  Domain: string;
  RequestType: string;
  PreferredChannel: string;
  Preferredplatform: string;
  Fidelity: string;
  TechnologyStack: string;
  RequesttypeFlag = false;
  myVar = false;
  req_id: any;
  userObj: any;
  // number : number;
  environ: any;
  emailaddress: any;
  disabled = false;
  disableOnNext = true;
  action = '';
  serviceforms: ServiceInterface[] = [];
  serviceform: ServiceInterface;
  date = new Date();
  newDate: any;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric'
  };
  time: string = new Date().toLocaleString('en-IN', this.options);
  private environments: Array<any> = [];
  private newAttribute: any = {
    id: '',
    service_id: '',
    user_id: '',
    OperatingSystemField: '',
    PrototypePlatformField: '',
    InstanceNeededField: '',
    DurationNeededField: ''
  };
  instance_count: number;
  tcDialog = false;
  urlParams: any;
  updatesubmit = false;
  editDialog = false;
  updateForm: any;
  user_id: any;
  mongo_id: [any];
  platform = [];
  platform1: any;
  platform2: any;
  platform3: any;
  channel: any;
  Type: any;
  role: any;
  OS: any;
  Prototypeplatform: any;
  Instance: any;
  supportingFileName: any;
  serviceCollector: any;
  id: any;
  service: any;
  isthisDraft = false;
  maxrequestDate: any;
  dateoptions = {
    year: 'numeric', month: 'short',
    day: 'numeric' ,
  };
  serviceassets: any;

  constructor(private route: ActivatedRoute, private networkingservice: NetWorkingService, private router: Router,
    private _location: Location, private data: DataService, private completerService: CompleterService,
    private translate: TranslateService) {
    this.showHide = false;
    this.dataService = completerService.local(this.searchData);
    this.userObj = JSON.parse(localStorage.getItem('user'));
  }
  ngOnInit() {
    this.translate.get('operating_systems').subscribe((res: any) => { this.OS = res; });
    this.translate.get('prototyping_platform').subscribe((res: any) => { this.Prototypeplatform = res; });
    this.translate.get('Instance').subscribe((res: any) => { this.Instance = res; });
    this.translate.get('platform1').subscribe((res: any) => { this.platform1 = res; });
    this.translate.get('platform2').subscribe((res: any) => { this.platform2 = res; });
    this.translate.get('platform3').subscribe((res: any) => { this.platform3 = res; });
    this.translate.get('channel').subscribe((res: any) => { this.channel = res; });
    this.translate.get('Type').subscribe((res: any) => { this.Type = res; });
    this.translate.get('role_servicereq').subscribe((res: any) => { this.role = res; });
    this.environments.push({
      id: '',
      service_id: '',
      user_id: this.userObj.id,
      OperatingSystemField: '',
      PrototypePlatformField: '',
      InstanceNeededField: '',
      DurationNeededField: ''
    });
    this.getPosts();
    this.route.queryParamMap.subscribe(params => {
      this.urlParams = { ...params.keys, ...params };
    });
    this.data.currentMessage.subscribe(response => {
      this.adminserviceflag = response;
    });
    const obj = { 'query': this.urlParams.params.id, 'view': true };
    //  console.log(this.urlParams.params.id,"this.environmentsthis.environmentsthis.environmentsthis.environments")
    if (this.urlParams.params.id) {
      this.environments = [];
      this.networkingservice.post('/servicerequest/getServiceRequests', obj).subscribe(data => {
        console.log(data, "Data object")
        if (data.userconfigure == false) {
          var serviceInstance = data.serviceInstance
          var duplicateoperatingfield = null;
          var duplicateprotoplatform = null;
          var duplicatecount = 0;
          var duplicateenv = 0;
          for (var i = 0; i < serviceInstance.length; i++) {
            if (serviceInstance[i].OperatingSystemField != duplicateoperatingfield && serviceInstance[i].PrototypePlatformField != duplicateprotoplatform) {
              console.log(duplicatecount, "asdfsdfasdfasdfasdfasdfasdfasdf11111111111111,", duplicateoperatingfield, "  ", duplicateprotoplatform)
              if (duplicateenv > 0) {
                let envobj = {
                  OperatingSystemField: duplicateoperatingfield,
                  PrototypePlatformField: duplicateprotoplatform,
                  InstanceNeededField: duplicatecount,
                  DurationNeededField: weeks,
                }
                console.log(duplicateoperatingfield, duplicateprotoplatform, duplicatecount, weeks)
                this.environments.push(envobj)
              }
              //  console.log(serviceInstance[i].DurationNeededField,"DurationNeededField")
              var fromDate = new Date(serviceInstance[i].DurationNeededField)
              var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds    
              var diffDays = Math.round(Math.abs((new Date().getTime() - fromDate.getTime()) / (oneDay)));
              var weeks = Math.round(diffDays / 7);
              // console.log(weeks);

              duplicateoperatingfield = serviceInstance[i].OperatingSystemField;
              duplicateprotoplatform = serviceInstance[i].PrototypePlatformField;
              duplicatecount = 1;
            }
            else {
              duplicatecount++;
            }
            duplicateenv++;
            console.log(duplicatecount, "asdfsdfasdfasdfasdfasdfasdfasdf,", duplicateoperatingfield, "  ", duplicateprotoplatform)
          }
          if (duplicateenv > 0) {
            let envobj = {
              OperatingSystemField: duplicateoperatingfield,
              PrototypePlatformField: duplicateprotoplatform,
              InstanceNeededField: duplicatecount,
              DurationNeededField: weeks,
            }
            console.log(duplicateoperatingfield, duplicateprotoplatform, duplicatecount, weeks)
            this.environments.push(envobj)
          }
          console.log(this.environments, "this.environmentsthis.environments")


        }
        // data.serviceInstance
        // this.environments = 
        // }
        // this.environments = data.environments;
        // console.log(this.environments.serviceInstance,"this.environmentsthis.environmentsthis.environmentsthis.environments")
        this.req_id = data.req_id;
        if (!data) {
          this.approveflag = false;
          this.rejectflag = false;
          this.revertflag = false;
        }
        this.serviceCollector = data;
        this.user_id = this.serviceCollector.user_id;
        if (this.serviceCollector.Requestername) {
          this.Requestername = this.serviceCollector.Requestername;
          this.email_address = this.serviceCollector.email_address;
          this.Phonenumber = this.serviceCollector.Phonenumber;
          this.status = this.serviceCollector.status;
          this.id = this.serviceCollector.service_id;
        } else {
          this.onbehalfname = this.serviceCollector.onbehalfname;
          this.onbehalfemail = this.serviceCollector.onbehalfemail;
          this.onbehalfphonenumber = this.serviceCollector.onbehalfphonenumber;
        }
        this.Clientname = this.serviceCollector.Clientname;
        this.Role = this.serviceCollector.Role;
        this.ServiceRequested = this.serviceCollector.ServiceRequested;
        this.RequestType = this.serviceCollector.RequestType;
        if (this.RequestType === 'Prototyping, Business Need') {
          this.RequesttypeFlag = true;
        } else if (this.RequestType === 'Prototyping, Technical Need') {
          this.RequesttypeFlag = false;
        }
        this.PreferredChannel = this.serviceCollector.PreferredChannel;
        if (this.PreferredChannel === 'Mobile') {
          this.platform = this.platform1;
        } else if (this.PreferredChannel === 'Tablet') {
          this.platform = this.platform2;
        } else if (this.PreferredChannel === 'Desktop') {
          this.platform = this.platform3;
        }
        // console.log("this.serviceCollector.Preferredplatform",this.serviceCollector.Preferredplatform)
        this.Preferredplatform = this.serviceCollector.Preferredplatform;
        this.Fidelity = this.serviceCollector.Fidelity;
        this.techStackArray = this.serviceCollector.techStackArray;
        this.userconfigure = this.serviceCollector.userconfigure;
        this.serviceassets = this.serviceCollector.assets;
        this.supportingFileName = this.serviceassets[0].replace(/\\/g, '/').replace(/.*\//, '');
      });
    }
    this.loading = true;
    if (this.urlParams.params) {
      if (this.urlParams.params.action === 'view') {
        this.action = 'hide';
        this.disabled = true;
        this.disableOnNext = true;
        this.ngbTabSet.activeId = 'signUptwo';
        this.isthisDraft = true;
      }
    }
    if (this.userObj.userGroup === 'SUPERADMIN') {
      this.action = 'edit';
      if (!this.urlParams.params.id) {
        this.updatebtn = true;
      }
      this.disabled = this.disableOnNext = false;
    } else if (this.userObj.userGroup === 'CUSTOMER') {
      this.updatebtn = true;
    }
    this.userObj = JSON.parse(localStorage.getItem('user'));
    this.emailaddress = this.userObj.email.toLowerCase();
  }
  changeShowStatus() {
    this.showHide = false;
  }
  changeShowStatusdiv() {
    this.showHide = true;
  }
  toggle() {
    this.myVar = !(this.myVar);
    this.req_id = 'REQ' + Math.floor(100000 + Math.random() * 900000);
  }
  edit() {
    this.disableOnNext = true;
  }
  onbehalfclass(){
    var returnvale;
    if (this.onbehalfflag) {
      returnvale="aboutMyselfandRequest1";
      // console.log("aboutMyselfandRequest")
     return returnvale;
    } else {
      returnvale="aboutMyselfandRequest";
      //  console.log("aboutMyselfandRequest1")
      return returnvale;
    }
  }
  onbehalf($event: any) {
    console.log($event,"$event")
    this.onbehalfflag = !this.onbehalfflag;
    if (this.onbehalfflag) {
      this.showHide1 = true;

    } else {
      this.showHide1 = false;
      this.onbehalfname = '';
      this.onbehalfemail = '';
      this.onbehalfphonenumber = '';
    }
  }
  backToservicerequest() {
    this.loading = false;
    this.router.navigateByUrl('/servicebox/service-request');
  }
  closesignout() {
    this.deleteDialog = false;
    this.approveflag = false;
    this.rejectflag = false;
    this.revertflag = false;
  }
  deleteenv(index, envData_id) {
    this.deleteDialog = !this.deleteDialog;
    this.delindex = index;
    this.delete_id = envData_id;
    this.delenvironflag = true;
  }
  deleteRequestfun() {
    if (this.delenvironflag) {
      this.environments.splice(this.delindex, 1);
      this.count--;
    }
    this.deleteDialog = !this.deleteDialog;
    this.deleteEnvironment = true;
    setTimeout(() => {
      this.deleteEnvironment = false;
    }, 3000);
    this.delenvironflag = false;
  }
  submit() {
    this.submitDialog = !this.submitDialog;
    this.router.navigate(['/servicebox/service-request']);
  }
  updated() {
    this.updatedialog = !this.updatedialog;
    this.router.navigate(['/servicebox/service-request']);
  }
  addService(method) {

    for (let i = 0; i < this.environments.length; i++) {
      this.environments[i].PrototypePlatformField = this.environments[i].PrototypePlatformField;
    }
    this.toggle();
    if (this.isthisDraft) {
      this.update(method);
      return false;
    }
    const newService = {
      email: this.userObj.email,
      Requestername: this.Requestername,
      email_address: this.emailaddress,
      Phonenumber: this.Phonenumber,
      onbehalfemail: this.onbehalfemail,
      onbehalfname: this.onbehalfname,
      onbehalfphonenumber: this.onbehalfphonenumber,
      Clientname: this.Clientname,
      Role: this.Role,
      ServiceRequested: this.ServiceRequested,
      RequestType: this.RequestType,
      PreferredChannel: this.PreferredChannel,
      Preferredplatform: this.Preferredplatform,
      Fidelity: this.Fidelity,
      techStackArray: this.techStackArray,
      environments: this.environments,
      req_id: this.req_id,
      uploadDate: this.time.toString(),
      user_id: this.userObj.id,
      status: method,
      servicerejectComment: '',
      tilldate: this.gettillDay(),
      userconfigure: this.userconfigure,
      dueDate: this.getserviceday(this.time),
      instance_url: '',
      approvedDate: ''
    };
    console.log("service request object", newService);
    this.networkingservice.post('/servicerequest/addServiceRequest', newService)
      .subscribe(data => {
        this.uploadAssets(data);
        const envParams = {
          user_id: this.userObj.id,
          service_id: data.id
        };
        this.serviceCollector = data;
        if (data.status === 'Pending') {
          const notedate = new Date(Date.now());
          const newnotedate = notedate;
          this.adminFormNotification = {
            email: this.userObj.email,
            ref_id: data.id,
            notificationtag: 'ServiceRequest',
            message: '',
            action: '',
            status: 'pending',
            notificationDate: newnotedate,
            serviceRequest: data.req_id
          };
          this.networkingservice.post('/users/notification', this.adminFormNotification).subscribe((res) => {
          });
          this.submitDialog = !this.submitDialog;
        } else {
          this.isthisDraft = true;

        }
        if (this.serviceCollector) {
          this.deleteRequest = true;
          setTimeout(() => {
            this.deleteRequest = false;
          }, 3000);

        } else {
          this.deleteRequest = false;
        }
      });
  }
  gettillDay() {
    const insDuration = [];
    this.environments.forEach((elem) => {
      insDuration.push(elem.DurationNeededField);
    });
    this.result = Math.max(...insDuration);
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + (this.result * 7));
    this.maxrequestDate = currentDate.toLocaleString('en-IN', this.dateoptions);
    this.maxrequestDate = this.maxrequestDate.split('/').reverse();
    this.maxrequestDate = this.maxrequestDate.join(' ');
    return this.maxrequestDate;
  }
  getserviceday(gettime) {
    const d = new Date(gettime);
    this.servicedate = new Date(d.setDate(d.getDate() + 3)).toLocaleString('en-IN', this.options);
    return this.servicedate;
  }
  update(method) {
    console.log(method, "method")
    this.service = {
      user_id: this.userObj.id,
      Requestername: this.Requestername,
      email_address: this.emailaddress,
      Phonenumber: this.Phonenumber,
      onbehalfemail: this.onbehalfemail,
      onbehalfname: this.onbehalfname,
      onbehalfphonenumber: this.onbehalfphonenumber,
      Clientname: this.Clientname,
      Role: this.Role,
      ServiceRequested: this.ServiceRequested,
      RequestType: this.RequestType,
      PreferredChannel: this.PreferredChannel,
      Preferredplatform: this.Preferredplatform,
      Fidelity: this.Fidelity,
      techStackArray: this.techStackArray,
      environments: this.environments,
      req_id: this.serviceCollector.req_id,
      userconfigure: this.userconfigure,
      status: method,
      uploadDate: this.time,
      tilldate: this.serviceCollector.tilldate,
      dueDate: this.serviceCollector.dueDate,
      instance_url: this.serviceCollector.instance_url ? this.serviceCollector.instance_url : '',
      approvedDate: ''
    };
    this.networkingservice.put('/servicerequest/updateService/' + this.serviceCollector.id, this.service)
      .subscribe(data => {
        this.uploadAssets(data);

        const envParams = {
          user_id: this.userObj.id,
          service_id: this.serviceCollector.id
        };
        this.serviceCollector = data;
        if (this.data) {
          this.deleteRequest = true;
          setTimeout(() => {
            this.deleteRequest = false;
          }, 5000);
        } else {
          this.deleteRequest = false;
        }
      });
    if (method === 'Pending') {
      const notedate = new Date();
      const newnotedate = notedate.toLocaleString('en-IN', this.options);
      this.adminFormNotification = {
        email: this.userObj.email,
        ref_id: this.userObj.id,
        notificationtag: 'ServiceRequest',
        message: '',
        action: '',
        status: 'pending',
        notificationDate: newnotedate,
        serviceRequest: this.userObj.req_id
      };
      this.networkingservice.post('/users/notification', this.adminFormNotification).subscribe((res) => {
      });
      this.isthisDraft = false;
      this.updatedialog = !this.updatedialog;
    }
    if (!this.isthisDraft) {
      this.submitDialog = !this.submitDialog;
    }
  }
  cancelService() {
    this._location.back();
  }
  deleteclose() {
    this.deleteRequest = false;
  }
  getPosts() {
    console.log("dsafasfasdf")
    const userObj = JSON.parse(localStorage.getItem('user'));
    const newService = {
      email: userObj.email,
      Requestername: '',
      email_address: '',
      Phonenumber: '',
      Clientname: '',
      Domain: '',
      RequestType: '',
      PreferredChannel: '',
      Preferredplatform: '',
      Fidelity: '',
      OperatingSystemField: '',
      PrototypePlatformField: '',
      InstanceNeededField: '',
      req_id: '',
      user_id: userObj.id,
      uploadDate: '',
      instance_url: '',
      action: 'get',
      approvedate: '',
      userGroup: userObj.userGroup
    };
    this.networkingservice.post('/servicerequest/getServiceRequests', newService)
      .subscribe(serviceform => {
        this.loading = false;
        this.serviceforms = serviceform;
        console.log(this.serviceforms, "this.serviceforms")
      });
  }
  techStackdiv(event) {
    if (event.key === 'Enter') {
      if (this.TechnologyStack) {
        let match = false;
        for (let i = 0; i < this.techStackArray.length; i++) {
          if (this.techStackArray[i] == this.TechnologyStack) {
            match = true;
            break;
          }
        }
        if (!match) {
          this.techStackArray.push(this.TechnologyStack.toLowerCase());
        }
        this.TechnologyStack = '';
      }
    }
  }
  removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }
  techstackfinaldiv() {
    this.techstackfinaldivboolean = true;
    this.showHide = false;
  }
  closetech(item) {
    const index = this.techStackArray.indexOf(item);
    this.techStackArray.splice(index, 1);
  }
  editPro() {
    this.updatebtn = true;
    this.action = 'edit';
    this.disabled = this.disableOnNext = false;
  }
  Rejectflag() {
    this.rejectflag = true;
    this.data.changeMessage({ id: this.req_id, status: 'requestRejected' });
  }
  Reject() {
    const RejectRequest = {
      id: this.urlParams.params.id,
      email: this.serviceCollector.email_address,
      req_id: this.serviceCollector.req_id,
      servicerejectComment: this.servicerejectComment
    };
    this.networkingservice.post('/servicerequest/RejectRequest', RejectRequest)
      .subscribe(data => {
        this.loading = false;
        this.environments.push({
          id: '',
          service_id: '',
          user_id: this.userObj.id,
          OperatingSystemField: '',
          PrototypePlatformField: '',
          InstanceNeededField: '',
          DurationNeededField: ''
        });
        this.environments = data.environments;
        this.serviceCollector = data;
        this.user_id = this.serviceCollector.user_id;
        if (this.serviceCollector.Requestername) {
          this.Requestername = this.serviceCollector.Requestername;
          this.email_address = this.serviceCollector.email_address;
          this.Phonenumber = this.serviceCollector.Phonenumber;
          this.status = this.serviceCollector.status;
          this.id = this.serviceCollector.service_id;
        } else {
          this.onbehalfname = this.serviceCollector.onbehalfname;
          this.onbehalfemail = this.serviceCollector.onbehalfemail;
          this.onbehalfphonenumber = this.serviceCollector.onbehalfphonenumber;
        }
        this.router.navigate(['/admin/rbac-dashboard']);
      });
  }
  Revert() {
    const RevertRequest = {
      id: this.urlParams.params.id,
      email: this.serviceCollector.email_address,
      req_id: this.serviceCollector.req_id
    };
    this.networkingservice.post('/servicerequest/revertrequest', RevertRequest)
      .subscribe(data => {
        this.environments.push({
          id: '',
          service_id: '',
          user_id: this.userObj.id,
          OperatingSystemField: '',
          PrototypePlatformField: '',
          InstanceNeededField: '',
          DurationNeededField: ''
        });
        this.environments = data.environments;
        this.serviceCollector = data;
        this.user_id = this.serviceCollector.user_id;
        this.req_id = this.serviceCollector.req_id;
        if (this.serviceCollector.Requestername) {
          this.Requestername = this.serviceCollector.Requestername;
          this.email_address = this.serviceCollector.email_address;
          this.Phonenumber = this.serviceCollector.Phonenumber;
          this.status = this.serviceCollector.status;
          this.id = this.serviceCollector.service_id;
        } else {
          this.onbehalfname = this.serviceCollector.onbehalfname;
          this.onbehalfemail = this.serviceCollector.onbehalfemail;
          this.onbehalfphonenumber = this.serviceCollector.onbehalfphonenumber;
        }
        this.router.navigate(['/landingpage']);
      });
    this.revertflag = false;
  }
  updateflag() {
    this.updatebtn = true;
    this.updatesubmit = true;
  }
  Approveflag() {
    const obj = {
      crowd: this.userconfigure,
      id: this.req_id
    };
    this.approveflag = true;
  }
  Revertflag() {
    this.revertflag = true;
  }
  Approve() {
    this.data.changeMessage({ id: this.serviceCollector.req_id, status: 'requestApproved', crowd: this.userconfigure });
    const newapprovedate = new Date(Date.now());
    const newapprovedate1 = newapprovedate.toLocaleString('en-IN', this.options);
    const ApproveRequest = {
      userconfigure: this.serviceCollector.userconfigure,
      status: this.serviceCollector.status,
      id: this.urlParams.params.id,
      email: this.serviceCollector.email_address,
      req_id: this.serviceCollector.req_id,
      approvedDate: newapprovedate1
    };
    this.approveflag = false;
    this.loading = true;
    this.networkingservice.post('/servicerequest/ApproveRequest', ApproveRequest)
      .subscribe(data => {
        this.loading = false;
        // this.environments.push({
        //   id: '',
        //   service_id: '',
        //   user_id: this.userObj.id,
        //   OperatingSystemField: '',
        //   PrototypePlatformField: '',
        //   InstanceNeededField: '',
        //   DurationNeededField: ''
        // })
        // console.log("vikcy", this.environments);
        // this.getPosts();
        //this.a.environments = this.environments;
        // this.route.queryParamMap.subscribe(params => {
        //   this.urlParams = { ...params.keys, ...params };
        // });

        // console.log("this.ngbTabChangeEvent ", this.urlParams.params.id);

        // var obj = { "query": this.urlParams.params.id, "lang": "en" }
        // if (this.urlParams.params.id) {
        // var id = {
        //   query: this.urlParams.params.id,
        // }
        // this.networkingservice.post('/servicerequest/getservicerequest', id).subscribe(data => {
        //   console.log("TEst Data ", data)
        //   const envParams = {
        //     user_id: this.userObj.id,
        //     service_id: data.id
        // }
        // this.networkingservice.post('/servicerequest/getEnvironments', envParams)
        //   .subscribe(envData => {
        //     if (envData.length) {
        // console.log("eveie", envData);
        // data.environments = envData
        // this.environments = data.environments;
        this.serviceCollector = data[0];
        this.user_id = this.serviceCollector.user_id;
        if (this.serviceCollector.Requestername) {
          this.Requestername = this.serviceCollector.Requestername;
          this.email_address = this.serviceCollector.email_address;
          this.Phonenumber = this.serviceCollector.Phonenumber;
          this.status = this.serviceCollector.status;
          this.id = this.serviceCollector.service_id;
        } else {
          this.onbehalfname = this.serviceCollector.onbehalfname;
          this.onbehalfemail = this.serviceCollector.onbehalfemail;
          this.onbehalfphonenumber = this.serviceCollector.onbehalfphonenumber;
        }
        this.approveflag = false;
        if (this.serviceCollector.userconfigure) {
          this.router.navigateByUrl('/crowdSourcing?id=' + this.urlParams.params.id);
        } else {
          this.router.navigateByUrl('/admin/rbac-dashboard');
        }
      });
  }
  gotoPrevStep() {
    const currentTab = this.ngbTabSet.activeId.replace('signUp', '');
    this.tabCount = currentTab - 1;
    this.ngbTabSet.activeId = 'signUp' + this.tabCount;
    if (this.adminserviceflag === 'true') {
      this._location.back();
    }
    if (this.tabCount < 1) {
      this.backToservicerequest();
    }
  }
  terms() {
    this.tcDialog = !this.tcDialog;
  }
  terms_close() {
    this.tcDialog = !this.tcDialog;
  }
  Requesttype() {
    if (this.RequestType === 'Prototyping, Business Need') {
      this.RequesttypeFlag = true;
      this.userconfigure = true;
      this.PreferredChannel = '';
      this.Preferredplatform = '';
      this.Fidelity = '';
      this.TechnologyStack = '';
    } else if (this.RequestType === 'Prototyping, Technical Need') {
      this.RequesttypeFlag = false;
      this.userconfigure = false;
      this.environments = [];
      this.environments.push({
        id: '',
        service_id: '',
        user_id: this.userObj.id,
        OperatingSystemField: '',
        PrototypePlatformField: '',
        InstanceNeededField: '',
        DurationNeededField: ''
      });
    }
  }
  focusFunction(focusid) {
    if (focusid === 1) {
      this.tab1 = true;
    } else if (focusid === 2) {
      this.tab2 = true;
    } else if (focusid === 3) {
      this.tab3 = true;
    } else if (focusid === 4) {
      this.tab4 = true;
    } else if (focusid === 5) {
      this.tab5 = true;
    } else if (focusid === 6) {
      this.tab6 = true;
    } else if (focusid === 7) {
      this.tab7 = true;
    } else if (focusid === 8) {
      this.tab8 = true;
    } else if (focusid === 9) {
      this.tab9 = true;
    } else if (focusid === 10) {
      this.tab10 = true;
    } else if (focusid === 11) {
      this.tab11 = true;
    } else if (focusid === 12) {
      this.tab12 = true;
    } else if (focusid === 13) {
      this.tab13 = true;
    }
  }
  focusOutFunction(focusid) {
    if (focusid === 1) {
      this.tab1 = false;
    } else if (focusid === 2) {
      this.tab2 = false;
    } else if (focusid === 3) {
      this.tab3 = false;
    } else if (focusid === 4) {
      this.tab4 = false;
    } else if (focusid === 5) {
      this.tab5 = false;
    } else if (focusid === 6) {
      this.tab6 = false;
      // if (this.RequestType === 'Prototyping, Business Need') {
      //   this.RequesttypeFlag = true;
      //   this.userconfigure = true;
      //   this.PreferredChannel = '';
      //   this.Preferredplatform = '';
      //   this.Fidelity = '';
      //   this.TechnologyStack = '';
      // } else if (this.RequestType === 'Prototyping, Technical Need') {
      //   this.RequesttypeFlag = false;
      //   this.userconfigure = false;
      //   this.environments = [];
      //   this.environments.push({
      //     id: '',
      //     service_id: '',
      //     user_id: this.userObj.id,
      //     OperatingSystemField: '',
      //     PrototypePlatformField: '',
      //     InstanceNeededField: '',
      //     DurationNeededField: ''
      //   });
      // }
    } else if (focusid === 7) {
      this.tab7 = false;
      if (this.PreferredChannel === 'Mobile') {
        this.platform = this.platform1;
      } else if (this.PreferredChannel === 'Tablet') {
        this.platform = this.platform2;
      } else if (this.PreferredChannel === 'Desktop') {
        this.platform = this.platform3;
      }
    } else if (focusid === 8) {
      this.tab8 = false;
    } else if (focusid === 9) {
      this.tab9 = false;
    } else if (focusid === 10) {
      this.tab10 = false;
    } else if (focusid === 11) {
      this.tab11 = false;
    } else if (focusid === 12) {
      this.tab12 = false;
    } else if (focusid === 13) {
      this.tab13 = false;
    }
  }
  addFieldValue() {
    this.environments.push({
      _id: '',
      service_id: '',
      user_id: this.userObj.id,
      OperatingSystemField: '',
      PrototypePlatformField: '',
      InstanceNeededField: '',
      DurationNeededField: ''
    });
    const len = this.environments.length - 1;
    this.count++;
  }
  mask: any[] = [/[1-9]/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.number = window.pageYOffset;
  }
  uploadAssets(data) {
    console.log("ddddddddddddddddddddddddddddddddddddddddddddd,", data.req_id)
    const formData = new FormData();
    this.serviceAssetUploader.queue.forEach((element) => {
      formData.append('serviceAssets', element._file, element._file.name);
    });
    this.networkingservice.post('/service/upload/' + data.req_id, formData).subscribe((output) => {

      console.log(output)
    });
  }
  down() {
    this.networkingservice.get('/service/download/').subscribe((output) => {

      console.log("output")
    });
  }
}
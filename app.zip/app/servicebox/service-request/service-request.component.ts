import {
  Component, OnInit, Input, Output, OnChanges, EventEmitter,
  trigger, state, style, animate, transition
} from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { LoadingModule } from 'ngx-loading';
import { ServiceInterface } from '../../shared/service.interface';
import { NetWorkingService } from '../../shared/networking.service';
import { DataService } from '../../shared/data.service';
import { requestInterface } from '../../shared/viewRequest.interface';
import { async } from 'async';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-service-request',
  templateUrl: './service-request.component.html',
  styleUrls: ['./service-request.component.css'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
// -----------------------------flag details-----------------------

// showDialog : draft limit popup,
// deleteDialog : delete confirmation popup
// loading : loading flag
// deleteRequest : soft message after deleting
// showDialogoverlay : close popup on clicking outside
// RejectDialog : reject dialog popup
// dummy : provisioning popup array of flags

// -----------------------------flag details-----------------------

export class ServiceRequestComponent implements OnInit {
  message: any;
  subscription: Subscription;
  private serviceRequests: ServiceInterface[] = [];
  private errorMessage: any = '';
  showDialog = false;
  deleteDialog = false;
  public loading = false;
  deleteRequest = false;
  envdisplay = false;
  rowIndex = 0;
  minusq = [];
  dept: any;
  delete_id: any;
  envrn_id: any;
  result: any;
  requestinstances: any;
  serviceforms: ServiceInterface[] = [];
  requestForms: requestInterface[] = [];
  showDialogoverlay = true;
  RejectDialog = false;
  email: any;
  dummy = [];
  rejected: string;
  auth: string;
  authtoken: string;
  letcount = 0;
  instanceUrl: string;
  serviceRequest = [];
  environmentsData: any;
  approvedDate: any;
  envArray = [];
  newapprovedate: any;
  date = new Date();
  expirationflag = false;
  maxrequestDate: any;
  expiration: string;
  expirationid: string;
  userEmail: Array<any> = [];
  fromDate: Array<any> = [];
  toDate: Array<any> = [];
  services = [];
  approveArray: Array<any> = [];
  instance_url = [];
  launching = [];
  status = [];
  userId: any;
  options = {
    year: 'numeric', month: 'short',
    day: 'numeric' ,
  };
  @Input() closable = true;
  @Input() visible: boolean;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private route: ActivatedRoute, private router: Router,
    private networkingservice: NetWorkingService, private data: DataService) {
    this.subscription = this.data.getMessage().subscribe(message => { this.expirationflag = true; });
  }

  ngOnInit() {
    this.loading = true;
    this.getPosts();
    this.expiration = localStorage.getItem('Expirationflag');
    const userObj = JSON.parse(localStorage.getItem('user'));
    this.email = userObj.email;
    this.userId = userObj.id;
  }
  close() {
    this.showDialog = !this.showDialog;
    this.showDialogoverlay = !this.showDialogoverlay;
  }
  Approve(i) {
    const newapprovedate = new Date(Date.now());
    this.newapprovedate = this.date.toLocaleString('en-IN', this.options);
    for (let j = 0; j < this.serviceforms.length; j++) {
      this.approveArray.push(this.serviceforms[j]);
    }
    const ApproveRequest = {
      req_id: this.approveArray[i].req_id,
      OperatingSystemField: this.approveArray[i].OperatingSystemField,
      PrototypePlatformField: this.approveArray[i].PrototypePlatformField,
      approvedDate: this.newapprovedate
    };
    this.networkingservice.post('/servicerequest/ApproveRequest', ApproveRequest)
      .subscribe(ApproveResponse => {
        this.loading = false;
      });
    this.getPosts();
  }
  getPosts() {
    this.expiration = localStorage.getItem('Expirationflag');
    const userObj = JSON.parse(localStorage.getItem('user'));
    const newService = {
      user_id: userObj.id,
      userGroup: userObj.userGroup
    };
    this.networkingservice.post('/servicerequest/getServiceRequests', newService)
      .subscribe(serviceform => {
        this.loading = false;
        this.serviceforms = serviceform;
        if (this.expiration) {
          this.expirationflag = true;
          for (let j = 0; j <= this.serviceforms.length - 1; j++) {
            if (this.serviceforms[j].req_id === this.expiration) {
              this.expirationid = this.serviceforms[j].id;
            }
          }
          this.networkingservice.post('/servicerequest/getserviceenvironment/' + this.expirationid, {})
            .subscribe(environment => {
              const currentDate = new Date();
              for (let j = 0; j < environment.length; j++) {
                if (!this.envArray[environment[j].id]) {
                  this.envArray[environment[j].id] = [];
                }
                this.envArray[environment[j].id].OperatingSystemField = environment[j].OperatingSystemField;
                this.envArray[environment[j].id].PrototypePlatformField = environment[j].PrototypePlatformField;
              }
            });
          this.networkingservice.post('/servicerequest/getservicerequestinstances/' + this.expirationid, {})
            .subscribe(requestinstances => {
              this.loading = false;
              this.requestinstances = requestinstances;
              for (let j = 0; j < this.requestinstances.length; j++) {
                this.userEmail.push(this.requestinstances[j].assignedto);
                this.fromDate.push(this.requestinstances[j].provision_date_from);
                this.toDate.push(this.requestinstances[j].provision_date_to);
              }
            });
        }
        const i = 0;
      });
  }
  userconfig(id) {
    this.router.navigateByUrl('/servicebox/instance-assign?id=' + id + '&action=view');
  }
  extendRequest(id, req_id) {
    this.router.navigateByUrl('/servicebox/instance-assign?id=' + id + '&action=extend');
}
  deleteclose() {
    this.deleteRequest = false;
  }
  toggle(id) {
    this.delete_id = id;
    this.deleteDialog = !this.deleteDialog;
  }
  closesignout() {
    this.deleteDialog = !this.deleteDialog;
  }
  leftBorderColor(status, id, userconfigure) {
    this.letcount++;
    const colorCheck = ['startingDate', 'overdue', 'fulfilled'];
    if (status === 'Pending' || status === 'Draft' || status === 'Rejected' ||
     status === 'Pending Resources' || status === 'Resubmitted' ||
      (status === 'Pending Provisioning' && userconfigure !== false)) {
      return colorCheck[0];
    } else if (status === 'Pending Provisioning' && userconfigure === false) {
      return colorCheck[1];
    } else if (status === 'Fulfilled' && userconfigure === false ||
     status === 'Fulfilled' && userconfigure === true ) {
      return colorCheck[2];
    }
  }
  viewServiceRequest(id) {
    const obj = {
      'query': id,
      'action': 'view',
      'lang': 'en'
    };
    this.data.changeMessage('true');
    this.router.navigateByUrl('/servicebox/service-request/service-form?id=' + id + '&action=view');
  }
  deleteRequestfun() {
    this.networkingservice.delete('/servicerequest/delete/' + this.delete_id + '/' + this.userId).subscribe(data => {
      if (this.data) {
        this.deleteRequest = true;
        setTimeout(() => {
          this.deleteRequest = false;
        }, 3000);
      } else {
        this.deleteRequest = false;
      }
      this.getPosts();
    });
    this.deleteDialog = !this.deleteDialog;
    this.deleteRequest = true;
  }
  provisionflag(i) {
    for (let j = 0; j < this.dummy.length; j++) {
      this.dummy[j] = false;
    }
    this.dummy[i] = true;
  }
  navClick() {
    this.showDialog = false;
  }
  edit() {
    this.router.navigateByUrl('/servicebox/service-request/service-form?id=' + this.serviceforms[0].id + '&action=view');
  }
  viewReject(id) {
    const reqObj = {
      'query': id,
      'lang': 'en',
      'view': true
    };
    this.networkingservice.post('/servicerequest/getServiceRequests/', reqObj).subscribe(Response => {
      this.rejected = Response.servicerejectComment;
      this.auth = Response.Clientname;
      this.RejectDialog = true;
    });
  }
  closerejectbox() {
    this.RejectDialog = false;
  }
  validate() {
    this.getPosts();
    this.data.changeMessage('false');
    let draftCount = 0;
    if (this.serviceforms.length !== 0) {
      for (let j = 0; j < this.serviceforms.length; j++) {
        if (this.serviceforms[j].status === 'Draft') {
          draftCount++;
          if (draftCount >= 3) {
            this.showDialog = true;
          }
        }
      }
      if (this.showDialog === false) {
        this.router.navigateByUrl('/servicebox/service-request/service-form');
      }
    } else {
      this.router.navigateByUrl('/servicebox/service-request/service-form');
    }
  }
}


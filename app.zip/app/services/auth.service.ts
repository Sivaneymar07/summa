import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import 'rxjs/add/observable/throw';
import { tokenNotExpired } from 'angular2-jwt';
import { Observable } from 'rxjs/Rx';
import { CookieService } from 'ngx-cookie';

// Operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class AuthService {
  authToken: any;
  user: any;
  loggedUser: any;
  AUTH_COOKIE_ID = "GUAC_AUTH";
  guaToken: string;

  constructor(private http: Http, private cookieService: CookieService) { }

  getUsers(): Observable<any> {
    //return this.http.get('./assets/data/category.json')
    return this.http.get('/users/register')
      .map(
      (response: Response) => {


        const data = response.json();

        //  return response.json();
        return data;
      }
      ).catch(this.handleError);
  }
  private handleError(errorResponse: Response) {
    return Observable.throw(errorResponse.json().error || 'Server error');
  }

  registerUser(user) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('/users/register', user, { headers: headers }).map(res => res.json());
  }
  profileUpdate(user) {
    const user1 = JSON.parse(localStorage.getItem('user'));
    const email = user1.email;

    const userProfile = {
      user: user,
      emailId: email
    };

    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('/users/profile', userProfile, { headers: headers }).map((response: Response) => {

      return response.json();

    });
  }

  // profileUpdateView() {
  //   const user = JSON.parse(localStorage.getItem('user'));
  //   var obj ={ email : user.email};
  //   return this.http.post('/users/ViewProfile',obj).map(res => res.json());
  // }
  authenticateUser(user) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('/users/authenticate', user, { headers: headers }).map(res => res.json());
  }

  getProfile() {
    const headers = new Headers();
    this.loadToken();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', this.authToken);
    return this.http.get('/users/register', { headers: headers }).map((res: Response) => {
      res.json();
    });
  }

  putCookie(key: string, value: Object, cookieOptions: Object) {
    this.cookieService.putObject(key, value, cookieOptions);
  }


  storeUserData(token, user, guaData) {
    console.log("guaData", guaData);
    localStorage.setItem('id_token', token);
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('localCount', 'one');
    this.guaToken = guaData.authToken;
    console.log("guaData", guaData);
    let template = {
      authToken: guaData.authToken,
      username: guaData.username,
      dataSource: guaData.dataSource,
      availableDataSources: guaData.availableDataSources
    }
    let cookieOptions = {
      path: '/guacamole'
    }
    this.putCookie(this.AUTH_COOKIE_ID, template, cookieOptions);
    this.authToken = token;
    this.user = user;
  }


  getUserData() {

    return this.user.username;
  }

  getUserToken() {
    return this.authToken;
  }
  loadToken() {
    const token = localStorage.getItem('id_token');
    this.authToken = token;
  }

  loggedIn() {
    return tokenNotExpired('id_token');
  }

  logout() {
    this.http.delete('http://ec2-52-70-168-206.compute-1.amazonaws.com:8080/guacamole/api/tokens/' + this.guaToken).map((response: Response) => {
    }).catch(this.handleError);
    this.cookieService.removeAll();
    this.authToken = null;
    this.user = null;
    localStorage.clear();


  }
}
